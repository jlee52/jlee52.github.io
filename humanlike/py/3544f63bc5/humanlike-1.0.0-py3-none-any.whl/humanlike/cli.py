"""Command line interface.

    humanlike validate DATA                     check a data set; list the analyses it supports
    humanlike validate DATA --protocol NAME     ... and that it was recorded under a protocol (leaderboard entry)
    humanlike evaluate DATA -o results/         run every applicable analysis; write results.json
    humanlike export minari DATA DATASET_ID     write a data set as a Minari dataset (profile in infos)
DATA: a Minari dataset (directory or registered id) with the humanlike profile.
    humanlike convert <adapter> <input> <dataset-id> --name MODEL [...]  to a Minari dataset (adapters: curated,
                                                mimickit, c3d, bvh, csv); an output ending in .hlb writes the
                                                internal container instead
    humanlike summarize results/results.json    one leaderboard row (humanlike.summary)
    humanlike references                        list the reference data in the bundle
    humanlike serve [--open]                    the web app on this computer (http://127.0.0.1:8765)
    humanlike cache [--clear]                   size of the stage cache, or empty it
"""
from __future__ import annotations

import argparse
import importlib
import json
import sys
from pathlib import Path


def _print_validation(rep: dict):
    print("OK" if rep["ok"] else "INVALID")
    for e in rep["errors"]:
        print(f"  error:   {e}")
    for w in rep["warnings"][:20]:
        print(f"  warning: {w}")
    if len(rep["warnings"]) > 20:
        print(f"  ... {len(rep['warnings']) - 20} more warnings")
    for k, v in rep["capabilities"].items():
        print(f"  {'+' if v['available'] else '-'} {k:<11s} {v['reason']}")


def cmd_validate(a):
    from .format import load, validate
    ds = load(a.input)
    rep = validate(ds).to_dict()
    _print_validation(rep)
    ok = rep["ok"]
    if a.protocol:
        from .rl.protocol import conformance
        c = conformance(ds, a.protocol, checks=not a.no_checks)
        print(f"protocol {a.protocol}: {'conforms' if c.ok else 'does not conform'}")
        print("\n".join("  " + line for line in str(c).splitlines()))
        rep["protocol"] = {"name": a.protocol, "ok": c.ok, "rows": [list(row) for row in c.rows]}
        ok = ok and c.ok
    if a.json:
        Path(a.json).write_text(json.dumps({**rep, "ok": ok}, indent=1))
    return 0 if ok else 1


def cmd_evaluate(a):
    from .engine import evaluate
    from .format import load
    ds = load(a.input)
    refs = {}
    if a.gait_reference:
        refs["gait"] = a.gait_reference
    if a.feedback_reference:
        refs["feedback"] = a.feedback_reference
    if a.kinetics_reference:
        refs["kinetics"] = [a.kinetics_reference]
    cache = None
    if not a.no_cache:
        from .cache import DirCache
        cache = DirCache(a.cache_dir)
    res = evaluate(ds, references=refs, only=a.only, cache=cache,
                   progress=lambda i, n, s, st: print(f"[{i}/{n}] {s}: {st}", file=sys.stderr))
    _print_validation(res["validation"])
    out = Path(a.output)
    out.mkdir(parents=True, exist_ok=True)
    (out / "results.json").write_text(json.dumps(res, indent=1))
    from .report import render
    (out / "report.html").write_text(render(res))
    for name, st in res["stages"].items():
        line = f"  {name:<15s} {st['status']}" + (" (cached)" if st.get("cached") else "")
        if st["status"] != "ok":
            line += f"  ({st.get('reason', '')})"
        print(line)
    print(f"results: {out / 'results.json'}, report: {out / 'report.html'}")
    return 0 if res["validation"]["ok"] else 1


def cmd_convert(a):
    from .format import write
    mod, fn = __import__("humanlike.adapters", fromlist=["ADAPTERS"]).ADAPTERS[a.adapter].split(":")
    convert = getattr(importlib.import_module(mod), fn)
    kw = {}
    if a.speeds:
        kw["speeds"] = a.speeds
    if a.side:
        kw["side"] = a.side
    for k in ("fs", "units", "up", "mass_kg", "leg_length_m"):
        if getattr(a, k) is not None:
            kw[k] = getattr(a, k)
    if a.treadmill_speed is not None:
        kw["treadmill_speed"] = a.treadmill_speed if a.treadmill_speed == "auto" else float(a.treadmill_speed)
    ds = convert(a.input, a.name, **kw)
    if a.output.endswith(".hlb"):                    # internal container
        write(a.output, ds)
        print(f"{a.output}: {len(ds.rollouts)} rollouts")
        return 0
    import warnings
    from .adapters.minari_io import write as write_minari
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        try:
            d = write_minari(ds, a.output, samples_per_step=a.samples_per_step, data_format=a.data_format, root=a.root)
        except ImportError:
            print('Arrow output needs: pip install "humanlike[minari]" (HDF5 does not)', file=sys.stderr)
            return 1
    print(f"{a.output}: Minari dataset with the humanlike profile, {len(ds.rollouts)} episodes ({d})")
    return 0


def cmd_export(a):
    from .format import load
    from .adapters.minari_io import write
    import warnings
    ds = load(a.input)
    with warnings.catch_warnings():                 # Minari's reminders for author, code link, ...
        warnings.simplefilter("ignore", UserWarning)
        d = write(ds, a.dataset_id, samples_per_step=a.samples_per_step, data_format=a.data_format, root=a.root)
    print(f"{d}: {len(ds.rollouts)} episodes")
    return 0


def cmd_serve(a):
    from .server import serve
    serve(a.host, a.port, cache=not a.no_cache, open_browser=a.open)
    return 0


def cmd_cache(a):
    from .cache import DirCache
    c = DirCache(a.cache_dir)
    if a.clear:
        print(f"removed {c.clear()} files from {c.path}")
    else:
        i = c.info()
        print(f"{i['path']}: {i['entries']} entries, {i['bytes'] / 1e6:.1f} MB")
    return 0


def cmd_summarize(a):
    from .summary import main as summarize
    return summarize([a.results] + (["-o", a.output] if a.output else []))


def cmd_references(a):
    from .references import Bundle
    b = Bundle(a.bundle)
    for n, m in b.manifest["references"].items():
        here = (b.path / m["file"]).exists()
        print(f"{'+' if here else '-'} {n:<28s} {m['license']:<40s} {m.get('description', '')}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="humanlike", description="Biomechanical human-likeness benchmark for locomotion")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("validate", help="check a data set; list the analyses it supports"); p.add_argument("input")
    p.add_argument("--protocol", help="also check that it was recorded under this protocol (humanlike.rl.PROTOCOLS)")
    p.add_argument("--no-checks", action="store_true", help="--protocol: skip the recording checks of the rollouts")
    p.add_argument("--json", help="write the report to this file")
    p.set_defaults(fn=cmd_validate)
    p = sub.add_parser("evaluate", help="run the analyses")
    p.add_argument("input"); p.add_argument("-o", "--output", default="results")
    p.add_argument("--gait-reference", nargs="+"); p.add_argument("--feedback-reference", nargs="+")
    p.add_argument("--kinetics-reference", help="human kinetic reference (default camargo-treadmill/kinetics)")
    p.add_argument("--only", nargs="+", help="run only these stages (and what they need)")
    p.add_argument("--no-cache", action="store_true", help="recompute every stage")
    p.add_argument("--cache-dir", help="stage cache (default $HUMANLIKE_CACHE or ~/.cache/humanlike)")
    p.set_defaults(fn=cmd_evaluate)
    p = sub.add_parser("convert", help="convert motion capture or simulator logs to a Minari dataset with the profile")
    p.add_argument("adapter", choices=["curated", "mimickit", "c3d", "bvh", "csv"]); p.add_argument("input")
    p.add_argument("output", help="Minari dataset id (namespace/name-v0) or directory")
    p.add_argument("--name", required=True); p.add_argument("--speeds", type=float, nargs="+")
    p.add_argument("--side", choices=["left", "right"], help="mimickit: leg of the sagittal angles and moments")
    p.add_argument("--fs", type=float, help="csv: sampling rate if there is no time column")
    p.add_argument("--units", help="bvh, csv: length unit of the file (m, cm, mm, in; bvh: auto)")
    p.add_argument("--up", choices=["x", "y", "z"], help="vertical axis (c3d, csv: z; bvh: y)")
    p.add_argument("--mass", dest="mass_kg", type=float, help="body mass (kg), needed for energetics and kinetics")
    p.add_argument("--leg-length", dest="leg_length_m", type=float, help="leg length (m), for dimensionless kinetics")
    p.add_argument("--treadmill-speed", help="c3d: belt speed in m/s, or 'auto' to estimate it")
    p.add_argument("--samples-per-step", type=int, default=1, help="Minari output: profile samples per step")
    p.add_argument("--data-format", choices=["hdf5", "arrow"], default="hdf5", help="Minari output storage")
    p.add_argument("--root", help="Minari output: datasets directory (default $MINARI_DATASETS_PATH)")
    p.set_defaults(fn=cmd_convert)
    p = sub.add_parser("export", help="write a data set in a community format (minari)")
    p.add_argument("target", choices=["minari"]); p.add_argument("input"); p.add_argument("dataset_id")
    p.add_argument("--samples-per-step", type=int, default=1, help="profile samples per Minari step")
    p.add_argument("--data-format", choices=["hdf5", "arrow"], default="hdf5")
    p.add_argument("--root", help="Minari datasets directory (default $MINARI_DATASETS_PATH or ~/.minari/datasets)")
    p.set_defaults(fn=cmd_export)
    p = sub.add_parser("serve", help="the web app with a local Python back end")
    p.add_argument("--host", default="127.0.0.1"); p.add_argument("--port", type=int, default=8765)
    p.add_argument("--open", action="store_true", help="open the browser"); p.add_argument("--no-cache", action="store_true")
    p.set_defaults(fn=cmd_serve)
    p = sub.add_parser("cache", help="size of the stage cache, or --clear it")
    p.add_argument("--clear", action="store_true"); p.add_argument("--cache-dir"); p.set_defaults(fn=cmd_cache)
    p = sub.add_parser("summarize", help="one leaderboard row from results.json"); p.add_argument("results")
    p.add_argument("-o", "--output"); p.set_defaults(fn=cmd_summarize)
    p = sub.add_parser("references", help="list the reference data"); p.add_argument("--bundle")
    p.set_defaults(fn=cmd_references)
    a = ap.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
