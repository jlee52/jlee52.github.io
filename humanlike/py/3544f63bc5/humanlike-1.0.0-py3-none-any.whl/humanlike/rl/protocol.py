"""Standard evaluation protocol and policy evaluation in one call (MuJoCo / Gymnasium environments).

    from humanlike.rl import evaluate_policy
    out = evaluate_policy(make_env, policy, body_map="humenv-smpl", protocol="locomotion-speed-v1")
    out["results"]          # humanlike.engine.evaluate: every analysis the data support
    out["dataset"]          # the recorded rollouts (minari_io.write saves them as a Minari dataset)

make_env(speed) returns a Gymnasium environment commanded to walk or run at `speed` m/s (how the command
is given is the environment's business); policy(obs) returns an action, and a policy with a reset()
method is reset at every episode. The protocol fixes what makes results comparable between models: the
commanded speeds, the rollouts per speed and their duration, and the start-up transient left out.

    locomotion-speed-v1         0.5-4.3 m/s in 0.2 m/s steps, 20 rollouts each, 20 s, the first 10 s left out
                                (the manuscript's rollouts)
    locomotion-speed-walk-v1    0.5-1.9 m/s (the speeds of the human references), otherwise as v1
    locomotion-speed-quick-v1   0.7, 1.1 and 1.5 m/s, 3 rollouts, 15 s, 5 s (development; not for comparisons)

conformance(ds, protocol) checks that a data set was recorded under a protocol (the leaderboard's entry
check; `humanlike validate DATA --protocol NAME`): every commanded speed with its rollouts, the duration of
the rollouts that did not fall, the transient left out, the physics-rate sampling, and the recording
checks (humanlike.rl.checks) on one rollout that did not fall at the slowest, middle and fastest speed.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Protocol:
    name: str
    speeds: tuple
    rollouts_per_speed: int
    seconds: float
    skip_s: float

    def describe(self) -> dict:
        return {"name": self.name, "speeds": [float(v) for v in self.speeds], "rollouts_per_speed": self.rollouts_per_speed,
                "seconds": self.seconds, "skip_s": self.skip_s}


PROTOCOLS = {p.name: p for p in (
    Protocol("locomotion-speed-v1", tuple(np.round(np.arange(0.5, 4.31, 0.2), 2)), 20, 20.0, 10.0),
    Protocol("locomotion-speed-walk-v1", tuple(np.round(np.arange(0.5, 1.91, 0.2), 2)), 20, 20.0, 10.0),
    Protocol("locomotion-speed-quick-v1", (0.7, 1.1, 1.5), 3, 15.0, 5.0),
)}


def protocol(spec) -> Protocol:
    if isinstance(spec, Protocol):
        return spec
    if spec not in PROTOCOLS:
        raise KeyError(f"unknown protocol {spec!r}; protocols: {', '.join(PROTOCOLS)}")
    return PROTOCOLS[spec]


def evaluate_policy(make_env, policy, body_map, protocol_spec="locomotion-speed-v1", name: str = "policy", seed: int = 0,
                    evaluate: bool = True, progress=None, check: bool = True, recorder_kw: dict | None = None,
                    **evaluate_kw) -> dict:
    """Roll out the policy under the protocol, record the profile signals at the physics rate
    (HumanlikeRecorder) and run the analyses. Returns {"protocol", "dataset", "results", "check"}.
    With check, the first episode that did not fall is checked (humanlike.rl.checks) and a failure stops
    the run before the remaining rollouts are spent on a wrong body map or floor."""
    from .recorder import HumanlikeRecorder
    p = protocol(protocol_spec)
    episodes, rec, report = [], None, None
    total, done = len(p.speeds) * p.rollouts_per_speed, 0
    for v in p.speeds:
        env = make_env(v)
        rec = HumanlikeRecorder(env, body_map, **(recorder_kw or {}))
        rec.episodes = episodes                          # one list across the speeds
        for r in range(p.rollouts_per_speed):
            obs, _ = rec.reset(seed=seed + done, options={"humanlike": {
                "id": f"v{v:.2f}_r{r:02d}", "group": f"{v:.2f}", "commanded_speed": float(v), "skip_s": p.skip_s}})
            if hasattr(policy, "reset"):
                policy.reset()
            steps = 0
            while True:
                obs, _, terminated, truncated, _ = rec.step(policy(obs))
                steps += 1
                if terminated or truncated:
                    break
                if steps * rec.k * rec.sample_dt >= p.seconds - 1e-9:
                    rec.end_episode()
                    break
            done += 1
            if check and report is None and episodes and not episodes[-1]["meta"].get("fell"):
                report = rec.check(-1, strict=True)
            if progress:
                progress(done, total, float(v))
        env.close()
    ds = rec.dataset(name)
    ds.meta.setdefault("dataset", {})["description"] = f"evaluation protocol {p.name}"
    out = {"protocol": p.describe(), "dataset": ds, "check": report}
    if evaluate:
        from ..engine import evaluate as run
        out["results"] = run(ds, **evaluate_kw)
    return out


def conformance(ds, protocol_spec, checks: bool = True):
    """Rows (name, "ok" | "fail" | "skip", message) of a humanlike.rl.checks.CheckReport: does the data set
    hold the protocol's rollouts? Falls are part of a model's result, so a fallen rollout counts towards
    its speed and may be shorter; every other rollout lasts the protocol's duration (one 30 Hz step of
    tolerance)."""
    from .checks import CheckReport, check_episode
    p = protocol(protocol_spec)
    r = CheckReport()
    add = lambda *row: r.rows.append(row)  # noqa: E731
    by = {}
    unset = [x.id for x in ds.rollouts if x.meta.get("commanded_speed") is None]
    for x in ds.rollouts:
        if x.meta.get("commanded_speed") is not None:
            by.setdefault(round(float(x.meta["commanded_speed"]), 2), []).append(x)
    want = {round(float(v), 2) for v in p.speeds}
    missing, extra = sorted(want - set(by)), sorted(set(by) - want)
    good = not (missing or extra or unset)
    add("speeds", "ok" if good else "fail", f"{len(want & set(by))} of {len(want)} commanded speeds" +
        (f"; missing {', '.join(f'{v:.2f}' for v in missing)}" if missing else "") +
        (f"; not in the protocol {', '.join(f'{v:.2f}' for v in extra)}" if extra else "") +
        (f"; {len(unset)} rollouts without commanded_speed" if unset else ""))
    short = {v: len(by.get(v, [])) for v in sorted(want) if len(by.get(v, [])) != p.rollouts_per_speed}
    add("rollouts per speed", "ok" if not short else "fail", f"{p.rollouts_per_speed} at each speed" if not short else
        "; ".join(f"{v:.2f} m/s: {n}" for v, n in short.items()) + f" (protocol: {p.rollouts_per_speed})")
    tol = 1 / 30 + 1e-6
    dur = [(x, len(x.arrays["pelvis_pos"]) / x.fs) for x in ds.rollouts if not x.meta.get("fell")]
    off = [(x.id, d) for x, d in dur if abs(d - p.seconds) > tol]
    add("duration", "ok" if not off else "fail", f"{p.seconds:g} s for the {len(dur)} rollouts that did not fall"
        if not off else f"{len(off)} rollouts do not last {p.seconds:g} s (e.g. {off[0][0]}: {off[0][1]:.2f} s)")
    sk = sorted({round(float(x.meta.get("skip_s", 0.0)), 6) for x in ds.rollouts})
    add("transient", "ok" if sk == [p.skip_s] else "fail", f"the first {p.skip_s:g} s left out" if sk == [p.skip_s]
        else f"skip_s {', '.join(f'{v:g}' for v in sk)} (protocol: {p.skip_s:g} s)")
    fs = sorted({x.fs for x in ds.rollouts})
    add("sample rate", "ok" if fs and fs[0] >= 100 else "fail", f"{', '.join(f'{f:.0f}' for f in fs)} Hz" +
        ("" if fs and fs[0] >= 100 else " (the protocol records at the physics rate, >= 100 Hz)"))
    fell = sum(bool(x.meta.get("fell")) for x in ds.rollouts)
    add("falls", "ok", f"{fell} of {len(ds.rollouts)} rollouts ({100 * fell / max(len(ds.rollouts), 1):.0f} %)")
    if not checks:
        return r
    speeds = sorted(by)
    picks = sorted({speeds[0], speeds[len(speeds) // 2], speeds[-1]}) if speeds else []
    for v in picks:
        x = next((x for x in by[v] if not x.meta.get("fell")), None)
        need = ("pelvis_pos", "left_foot_pos", "right_foot_pos", "left_grf", "right_grf")
        if x is None:
            add(f"recording {v:.2f} m/s", "skip", "every rollout fell")
        elif ds.mass is None or any(k not in x.arrays for k in need):
            add(f"recording {v:.2f} m/s", "skip", "no ground reaction forces or body mass")
        else:
            rep = check_episode(x.arrays, x.fs, ds.mass, ds.leg_length)
            bad = rep.failures()
            add(f"recording {v:.2f} m/s", "ok" if not bad else "fail", f"{x.id}: " + ("all checks pass" if not bad else
                "; ".join(f"{n}: {m}" for n, _, m in bad)))
    return r
