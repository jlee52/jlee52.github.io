"""Reinforcement-learning integration: record the profile signals from a running simulation and evaluate a
policy under a standard protocol.

    HumanlikeRecorder     Gymnasium wrapper for MuJoCo environments (physics-rate GRF, torques, sagittal joints)
    IsaacLabRecorder      vectorized recording for Isaac Lab environments
    BodyMap, PRESETS      where the pelvis, feet and sagittal joints are in the model
    evaluate_policy       roll out, record and analyse under a protocol (PROTOCOLS)

The recorders put each step's samples in info["humanlike"] / their episodes, in the layout of the Minari
mapping (humanlike.adapters.minari_io), so the data can be evaluated directly or saved as a Minari dataset.
"""
from .bodymap import PRESETS, BodyMap, bodymap
from .protocol import PROTOCOLS, Protocol, evaluate_policy, protocol

__all__ = ["BodyMap", "PRESETS", "bodymap", "Protocol", "PROTOCOLS", "protocol", "evaluate_policy",
           "HumanlikeRecorder", "IsaacLabRecorder"]


def __getattr__(name):                     # gymnasium and mujoco are imported only when a recorder is used
    if name == "HumanlikeRecorder":
        from .recorder import HumanlikeRecorder
        return HumanlikeRecorder
    if name == "IsaacLabRecorder":
        from .isaaclab import IsaacLabRecorder
        return IsaacLabRecorder
    raise AttributeError(name)
