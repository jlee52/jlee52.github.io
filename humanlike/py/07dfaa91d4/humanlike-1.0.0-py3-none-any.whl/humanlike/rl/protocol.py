"""Standard evaluation protocol and policy evaluation in one call (MuJoCo / Gymnasium environments).

    from humanlike.rl import evaluate_policy
    out = evaluate_policy(make_env, policy, body_map="humenv-smpl", protocol="locomotion-speed-v1")
    out["results"]          # humanlike.engine.evaluate: every analysis the data support
    out["dataset"]          # the recorded rollouts (minari_io.write saves them as a Minari dataset)

make_env(speed) returns a Gymnasium environment commanded to walk or run at `speed` m/s (how the command
is given is the environment's business); policy(obs) returns an action, and a policy with a reset()
method is reset at every episode. The protocol fixes what makes results comparable between models: the
commanded speeds, the rollouts per speed and their duration, and the start-up transient left out.

    locomotion-speed-v1         0.5-4.3 m/s in 0.2 m/s steps, 20 rollouts each, 20 s, the first 10 s left out
                                (the manuscript's rollouts)
    locomotion-speed-walk-v1    0.5-1.9 m/s (the speeds of the human references), otherwise as v1
    locomotion-speed-quick-v1   0.7, 1.1 and 1.5 m/s, 3 rollouts, 15 s, 5 s (development; not for comparisons)
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Protocol:
    name: str
    speeds: tuple
    rollouts_per_speed: int
    seconds: float
    skip_s: float

    def describe(self) -> dict:
        return {"name": self.name, "speeds": [float(v) for v in self.speeds], "rollouts_per_speed": self.rollouts_per_speed,
                "seconds": self.seconds, "skip_s": self.skip_s}


PROTOCOLS = {p.name: p for p in (
    Protocol("locomotion-speed-v1", tuple(np.round(np.arange(0.5, 4.31, 0.2), 2)), 20, 20.0, 10.0),
    Protocol("locomotion-speed-walk-v1", tuple(np.round(np.arange(0.5, 1.91, 0.2), 2)), 20, 20.0, 10.0),
    Protocol("locomotion-speed-quick-v1", (0.7, 1.1, 1.5), 3, 15.0, 5.0),
)}


def protocol(spec) -> Protocol:
    if isinstance(spec, Protocol):
        return spec
    if spec not in PROTOCOLS:
        raise KeyError(f"unknown protocol {spec!r}; protocols: {', '.join(PROTOCOLS)}")
    return PROTOCOLS[spec]


def evaluate_policy(make_env, policy, body_map, protocol_spec="locomotion-speed-v1", name: str = "policy", seed: int = 0,
                    evaluate: bool = True, progress=None, check: bool = True, recorder_kw: dict | None = None,
                    **evaluate_kw) -> dict:
    """Roll out the policy under the protocol, record the profile signals at the physics rate
    (HumanlikeRecorder) and run the analyses. Returns {"protocol", "dataset", "results", "check"}.
    With check, the first episode that did not fall is checked (humanlike.rl.checks) and a failure stops
    the run before the remaining rollouts are spent on a wrong body map or floor."""
    from .recorder import HumanlikeRecorder
    p = protocol(protocol_spec)
    episodes, rec, report = [], None, None
    total, done = len(p.speeds) * p.rollouts_per_speed, 0
    for v in p.speeds:
        env = make_env(v)
        rec = HumanlikeRecorder(env, body_map, **(recorder_kw or {}))
        rec.episodes = episodes                          # one list across the speeds
        for r in range(p.rollouts_per_speed):
            obs, _ = rec.reset(seed=seed + done, options={"humanlike": {
                "id": f"v{v:.2f}_r{r:02d}", "group": f"{v:.2f}", "commanded_speed": float(v), "skip_s": p.skip_s}})
            if hasattr(policy, "reset"):
                policy.reset()
            steps = 0
            while True:
                obs, _, terminated, truncated, _ = rec.step(policy(obs))
                steps += 1
                if terminated or truncated:
                    break
                if steps * rec.k * rec.sample_dt >= p.seconds - 1e-9:
                    rec.end_episode()
                    break
            done += 1
            if check and report is None and episodes and not episodes[-1]["meta"].get("fell"):
                report = rec.check(-1, strict=True)
            if progress:
                progress(done, total, float(v))
        env.close()
    ds = rec.dataset(name)
    ds.meta.setdefault("dataset", {})["description"] = f"evaluation protocol {p.name}"
    out = {"protocol": p.describe(), "dataset": ds, "check": report}
    if evaluate:
        from ..engine import evaluate as run
        out["results"] = run(ds, **evaluate_kw)
    return out
