"""Profile signals of a MuJoCo simulation, sampled after a physics step.

    pelvis_pos, left_foot_pos, right_foot_pos     body positions (m)
    left_grf, right_grf                           floor-on-foot force: the contact forces between the floor
                                                  geom(s) and the foot bodies (as humanlike.rollout.mujoco_logger)
    com_pos, com_vel                              whole-body centre of mass and its velocity
    joint_torque, joint_vel                       generalized actuator forces and velocities of every
                                                  degree of freedom except a free root joint
    sagittal_angles, sagittal_moments, sagittal_powers   the body map's hip, knee and ankle (deg, N m, W)

Sampling does not perturb the simulation: forces come from an extra mj_forward on the stepped state and
the solver warm start it overwrites is restored (as MujocoRolloutLogger; tests/test_rollout_logger.py).

Contacts that the ground reaction forces leave out are counted in `diagnostics` for the recorders'
check(): feet touching geoms outside the robot that are not the floor (terrain not named in the body
map), and other robot bodies touching the floor (knees, hands, a fall). The diagnostics also hold what
the sagittal sign checks need: the mean world axes of the sagittal joints, the orientations of the
pelvis, thigh, shank and foot (at ~50 Hz) and the direction the feet point at the first sample.
"""
from __future__ import annotations

import numpy as np

from .bodymap import BodyMap, bodymap


def _names(model, objtype, n):
    import mujoco
    return [mujoco.mj_id2name(model, objtype, i) for i in range(n)]


def _lookup(model, kind, name):
    import mujoco
    try:
        return getattr(model, kind)(name)
    except KeyError:
        objtype, n = {"body": (mujoco.mjtObj.mjOBJ_BODY, model.nbody), "joint": (mujoco.mjtObj.mjOBJ_JOINT, model.njnt),
                      "geom": (mujoco.mjtObj.mjOBJ_GEOM, model.ngeom)}[kind]
        names = [x for x in _names(model, objtype, n) if x]
        hint = ' (or floor="world": every geom that is not part of the robot)' if kind == "geom" else ""
        raise KeyError(f"no {kind} {name!r} in the model{hint}; {kind}s: {', '.join(names[:80])}"
                       + (" ..." if len(names) > 80 else "")) from None


class MujocoExtractor:
    def __init__(self, model, data, body_map):
        import mujoco
        self.mj, self.model, self.data = mujoco, model, data
        self.map: BodyMap = bodymap(body_map)
        m = self.map
        bid = lambda n: _lookup(model, "body", n).id  # noqa: E731
        self.pelvis, self.lfoot, self.rfoot = bid(m.pelvis), bid(m.left_foot[0]), bid(m.right_foot[0])
        self.feet = {"L": {bid(n) for n in m.left_foot}, "R": {bid(n) for n in m.right_foot}}
        root = int(model.body_rootid[self.pelvis])
        self.robot_geom = model.body_rootid[model.geom_bodyid] == root           # [ngeom] geoms of the robot
        if m.floor == "world":
            self.floor = set(np.flatnonzero(~self.robot_geom).tolist())
        else:
            names = (m.floor,) if isinstance(m.floor, str) else tuple(m.floor)
            self.floor = {_lookup(model, "geom", n).id for n in names}
        self.foot_of = {b: k for k, ids in self.feet.items() for b in ids}
        free = [j for j in range(model.njnt) if model.jnt_type[j] == mujoco.mjtJoint.mjJNT_FREE]
        root = {int(model.jnt_dofadr[j]) + k for j in free for k in range(6)}
        self.dofs = np.array([i for i in range(model.nv) if i not in root], int)
        if m.sagittal:
            joints = [_lookup(model, "joint", m.sagittal[k][0]) for k in ("hip", "knee", "ankle")]
            self.sag_q = np.array([int(j.qposadr[0]) for j in joints])
            self.sag_v = np.array([int(j.dofadr[0]) for j in joints])
            self.sag_sign = np.array([m.sagittal[k][1] for k in ("hip", "knee", "ankle")], float)
            self.sag_jnt = np.array([int(j.id) for j in joints])
            if m.segments:
                self.seg = np.array([bid(m.segments[k]) for k in ("pelvis", "thigh", "shank", "foot")])
            else:                                             # the body of each joint; the thigh's parent
                thigh, shank, foot = (int(model.jnt_bodyid[j]) for j in self.sag_jnt)
                self.seg = np.array([int(model.body_parentid[thigh]), thigh, shank, foot])
        self.mass = float(model.body_subtreemass[0])
        self.dt = float(model.opt.timestep)
        self.seg_stride = max(1, round(1.0 / (50.0 * self.dt)))
        self.reset_diagnostics()

    def sample(self) -> dict:
        mj, m, d = self.mj, self.model, self.data
        ws = d.qacc_warmstart.copy()
        mj.mj_forward(m, d)
        mj.mj_subtreeVel(m, d)
        d.qacc_warmstart[:] = ws
        if self.map.sagittal:
            self._kinematics()
        force = self._grf()
        out = {"pelvis_pos": d.xpos[self.pelvis].copy(), "left_foot_pos": d.xpos[self.lfoot].copy(),
               "right_foot_pos": d.xpos[self.rfoot].copy(), "left_grf": force["L"], "right_grf": force["R"],
               "com_pos": d.subtree_com[0].copy(), "com_vel": d.subtree_linvel[0].copy(),
               "joint_torque": d.qfrc_actuator[self.dofs].copy(), "joint_vel": d.qvel[self.dofs].copy()}
        if self.map.sagittal:
            tau = d.qfrc_actuator[self.sag_v]
            out.update(sagittal_angles=np.degrees(d.qpos[self.sag_q]) * self.sag_sign, sagittal_moments=tau * self.sag_sign,
                       sagittal_powers=tau * d.qvel[self.sag_v])
        return out

    def reset_diagnostics(self):
        self.diagnostics = {"samples": 0, "unlisted_foot_contact": 0, "unlisted_foot_force_max": 0.0,
                            "unlisted_geoms": set(), "non_foot_floor_contact": 0, "non_foot_fz": 0.0,
                            "non_foot_bodies": set(), "sagittal_axis_sum": np.zeros((3, 3)), "segment_rot": [],
                            "segment_stride": self.seg_stride, "forward_hint": None, "sagittal_signs": None}
        if self.map.sagittal:
            self.diagnostics["sagittal_signs"] = self.sag_sign.copy()

    def _kinematics(self):
        d, dg = self.data, self.diagnostics
        dg["sagittal_axis_sum"] += d.xaxis[self.sag_jnt]
        if dg["samples"] % self.seg_stride == 0:
            dg["segment_rot"].append(d.xmat[self.seg].reshape(4, 3, 3).copy())
        if dg["forward_hint"] is None:                         # where the feet point (mean of both feet)
            f = sum(d.subtree_com[b] - d.xpos[b] for b in (self.lfoot, self.rfoot))
            f[2] = 0.0
            dg["forward_hint"] = f / np.linalg.norm(f) if np.linalg.norm(f) > 1e-9 else None

    def _grf(self) -> dict:
        """Floor-on-foot force per foot (world frame); contacts it leaves out go to the diagnostics."""
        mj, m, d = self.mj, self.model, self.data
        f6 = np.zeros(6)
        force = {"L": np.zeros(3), "R": np.zeros(3)}
        unlisted, non_foot = 0.0, 0.0
        for i in range(d.ncon):
            c = d.contact[i]
            g1, g2 = int(c.geom1), int(c.geom2)
            if g1 in self.floor and g2 not in self.floor:
                g, sign = g2, 1.0                    # mj_contactForce: force of geom1 on geom2
            elif g2 in self.floor and g1 not in self.floor:
                g, sign = g1, -1.0
            else:
                for g, o in ((g1, g2), (g2, g1)):               # a foot on something that is not the floor
                    if self.robot_geom[g] and not self.robot_geom[o] and m.geom_bodyid[g] in self.foot_of:
                        mj.mj_contactForce(m, d, i, f6)
                        unlisted = max(unlisted, abs(float(f6[0])))
                        self.diagnostics["unlisted_geoms"].add(mj.mj_id2name(m, mj.mjtObj.mjOBJ_GEOM, o) or f"geom {o}")
                continue
            mj.mj_contactForce(m, d, i, f6)
            f = sign * (c.frame.reshape(3, 3).T @ f6[:3])
            label = self.foot_of.get(int(m.geom_bodyid[g]))
            if label is None:
                if self.robot_geom[g]:
                    non_foot += float(f[2])
                    self.diagnostics["non_foot_bodies"].add(mj.mj_id2name(m, mj.mjtObj.mjOBJ_BODY, int(m.geom_bodyid[g])))
                continue
            force[label] += f
        dg = self.diagnostics
        dg["samples"] += 1
        dg["non_foot_floor_contact"] += int(non_foot != 0.0)
        dg["non_foot_fz"] += non_foot
        if unlisted > 0:
            dg["unlisted_foot_contact"] += 1
            dg["unlisted_foot_force_max"] = max(dg["unlisted_foot_force_max"], unlisted)
        return force

    def meta(self) -> dict:
        return {"mass_kg": self.mass, "up": "z", "sagittal_side": self.map.side if self.map.sagittal else None,
                "leg_length_m": self.map.leg_length_m, "simulator": f"MuJoCo {self.mj.__version__}"}
