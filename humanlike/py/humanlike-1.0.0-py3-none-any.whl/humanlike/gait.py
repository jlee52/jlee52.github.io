"""Standard stride parameters and gait cycles, the same for every data set (simulation or motion capture).

For each stride of the reference foot, from one foot strike (sample a) to the next (sample b):
    direction        horizontal pelvis displacement from a to b (the walking direction of the stride)
    stride length    horizontal displacement of the reference foot from a to b, projected on it
    speed            mean horizontal pelvis speed over a..b (central differences of the positions)
    stride frequency speed / stride length
    gait cycle       samples a..b, both strikes included (0 % and 100 %), resampled to 101 points
Strides with a masked sample in [a, b) (turns, excluded intervals) or fewer than 3 samples are
skipped. A rollout is summarised by the mean speed and stride length and the mean of the per-stride
frequencies; its mean gait cycle and its speed are taken over the same strides.

The published analyses used other definitions: the MimicKit models (AMP, SMP) ended the stride
one sample before the next strike and used the 3D root speed; the loco-benchmark data (BFMs, AMASS,
KIT, KINESIS) took the stride length in the pelvis frame at the strike and the 3D centre-of-mass
speed; gait cycles of the models ended one sample before the next strike, and the speed attached to
a cycle-averaged trajectory was the rollout's mean root speed or, for the BFMs, the commanded speed.
This module replaces all of them.
"""
from __future__ import annotations

import numpy as np
from scipy.interpolate import interp1d

CYCLE_POINTS = 101


def _horizontal(up: int):
    return [i for i in range(3) if i != up]


def valid_strides(heel_strikes, n_samples: int, mask=None, min_samples: int = 3):
    """(a, b) sample pairs of consecutive strikes without a masked sample in [a, b)."""
    hs = np.asarray(heel_strikes, int)
    m = np.zeros(n_samples, bool) if mask is None else np.asarray(mask, bool)
    return [(int(a), int(b)) for a, b in zip(hs[:-1], hs[1:]) if b - a >= min_samples and b < n_samples and not m[a:b].any()]


def stride_speed(pelvis, a: int, b: int, fs: float, up: int = 2, vel=None) -> float:
    """Mean horizontal pelvis speed over samples a..b (vel: precomputed horizontal velocity)."""
    if vel is None:
        vel = np.gradient(np.asarray(pelvis, float)[:, _horizontal(up)], 1 / fs, axis=0)
    return float(np.linalg.norm(vel[a:b + 1], axis=1).mean())


def cycle(x, a: int, b: int, n: int = CYCLE_POINTS, kind: str = "cubic"):
    """Samples a..b of x (first axis: time), both foot strikes included, resampled to n points."""
    seg = np.asarray(x, float)[a:b + 1]
    kind = kind if len(seg) > 3 else "linear"
    return interp1d(np.linspace(0, 100, len(seg)), seg, axis=0, kind=kind)(np.linspace(0, 100, n))


def strides(pelvis, foot, heel_strikes, fs, up: int = 2, mask=None, min_samples: int = 3, return_pairs: bool = False):
    """Per-stride (speed, stride length) arrays, positions [T, 3] in metres."""
    P, F = np.asarray(pelvis, float), np.asarray(foot, float)
    h = _horizontal(up)
    vel = np.gradient(P[:, h], 1 / fs, axis=0)
    sp, ln, pairs = [], [], []
    for a, b in valid_strides(heel_strikes, len(P), mask, min_samples):
        disp = P[b, h] - P[a, h]
        nd = np.linalg.norm(disp)
        if nd == 0:
            continue
        length = abs(np.dot(F[b, h] - F[a, h], disp / nd))
        if length == 0:
            continue
        sp.append(stride_speed(P, a, b, fs, up, vel))
        ln.append(length)
        pairs.append((a, b))
    out = (np.array(sp), np.array(ln))
    return (*out, pairs) if return_pairs else out


def summary(pelvis, foot, heel_strikes, fs, up: int = 2, mask=None) -> dict | None:
    """Rollout summary: speed, stride_length, stride_frequency, strides (None without a stride)."""
    sp, ln = strides(pelvis, foot, heel_strikes, fs, up, mask)
    if not len(sp):
        return None
    return {"speed": float(sp.mean()), "stride_length": float(ln.mean()),
            "stride_frequency": float((sp / ln).mean()), "strides": int(len(sp))}


def mean_cycle(x, pelvis, heel_strikes, fs, up: int = 2, mask=None, kind: str = "cubic"):
    """(mean gait cycle [101, ...], mean stride speed, number of strides) over the valid strides of a
    trajectory, or None without one. The foot only defines the strikes, so no stride-length test."""
    P = np.asarray(pelvis, float)
    vel = np.gradient(P[:, _horizontal(up)], 1 / fs, axis=0)
    pairs = valid_strides(heel_strikes, len(P), mask)
    if not pairs:
        return None
    cyc = np.mean([cycle(x, a, b, kind=kind) for a, b in pairs], 0)
    return cyc, float(np.mean([stride_speed(P, a, b, fs, up, vel) for a, b in pairs])), len(pairs)
