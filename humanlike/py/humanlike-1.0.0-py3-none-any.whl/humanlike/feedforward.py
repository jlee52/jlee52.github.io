"""Feedforward signature: divergence of speed-dependent stride profiles.

Manuscript: 2D Gaussian KDE of (speed, stride length) or (speed, stride frequency) for
human/expert data (H) and model data (M); JS divergence to the mixture M = (p_H + p_M)/2,
reported in bits. Each KL term is a Monte-Carlo estimate over that distribution's own samples.
"""
from __future__ import annotations

import numpy as np
from scipy.stats import gaussian_kde

EPS = 1e-12   # guards log(0)


def _clean(x, y):
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    m = np.isfinite(x) & np.isfinite(y)
    return np.vstack([x[m], y[m]])


def kde_divergences(ref_x, ref_y, sim_x, sim_y, bw_method=None) -> dict:
    """Bidirectional KL (nats), Jeffreys (nats) and JS (bits) between KDE densities.

    ref_*: human / expert reference samples (H); sim_*: model samples (M).
    bw_method: passed to scipy.stats.gaussian_kde (None = Scott's rule, as in the paper).
    """
    H, M = _clean(ref_x, ref_y), _clean(sim_x, sim_y)
    kde_h, kde_m = gaussian_kde(H, bw_method), gaussian_kde(M, bw_method)
    ph_H, pm_H = kde_h(H), kde_m(H)      # densities at reference samples
    pm_M, ph_M = kde_m(M), kde_h(M)      # densities at model samples

    log = lambda p: np.log(p + EPS)
    kl_m_h = np.mean(log(pm_M) - log(ph_M))
    kl_h_m = np.mean(log(ph_H) - log(pm_H))
    js_nats = 0.5 * (np.mean(log(ph_H) - log(0.5 * (ph_H + pm_H)))
                     + np.mean(log(pm_M) - log(0.5 * (pm_M + ph_M))))
    return {"kl_m_h": float(kl_m_h), "kl_h_m": float(kl_h_m),
            "jeffreys": float(kl_m_h + kl_h_m), "js_bits": float(js_nats / np.log(2)),
            "n_ref": H.shape[1], "n_sim": M.shape[1]}


def js_divergence(ref_x, ref_y, sim_x, sim_y, bw_method=None) -> float:
    """JS divergence in bits (0 = identical, 1 = disjoint)."""
    return kde_divergences(ref_x, ref_y, sim_x, sim_y, bw_method)["js_bits"]
