"""The analyses of the benchmark as engine stages. Each wraps the metric functions used for the
manuscript (feedforward, footplacement, feedback, energetics, stats), applied to an HLB data set.

    events          foot strikes of both feet (given, or detected: humanlike.events)
    gait_summary    per rollout: speed, stride length and frequency (left-foot strides)
    gait_scaling    feedforward signature: JS divergence of the speed-stride length and
                    speed-stride frequency densities from each gait reference
    foot_placement  phase-resolved foot-placement regression per group (session or subject)
    feedback        feedback signature: FPGD from each feedback reference; peak relative
                    predictive power and its timing, compared with the reference
    energetics      mechanical cost of transport per rollout and the two-Gaussian classification
    gait_phases     double support, single support and flight fractions from the foot GRFs
    sagittal        sagittal hip, knee and ankle angles against the human reference at each speed
    kinetic_principles
                    per-stride GRF, joint-work and centre-of-mass features (humanlike.kinetics)
                    against the 16 predictions of six principles of human walking
                    (humanlike.principles), with the human reference evaluated alongside
"""
from __future__ import annotations

import numpy as np

from .engine import stage
from .events import foot_strikes, heading
from .feedforward import kde_divergences

G = 9.80665
CONTACT_BW = 0.05


def _skip_samples(r) -> int:
    return int(round(float(r.meta.get("skip_s", 0) or 0) * r.fs))


def _usable(ds):
    return [r for r in ds.rollouts if not r.meta.get("fell", False)]


def _pelvis_vel(r) -> np.ndarray:
    if "pelvis_vel" in r.arrays:
        return np.asarray(r.arrays["pelvis_vel"], float)
    return np.gradient(np.asarray(r.arrays["pelvis_pos"], float), 1 / r.fs, axis=0)


@stage("events", "Foot strikes", needs=("core",))
def events(ctx):
    up, ev, detected = ctx.ds.up, {}, 0
    for r in _usable(ctx.ds):
        p = np.asarray(r.arrays["pelvis_pos"], float)
        d = heading(p, up)
        out = {}
        for side in ("left", "right"):
            key = f"{side}_heel_strikes"
            if key in r.arrays:
                hs = np.asarray(r.arrays[key], int)
            else:
                hs = foot_strikes(p, r.arrays[f"{side}_foot_pos"], r.fs, up, d); detected += 1
            out[side] = hs[hs >= _skip_samples(r)]
        ev[r.id] = {"direction": d, **out}
    ctx.cache["events"] = ev
    n = [len(e["left"]) - 1 for e in ev.values()]
    return {"rollouts": len(ev), "strides_left": int(np.sum(np.maximum(n, 0))),
            "detected": detected > 0, "excluded_fell": len(ctx.ds.rollouts) - len(ev)}


@stage("gait_summary", "Speed and stride parameters", needs=("core",), after=("events",), options=("definition",))
def gait_summary(ctx):
    """Per rollout, over its left-foot strides: speed, stride length and frequency (humanlike.gait).

    definition "standard" (default): humanlike.gait (stride from strike to strike along the stride's
    walking direction, horizontal pelvis speed from the positions). definition "legacy-mimickit":
    the MimicKit pipeline of the first submission (stride ends one sample early, 3D pelvis velocity
    resampled to 101 points), kept to compare with those values."""
    from .gait import summary
    legacy = ctx.options.get("definition", "standard") == "legacy-mimickit"
    rows = []
    for r in _usable(ctx.ds):
        e = ctx.cache["events"][r.id]
        hs = e["left"]
        if len(hs) < 2:
            continue
        if legacy:
            res = _legacy_mimickit_summary(r, e, ctx.ds.up)
        else:
            res = summary(r.arrays["pelvis_pos"], r.arrays["left_foot_pos"], hs, r.fs, ctx.ds.up)
        if res is None:
            continue
        rows.append({"rollout": r.id, "group": r.meta["group"], "commanded_speed": r.meta.get("commanded_speed"), **res})
    if not rows:
        return {"skipped": "no rollout has two foot strikes of the left foot"}
    ctx.cache["gait"] = {k: np.array([x[k] for x in rows], float) for k in ("speed", "stride_length", "stride_frequency")}
    return {"definition": "legacy-mimickit" if legacy else "standard", "rollouts": rows}


def _legacy_mimickit_summary(r, e, up):
    from scipy.interpolate import interp1d
    hs = e["left"]
    foot = np.asarray(r.arrays["left_foot_pos"], float) @ e["direction"]
    vel = _pelvis_vel(r)
    sp, ln = [], []
    for a, b in zip(hs[:-1], hs[1:]):
        v = vel[a:b]
        v = interp1d(np.linspace(0, 100, len(v)), v, axis=0, kind="cubic")(np.linspace(0, 100, 101))
        sp.append(np.linalg.norm(v, axis=1).mean())
        ln.append(abs(foot[b - 1] - foot[a]))
    sp, ln = np.array(sp), np.array(ln)
    ok = ln > 0
    if not ok.any():
        return None
    return {"speed": float(sp[ok].mean()), "stride_length": float(ln[ok].mean()),
            "stride_frequency": float((sp[ok] / ln[ok]).mean()), "strides": int(ok.sum())}


@stage("gait_scaling", "Feedforward signature", needs=("core",), after=("gait_summary",), refs=("gait",))
def gait_scaling(ctx):
    if ctx.bundle is None:
        return {"skipped": "no reference bundle"}
    g = ctx.cache["gait"]
    out = {}
    for name in ctx.references.get("gait", []):
        ref = ctx.bundle.get(name)
        R = ref.data
        sel = np.ones(len(g["speed"]), bool)
        if ref.meta.get("restrict_speed"):
            sel = (g["speed"] >= R["speeds"].min()) & (g["speed"] <= R["speeds"].max())
        if sel.sum() < 5:
            out[name] = {"skipped": f"only {int(sel.sum())} rollouts within the reference speed range"}
            continue
        res = {"n": int(sel.sum()), "speed_range": [float(R["speeds"].min()), float(R["speeds"].max())]
               if ref.meta.get("restrict_speed") else None}
        for feat, key in (("stride_length", "stride_lengths"), ("stride_frequency", "stride_frequencies")):
            res[f"js_{feat}"] = kde_divergences(R["speeds"], R[key], g["speed"][sel], g[feat][sel])["js_bits"]
        res["reference"] = {k: R[k] for k in ("speeds", "stride_lengths", "stride_frequencies")}
        out[name] = res
    return out


@stage("foot_placement", "Foot-placement control model", needs=("core",), after=("events",))
def foot_placement(ctx):
    from .footplacement import from_trajectories
    trajs = []
    for r in _usable(ctx.ds):
        e = ctx.cache["events"][r.id]
        trajs.append(dict(group=r.meta["group"], pelvis=r.arrays["pelvis_pos"], l_foot=r.arrays["left_foot_pos"],
                          r_foot=r.arrays["right_foot_pos"], l_heel_strikes=e["left"], r_heel_strikes=e["right"]))
    groups = sorted({t["group"] for t in trajs}, key=str)
    gid = {g: i for i, g in enumerate(groups)}
    for t in trajs:
        t["group"] = gid[t["group"]]
    fps = {r.fs for r in _usable(ctx.ds)}
    if len(fps) != 1:
        return {"skipped": "rollouts have different sampling rates"}
    fc = from_trajectories(trajs, dt=1 / fps.pop())
    ctx.cache["ft_ctl"] = fc
    return {"groups": [str(g) for g in groups], "gains": fc["gains"], "ctl_mag": fc["ctl_mag"]}


@stage("feedback", "Feedback signature", needs=("core",), after=("foot_placement",), refs=("feedback",))
def feedback(ctx):
    from .feedback import fpgd, peak_delta_r2
    from .stats import compare_groups
    if ctx.bundle is None:
        return {"skipped": "no reference bundle"}
    fc = ctx.cache["ft_ctl"]
    mag, tau = peak_delta_r2(fc["ctl_mag"])
    out = {"peak_dr2": mag, "peak_timing": tau, "references": {}}
    for name in ctx.references.get("feedback", []):
        R = ctx.bundle.get(name).data
        v = fpgd(R["gains"], fc["gains"])
        rm, rt = peak_delta_r2(R["ctl_mag"])
        cmp = {}
        for key, a, b in (("peak_dr2", mag, rm), ("peak_timing", tau, rt)):
            if len(a) >= 2 and len(b) >= 2:
                st = compare_groups({"model": a, "reference": b})
                ph = st["posthoc"].iloc[0]
                cmp[key] = {"model_mean": float(np.mean(a)), "reference_mean": float(np.mean(b)),
                            "diff": float(np.mean(a) - np.mean(b)), "p": float(ph["pval"]), "cohen_d": float(ph["cohen_d"])}
        out["references"][name] = {"fpgd": v, "fpgd_mean": float(np.mean(v)), "fpgd_sd": float(np.std(v, ddof=1)) if len(v) > 1 else None,
                                   "reference_peak_dr2": rm, "reference_peak_timing": rt, "comparison": cmp}
    return out


@stage("energetics", "Energetic signature", needs=("core", "energetics"), after=("gait_summary",))
def energetics(ctx):
    from .energetics import classify_cot, fit_cot, mechanical_cot
    mass = ctx.ds.mass
    speeds, cots = [], []
    summary = {x["rollout"]: x for x in ctx.results["gait_summary"]["rollouts"]}
    for r in _usable(ctx.ds):
        if r.id not in summary:
            continue
        s = _skip_samples(r)
        p = np.abs(np.asarray(r.arrays["joint_torque"], float) * np.asarray(r.arrays["joint_vel"], float)).sum(1)[s:]
        cots.append(mechanical_cot(p, 1 / r.fs, np.asarray(r.arrays["pelvis_pos"], float)[s:], mass))
        speeds.append(summary[r.id]["speed"])
    speeds, cots = np.array(speeds), np.array(cots)
    try:
        fit = fit_cot(speeds, cots)
    except (RuntimeError, ValueError):
        fit = None
    label, reason = classify_cot(fit)
    return {"speed": speeds, "cot": cots, "fit": fit, "label": label, "reason": reason}


@stage("gait_phases", "Phases of the stride", needs=("core", "kinetics"), after=("events",))
def gait_phases(ctx):
    bw = (ctx.ds.mass or 0) * G
    rows = []
    for r in _usable(ctx.ds):
        e = ctx.cache["events"][r.id]
        hs = e["left"]
        if len(hs) < 2:
            continue
        fl = np.asarray(r.arrays["left_grf"], float)[:, ctx.ds.up] > CONTACT_BW * bw
        fr = np.asarray(r.arrays["right_grf"], float)[:, ctx.ds.up] > CONTACT_BW * bw
        a, b = hs[0], hs[-1]
        both, none = (fl & fr)[a:b], ~(fl | fr)[a:b]
        rows.append({"rollout": r.id, "double_support": float(both.mean()), "flight": float(none.mean()),
                     "single_support": float(1 - both.mean() - none.mean())})
    if not rows:
        return {"skipped": "no rollout has two foot strikes of the left foot"}
    agg = {k: float(np.median([x[k] for x in rows])) for k in ("double_support", "single_support", "flight")}
    agg["rollouts_with_flight"] = float(np.mean([x["flight"] > 0.01 for x in rows]))
    return {"rollouts": rows, "median": agg}


@stage("sagittal", "Sagittal joint angles", needs=("core", "sagittal"), after=("gait_summary",), refs=("sagittal",))
def sagittal_angles(ctx):
    """Each rollout's mean gait cycle of the sagittal hip, knee and ankle angles (cycles of the foot of
    dataset.sagittal_side, left by default, from
    strike to strike inclusive, humanlike.gait), compared with the human reference at the speed of
    the same strides: eight
    features (humanlike.sagittal.FEATURES; median difference and robust z, consistent if
    |median z| <= 2) and the shape distance after range-of-motion normalization."""
    from .gait import mean_cycle
    from .principles import SpeedModel, Z_MAX
    from .sagittal import FEATURES, JOINTS, features, human_table, rom_normalize
    if ctx.bundle is None:
        return {"skipped": "no reference bundle"}
    name = ctx.references.get("sagittal", [None])[0]
    hum = ctx.bundle.get(name).data
    lo, hi = float(hum["speed"].min()) - .025, float(hum["speed"].max()) + .025
    cycles, sp = [], []
    for r in _usable(ctx.ds):
        hs = ctx.cache["events"][r.id][ctx.ds.side]
        if "sagittal_angles" not in r.arrays or len(hs) < 2:
            continue
        res = mean_cycle(r.arrays["sagittal_angles"], r.arrays["pelvis_pos"], hs, r.fs, ctx.ds.up)
        if res is None or not lo <= res[1] <= hi:
            continue
        cycles.append(res[0]); sp.append(res[1])
    if len(cycles) < 3:
        return {"skipped": f"only {len(cycles)} rollouts within the human speed range ({lo:.2f}-{hi:.2f} m/s)"}
    C, sp = np.array(cycles), np.array(sp)
    H = human_table(hum)
    feats = features(C)
    out = {"n": len(C), "speed": sp, "mean_cycle": C.mean(0), "features": {}}
    for k, (label, unit) in FEATURES.items():
        ref = SpeedModel(H.speed.to_numpy(), H[k].to_numpy())
        mu, sd = ref(sp)
        d, z = feats[k] - mu, (feats[k] - mu) / sd
        out["features"][k] = {"label": label, "unit": unit, "value": feats[k], "median_diff": float(np.median(d)),
                              "median_z": float(np.median(z)), "consistent": bool(abs(np.median(z)) <= Z_MAX)}
    # waveform shape after range-of-motion normalization, against the human mean shape at the nearest speed
    A = rom_normalize(hum["angles"].astype(float))
    okh = np.isfinite(A).all(axis=(2, 3)) & (hum["n_strides"] >= 3)
    mean_shape = np.stack([A[okh[:, k], k].mean(0) for k in range(len(hum["speed"]))])
    near = np.abs(sp[:, None] - hum["speed"][None]).argmin(1)
    dist = 100 * np.sqrt(np.mean((rom_normalize(C) - mean_shape[near]) ** 2, axis=1))
    out["shape_distance"] = {j: {"median": float(np.median(dist[:, i]))} for i, j in enumerate(JOINTS)}
    out["consistent_features"] = int(sum(v["consistent"] for v in out["features"].values()))
    return out


def _horizontal_last(ds):
    """Column order putting the two horizontal axes first and the vertical one last."""
    return [i for i in range(3) if i != ds.up] + [ds.up]


@stage("kinetic_principles", "Kinetic gait and biomechanical principles", needs=("core", "kinetics"), after=("events",),
       refs=("kinetics",))
def kinetic_principles(ctx):
    """Per stride of the reference foot (dataset.sagittal_side; strides found from its vertical GRF as
    in force-plate data): GRF, joint-work and centre-of-mass features (humanlike.kinetics), averaged per
    rollout over the strides in the human speed range and tested against the predictions of
    humanlike.principles; the human reference is evaluated with the same criteria. Without
    sagittal_moments the joint-work predictions (P2, P3) are n/a; without com_pos / com_vel the centre
    of mass of each stride is obtained by integrating the total GRF, as for the force-plate data of the
    human reference. With subject.leg_length_m, work and impulse are made dimensionless (Hof 1996)
    for the model and the human reference; otherwise both stay per kilogram."""
    from .kinetics import G as GK, rollout_strides
    from .principles import PREDICTIONS, PRINCIPLES, evaluate, summary
    if ctx.bundle is None:
        return {"skipped": "no reference bundle"}
    name = ctx.references.get("kinetics", ["camargo-treadmill/kinetics"])[0]
    ref = ctx.bundle.get(name).data
    m = ctx.ds.mass
    side = ctx.ds.side
    other = "right" if side == "left" else "left"
    ax = _horizontal_last(ctx.ds)
    F, R, ids, joint = [], [], [], False
    for r in _usable(ctx.ds):
        A = r.arrays
        fs = r.fs
        gs = np.asarray(A[f"{side}_grf"], float)[:, ax] / (m * GK)
        go = np.asarray(A[f"{other}_grf"], float)[:, ax] / (m * GK)
        P = np.asarray(A["pelvis_pos"], float)[:, ax]
        if "com_pos" in A or "com_vel" in A:
            C = np.asarray(A["com_pos"], float)[:, ax] if "com_pos" in A else None
            V = np.asarray(A["com_vel"], float)[:, ax] if "com_vel" in A else np.gradient(C, 1 / fs, axis=0)
            if C is None:
                C = P + np.cumsum(V - V.mean(0), 0) / fs
            zc = C[:, 2]
        else:                                                  # COM from the GRF, as the human reference
            V = zc = None
        if "sagittal_moments" in A:
            joint = True
            M = np.asarray(A["sagittal_moments"], float)
            W = np.asarray(A["sagittal_powers"], float) if "sagittal_powers" in A else \
                M * np.gradient(np.radians(np.asarray(A["sagittal_angles"], float)), 1 / fs, axis=0)
            M, W = M / m, W / m
        else:
            M = W = np.full((len(P), 3), np.nan)
        rows, _ = rollout_strides(gs[:, 2], gs[:, :2], V, M, W, fs, fs, _skip_samples(r), None,
                                  (gs + go)[:, :2], np.stack([gs, go], 1), zc, P)
        if rows:
            F += rows; R += [len(ids)] * len(rows); ids.append(r.id)
    if not F:
        return {"skipped": f"no stride of the {side} foot found from its vertical GRF"}
    model = {"features": np.array(F, float), "stride_rollout": np.array(R)}
    legs = None
    if ctx.ds.leg_length and "leg_length" in ref:
        legs = {"human": dict(zip(map(str, ref["subject"]), map(float, ref["leg_length"]))),
                "models": {ctx.ds.name: ctx.ds.leg_length}}
    hum = {k: ref[k] for k in ("features", "stride_subject", "stride_bin", "subject")}
    out = evaluate(hum, {ctx.ds.name: model}, legs=legs)
    T = out["tests"]
    text = {p.key: p.text for p in PREDICTIONS}
    rows = []
    for _, t in T[T.group == ctx.ds.name].iterrows():
        h = T[(T.group == "Human") & (T.key == t.key)].iloc[0]
        rows.append({"principle": t.principle, "key": t.key, "prediction": text[t.key], "kind": t.kind,
                     "value": t.value, "ci_low": t.ci_low, "ci_high": t.ci_high, "human_value": h.value,
                     "consistent": None if t.consistent is None or (isinstance(t.consistent, float) and np.isnan(t.consistent))
                     else bool(t.consistent), "p_holm": t.p_holm})
    valid = [x for x in rows if x["consistent"] is not None]
    by = summary(T)[ctx.ds.name].to_dict()
    return {"reference": name, "foot": side, "normalized": legs is not None, "joint_kinetics": joint,
            "rollouts": len(ids), "strides": len(F), "human_range": list(out["human_range"]),
            "consistent": int(sum(x["consistent"] for x in valid)), "evaluated": len(valid),
            "by_principle": {k: {"title": PRINCIPLES[k], "score": v} for k, v in by.items()},
            "predictions": rows}

