"""Kinetic gait against established biomechanical principles of human walking.

Each principle is turned into predictions that hold in human walking and can be checked in every
model (Camargo et al. 2021 treadmill data as the human reference, models' rollouts within the human
speed range). Sources, cross-checked against the papers (abstracts; full text where available):

  P1 step-to-step transition: trailing-leg push-off and leading-leg collision work on the COM in double
     support, both increasing with speed (Donelan, Kram & Kuo 2002, J Biomech: positive 13.7 -> 23.8 J,
     negative 6.5 -> 26.8 J per step from 0.75 to 2.0 m/s; Kuo & Donelan 2010); double support shortens
     with speed (Hebenstreit et al. 2015)
  P2 ankle push-off: a burst of ankle positive work late in stance that grows with speed (Winter 1983;
     Browne & Franz 2017), 35-45 % of the summed hip, knee and ankle positive work (Sawicki, Lewis &
     Ferris 2009), a share that does not change with speed (Farris & Sawicki 2012)
  P3 joint roles: the knee absorbs and the ankle and hip generate net work (Winter 1983; DeVita, Helseth
     & Hortobagyi 2007; Sawicki et al. 2009)
  P4 anteroposterior balance: braking and propulsive impulses cancel at steady speed (Turns, Neptune &
     Kautz 2007), and the peak propulsive force rises with speed (Nilsson & Thorstensson 1989; Fukuchi,
     Fukuchi & Duarte 2019)
  P5 vertical GRF: double-humped, its first peak rising with speed (Nilsson & Thorstensson 1989; Fukuchi
     et al. 2019) and the stance fraction falling (Hebenstreit et al. 2015: 68.0 - 3.2 v % of the cycle)
  P6 pendular energy exchange: recovery about 65-70 %, maximal at intermediate speeds near 1.5 m/s
     (Cavagna, Thys & Zamboni 1976; Cavagna, Heglund & Taylor 1977; Cavagna, Willems & Heglund 2000)
The manuscript table tab:principles_literature gives each reported finding next to the human data.

Prediction types and criteria (fixed in advance):
  magnitude   robust z of each rollout mean against the human quantile regression at its speed (speed-
              dependent reference by quantile regression as for growth charts, Wei et al. 2006),
              z = (x - median(v)) / (IQR(v) / 1.349); consistent if |median z| <= Z_MAX (the least
              conservative of the outlier cut-offs 2, 2.5, 3 in Leys et al. 2013). A Wilcoxon
              signed-rank test of z against 0 (Holm-corrected over all model x magnitude tests) is
              reported; between models, Welch's ANOVA and Games-Howell on |z|
  direction   slope of the rollout means on speed; consistent if its 95 % bootstrap CI (rollouts
              resampled) lies on the predicted side of 0
  sign        share of rollout means with the predicted sign; consistent if >= SIGN_REL x the human
              share (the human share is reported as the reference)
  shape       quadratic fit of the rollout means on speed; consistent if the 95 % bootstrap CI of the
              quadratic coefficient is below 0 and the vertex lies inside the speeds covered
Direction and shape need rollouts spanning at least MIN_SPAN m/s of the human range ("n/a" otherwise).
The human data are evaluated with the same criteria (subject x speed means, subjects resampled).

Body-size normalization (evaluate(..., legs=...)): the kinetic quantities are made dimensionless with
leg length L, gravity g and body mass (Hof 1996): work (J/kg) / (g L), impulse (BW s) / sqrt(L / g);
forces in BW, fractions, ratios and percentages are already dimensionless. Speed stays in m/s.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .kinetics import FEATURES

Z_MAX, SIGN_REL, MIN_SPAN, N_BOOT = 2.0, 0.8, 0.6, 2000
G = 9.80665
WORK = ("pushoff_work", "collision_work", "transition_work", "ankle_pos_work", "hip_net_work", "knee_net_work",
        "ankle_net_work")
IMPULSE = ("propel_impulse",)


def dimensionless(D: dict, L) -> dict:
    """Kinetic metrics of strides with leg length L (m, scalar or per stride) in Hof's (1996) units."""
    L = np.asarray(L, float)
    out = dict(D)
    for k in WORK:
        out[k] = D[k] / (G * L)
    for k in IMPULSE:
        out[k] = D[k] / np.sqrt(L / G)
    return out


def derived(F: np.ndarray) -> dict[str, np.ndarray]:
    """Per-stride metrics used by the predictions, from FEATURES rows."""
    c = {k: F[:, i].astype(float) for i, k in enumerate(FEATURES)}
    pos = c["hip_pos_work"] + c["knee_pos_work"] + c["ankle_pos_work"]
    with np.errstate(invalid="ignore", divide="ignore"):
        return {
            "speed": c["speed"],
            "double_support": c["double_support"],
            "pushoff_work": c["pushoff_work"],
            "collision_work": c["collision_work"],
            "transition_work": c["pushoff_work"] - c["collision_work"],
            "pushoff_peak_time": c["pushoff_peak_time"],
            "ankle_share": np.where(pos > 0, c["ankle_pos_work"] / pos, np.nan),
            "ankle_pos_work": c["ankle_pos_work"],
            "hip_net_work": c["hip_pos_work"] + c["hip_neg_work"],
            "knee_net_work": c["knee_pos_work"] + c["knee_neg_work"],
            "ankle_net_work": c["ankle_pos_work"] + c["ankle_neg_work"],
            "net_ap_impulse": np.where(c["tot_propel_impulse"] > 0,
                                       (c["tot_propel_impulse"] + c["tot_brake_impulse"]) / c["tot_propel_impulse"], np.nan),
            "propel_impulse": c["tot_propel_impulse"],
            "propel_peak": c["propel_peak"],
            "double_hump": (c["fz_valley"] < 0.95 * np.minimum(c["fz_peak1"], c["fz_peak2"])).astype(float),
            "fz_peak1": c["fz_peak1"],
            "stance_frac": c["stance_frac"],
            "recovery": c["recovery"],
        }


@dataclass(frozen=True)
class Prediction:
    principle: str
    key: str
    text: str
    kind: str          # magnitude | direction | sign | shape
    metric: str
    sense: int = 1     # direction/sign: +1 positive, -1 negative


PRINCIPLES = {
    "P1": "Step-to-step transition",
    "P2": "Ankle push-off work",
    "P3": "Joint roles",
    "P4": "AP balance and propulsion",
    "P5": "Vertical GRF and speed",
    "P6": "Pendular energy exchange",
}
PREDICTIONS = [
    Prediction("P1", "1a", "double support (fraction of stride)", "magnitude", "double_support"),
    Prediction("P1", "1b", "trailing-leg push-off work (J/kg)", "magnitude", "pushoff_work"),
    Prediction("P1", "1c", "leading-leg collision work (J/kg)", "magnitude", "collision_work"),
    Prediction("P1", "1d", "push-off + collision work rises with speed", "direction", "transition_work", +1),
    Prediction("P2", "2a", "ankle share of positive joint work", "magnitude", "ankle_share"),
    Prediction("P2", "2b", "ankle positive work rises with speed", "direction", "ankle_pos_work", +1),
    Prediction("P3", "3a", "knee net work negative", "sign", "knee_net_work", -1),
    Prediction("P3", "3b", "ankle net work positive", "sign", "ankle_net_work", +1),
    Prediction("P3", "3c", "hip net work positive", "sign", "hip_net_work", +1),
    Prediction("P4", "4a", "net AP impulse / propulsive impulse", "magnitude", "net_ap_impulse"),
    Prediction("P4", "4b", "peak propulsive force rises with speed", "direction", "propel_peak", +1),
    Prediction("P5", "5a", "double-humped vertical GRF", "sign", "double_hump", +1),
    Prediction("P5", "5b", "first vertical peak rises with speed", "direction", "fz_peak1", +1),
    Prediction("P5", "5c", "stance fraction falls with speed", "direction", "stance_frac", -1),
    Prediction("P6", "6a", "energy recovery (%)", "magnitude", "recovery"),
    Prediction("P6", "6b", "recovery maximal at an intermediate speed", "shape", "recovery"),
]


class SpeedModel:
    """Quadratic quantile regression on speed (as Figure 2): median mu(v), quartiles; robust spread
    sigma(v) = IQR(v) / 1.349, floored at 10 % of its mean."""

    def __init__(self, v, x):
        import statsmodels.api as sm
        ok = np.isfinite(v) & np.isfinite(x)
        v, x = v[ok], x[ok]
        X = np.c_[np.ones_like(v), v, v ** 2]
        self.coef = {q: sm.QuantReg(x, X).fit(q=q, max_iter=5000).params for q in (.25, .5, .75)}
        self.floor = 0.1 * max(float(np.mean((self.q(v, .75) - self.q(v, .25)) / 1.349)), 1e-12)

    def q(self, v, q):
        c = self.coef[q]
        v = np.asarray(v, float)
        return c[0] + c[1] * v + c[2] * v ** 2

    def __call__(self, v):
        return self.q(v, .5), np.maximum((self.q(v, .75) - self.q(v, .25)) / 1.349, self.floor)


def human_means(hum, legs: dict | None = None) -> pd.DataFrame:
    """Subject x speed-bin means of the derived metrics (bins with >= 5 strides); kinetic metrics
    dimensionless with legs ({subject: leg length})."""
    import warnings
    warnings.filterwarnings("ignore", "Mean of empty slice", RuntimeWarning)
    D = derived(hum["features"])
    subj, b = hum["stride_subject"], hum["stride_bin"]
    if legs is not None:
        D = dimensionless(D, np.array([legs[str(x)] for x in hum["subject"]])[subj])
    rows = []
    for s in np.unique(subj):
        for k in np.unique(b):
            m = (subj == s) & (b == k)
            if m.sum() >= 5:
                rows.append({"unit": f"{s}", **{key: float(np.nanmean(val[m])) for key, val in D.items()}})
    return pd.DataFrame(rows)


def rollout_means(d, lo, hi, leg: float | None = None) -> pd.DataFrame:
    """Per-rollout means of the derived metrics over its strides within [lo, hi] m/s (>= 2 strides);
    kinetic metrics dimensionless with the skeleton's leg length."""
    D = derived(d["features"])
    if leg is not None:
        D = dimensionless(D, leg)
    R = d["stride_rollout"]
    keep = (D["speed"] >= lo) & (D["speed"] <= hi)
    rows = []
    for r in np.unique(R[keep]):
        m = keep & (R == r)
        if m.sum() >= 2:
            rows.append({"unit": str(r), **{key: float(np.nanmean(val[m])) for key, val in D.items()}})
    return pd.DataFrame(rows)


def _boot(units, fn, rng):
    """Bootstrap of fn over resampled units (rows grouped by unit); returns the 2.5 / 97.5 % quantiles."""
    groups = [g for _, g in units.groupby("unit")]
    vals = []
    for _ in range(N_BOOT):
        idx = rng.integers(0, len(groups), len(groups))
        vals.append(fn(pd.concat([groups[i] for i in idx])))
    vals = np.array(vals, float)
    return np.nanpercentile(vals, [2.5, 97.5])


def _slope(df, metric):
    ok = np.isfinite(df.speed) & np.isfinite(df[metric])
    return np.polyfit(df.speed[ok], df[metric][ok], 1)[0] if ok.sum() >= 3 else np.nan


def _quad(df, metric):
    ok = np.isfinite(df.speed) & np.isfinite(df[metric])
    return np.polyfit(df.speed[ok], df[metric][ok], 2) if ok.sum() >= 4 else np.full(3, np.nan)


def evaluate(hum, models: dict, seed: int = 0, legs: dict | None = None) -> dict:
    """Evaluate every prediction for the human reference and each model. legs: {"human": {subject: L},
    "models": {model: L}} (m) for body-size normalized (dimensionless) kinetic quantities.

    Returns tests (DataFrame: group, principle, key, kind, value, ci_low, ci_high, n, consistent, p,
    p_holm), z (per-rollout z of the magnitude metrics), between (Welch/Games-Howell on |z|)."""
    from scipy.stats import wilcoxon
    from statsmodels.stats.multitest import multipletests

    from .stats import compare_groups

    rng = np.random.default_rng(seed)
    H = human_means(hum, legs and legs["human"])
    lo, hi = float(H.speed.min()), float(H.speed.max())
    ref = {p.metric: SpeedModel(H.speed.to_numpy(), H[p.metric].to_numpy()) for p in PREDICTIONS if p.kind == "magnitude"}
    groups = {"Human": H, **{m: rollout_means(d, lo, hi, legs and legs["models"][m]) for m, d in models.items()}}
    human_share = {}
    for p in PREDICTIONS:
        if p.kind == "sign":
            x = H[p.metric].to_numpy(); x = x[np.isfinite(x)]
            human_share[p.key] = float(np.mean(x)) if p.metric == "double_hump" else float(np.mean(np.sign(x) == p.sense))
    rows, zrows = [], []
    for g, df in groups.items():
        span = float(df.speed.max() - df.speed.min()) if len(df) else 0.0
        for p in PREDICTIONS:
            r = dict(group=g, principle=p.principle, key=p.key, kind=p.kind, n=len(df), value=np.nan,
                     ci_low=np.nan, ci_high=np.nan, consistent=None, p=np.nan)
            x = df[p.metric].to_numpy() if len(df) else np.array([])
            if p.kind == "magnitude":
                mu, sd = ref[p.metric](df.speed.to_numpy())
                z = (x - mu) / sd
                ok = np.isfinite(z)
                if ok.sum():
                    r["value"] = float(np.median(z[ok]))
                    r["ci_low"], r["ci_high"] = np.percentile(z[ok], [25, 75])
                    r["consistent"] = bool(abs(r["value"]) <= Z_MAX)
                    if g != "Human" and ok.sum() >= 5:
                        r["p"] = float(wilcoxon(z[ok]).pvalue)
                        zrows += [dict(group=g, key=p.key, metric=p.metric, unit=u, speed=s, value=xv, z=zv)
                                  for u, s, xv, zv in zip(df.unit[ok], df.speed[ok], x[ok], z[ok])]
            elif p.kind == "sign":
                ok = np.isfinite(x)
                if ok.sum():
                    r["value"] = float(np.mean(np.sign(x[ok]) == p.sense)) if p.metric != "double_hump" else float(np.mean(x[ok]))
                    r["consistent"] = bool(r["value"] >= SIGN_REL * human_share[p.key]) if g != "Human" else True
            elif span >= MIN_SPAN and np.isfinite(x).sum() >= 4:
                if p.kind == "direction":
                    r["value"] = float(_slope(df, p.metric))
                    r["ci_low"], r["ci_high"] = _boot(df, lambda b: _slope(b, p.metric), rng)
                    r["consistent"] = bool(r["ci_low"] > 0) if p.sense > 0 else bool(r["ci_high"] < 0)
                else:                                      # shape: concave with the vertex inside the range
                    a, b, _ = _quad(df, p.metric)
                    r["value"] = float(-b / (2 * a)) if a else np.nan            # vertex speed
                    r["ci_low"], r["ci_high"] = _boot(df, lambda s: _quad(s, p.metric)[0], rng)   # CI of curvature
                    r["consistent"] = bool(r["ci_high"] < 0 and df.speed.min() <= r["value"] <= df.speed.max())
            rows.append(r)
    tests = pd.DataFrame(rows)
    m = tests.p.notna()
    tests["p_holm"] = np.nan
    if m.any():
        tests.loc[m, "p_holm"] = multipletests(tests.p[m], method="holm")[1]
    Z = pd.DataFrame(zrows)
    between = {}
    for p in PREDICTIONS:
        if p.kind == "magnitude" and len(Z):
            sub = Z[Z.key == p.key]
            grp = {g: np.abs(sub.z[sub.group == g].to_numpy()) for g in models if (sub.group == g).sum() >= 3}
            if len(grp) >= 2:
                between[p.key] = compare_groups(grp)
    return {"tests": tests, "z": Z, "between": between, "human_range": (lo, hi), "groups": groups, "reference": ref}


def summary(tests: pd.DataFrame) -> pd.DataFrame:
    """Consistent predictions per principle and group, as 'k/n' (n excludes n/a)."""
    out = {}
    for (g, pr), sub in tests.groupby(["group", "principle"], sort=False):
        valid = sub.consistent.dropna()
        out.setdefault(g, {})[pr] = f"{int(valid.sum())}/{len(valid)}" if len(valid) else "n/a"
    return pd.DataFrame(out).reindex(list(PRINCIPLES))
