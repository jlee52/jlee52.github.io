"""Gait cycles whose ground reaction forces were reproduced exactly.

The BFM GRF reconstruction (scripts/reconstruct_bfm_grf.py) re-simulates each 30 Hz control
interval j, from stored state j-1 to stored state j, and records its end-state error. A gait cycle
between heel strikes hs[k] and hs[k+1] (stored-state indices) is kept only if every interval in
[hs[k], hs[k+1]] reproduced its stored end state (one interval of margin before the cycle).
Heel strikes are detected on the whole rollout as before; cycles are dropped afterwards.
"""
from __future__ import annotations

import numpy as np

TOL = 1e-6


def kept_cycles(heel_strikes, bad) -> np.ndarray:
    """keep[k] for the cycle [hs[k], hs[k+1]]; bad: per control interval, True if not reproduced."""
    hs = np.asarray(heel_strikes, int)
    bad = np.asarray(bad, bool)
    return np.array([not bad[hs[k]:hs[k + 1] + 1].any() for k in range(len(hs) - 1)], bool)


def kept_runs(heel_strikes, keep) -> list[np.ndarray]:
    """Heel strikes of each maximal run of consecutive kept cycles (a run of n cycles has n + 1)."""
    hs = np.asarray(heel_strikes, int)
    runs, cur = [], None
    for k, ok in enumerate(keep):
        if ok:
            cur = [hs[k], hs[k + 1]] if cur is None else cur + [hs[k + 1]]
        elif cur is not None:
            runs.append(np.array(cur))
            cur = None
    if cur is not None:
        runs.append(np.array(cur))
    return runs
