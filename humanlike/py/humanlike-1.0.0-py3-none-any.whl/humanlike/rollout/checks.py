"""Engine-agnostic consistency checks for logged ground reaction forces.

All take physics-rate arrays: time [n], grf [n, feet, 3] (floor on body, world frame, N), com
velocity [n, 3] and total mass. The checks hold for any rigid-body simulation whose only
external forces are gravity and floor contacts.
"""
from __future__ import annotations

import numpy as np


def impulse_residual(grf_total, com_vel, mass, dt, gravity=9.81, window=15):
    """Linear momentum balance over consecutive windows of `window` physics steps:

        m (v_com[i + w] - v_com[i]) = dt * sum_{k=i}^{i+w-1} (F[k] - m g)

    with F[k] the total floor force at the logged state k (it acts during step k -> k + 1).
    Returns the residual [n_windows, 3] in N (momentum error / window duration). It is not exactly
    zero for an implicit integrator and a configuration-dependent COM Jacobian, but it should be a
    small fraction of body weight.
    """
    F = np.asarray(grf_total, float) - np.array([0.0, 0.0, mass * gravity])
    v = np.asarray(com_vel, float)
    starts = np.arange(0, len(v) - window, window)
    dp = mass * (v[starts + window] - v[starts])
    imp = np.array([F[s:s + window].sum(axis=0) * dt for s in starts])
    return (dp - imp) / (window * dt)


def mean_vertical_grf(grf_total_z, start: int, stop: int, mass, gravity=9.81) -> float:
    """Mean vertical floor force over [start, stop) in body weights. Over whole steady strides it is
    1 + (mean vertical COM acceleration) / g, i.e. 1 to within the stride's vertical velocity change."""
    return float(np.mean(np.asarray(grf_total_z)[start:stop]) / (mass * gravity))
