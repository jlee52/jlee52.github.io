"""Rollout logging (simulation side) and checks for the unified post-processing pipeline."""
from .checks import impulse_residual, mean_vertical_grf

__all__ = ["impulse_residual", "mean_vertical_grf"]
