"""Physics-rate rollout logging for MuJoCo policies: ground reaction forces from the solver's
contact forces, joint torques and state at every physics step.

Ground reaction force (GRF) here is the sum, over the contacts between the floor and a foot's
geoms, of the contact force the floor exerts on the foot, from ``mj_contactForce`` rotated from
the contact frame to the world frame (``frame.T @ f``: the rows of ``contact.frame`` are the
contact axes). It equals the linear part of MuJoCo's ``cfrc_ext`` for those bodies. Foot
``<force>`` sensors are not used: they report the joint reaction force from the shank, which
includes the foot's weight and inertia (tens of N vertically, up to ~140 N horizontally).

Usage, in place of ``env.step`` (humenv: ``ctrl = action`` then 15 physics steps)::

    log = MujocoRolloutLogger(model, data, feet={"L": ["L_Ankle", "L_Toe"], "R": ["R_Ankle", "R_Toe"]})
    for t in range(n_control_steps):
        action = policy(obs)
        log.control_step(action, n_substeps=15)
        obs = env.unwrapped.get_obs()          # whatever the environment returns after stepping
    arrays = log.arrays()

Logging does not perturb the simulation: forces are evaluated with an extra ``mj_forward`` on
the stepped state, and the solver warm start it overwrites is restored, so the trajectory is
bitwise identical to plain ``mj_step`` calls (tests/test_rollout_logger.py).
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence

import numpy as np

try:
    import mujoco
except ImportError:  # pragma: no cover - mujoco is only needed where rollouts are generated
    mujoco = None

G = 9.81


def _body_ids(model, names: Sequence[str]) -> set[int]:
    return {model.body(n).id for n in names}


def contact_grf(model, data, floor_id: int, feet: Mapping[str, set[int]]):
    """Floor-on-foot forces and centres of pressure for the current ``data`` (after mj_forward).

    feet: {label: body ids}. Returns (force {label: [3]}, cop {label: [3] or NaN}, other [3]),
    where `other` sums floor contacts on any non-foot body.
    """
    f6 = np.zeros(6)
    force = {k: np.zeros(3) for k in feet}
    moment = {k: np.zeros(3) for k in feet}          # sum of Fz * contact position (for the CoP)
    other = np.zeros(3)
    for i in range(data.ncon):
        c = data.contact[i]
        if floor_id == c.geom1:
            g, sign = c.geom2, 1.0                    # mj_contactForce: force of geom1 on geom2
        elif floor_id == c.geom2:
            g, sign = c.geom1, -1.0
        else:
            continue
        mujoco.mj_contactForce(model, data, i, f6)
        f = sign * (c.frame.reshape(3, 3).T @ f6[:3])
        body = model.geom_bodyid[g]
        label = next((k for k, ids in feet.items() if body in ids), None)
        if label is None:
            other += f
        else:
            force[label] += f
            moment[label] += f[2] * c.pos
    cop = {k: moment[k] / force[k][2] if force[k][2] > 1e-9 else np.full(3, np.nan) for k in feet}
    return force, cop, other


class MujocoRolloutLogger:
    """Record state, actuation and foot GRF after every physics step."""

    def __init__(self, model, data, feet: Mapping[str, Sequence[str]], floor: str = "floor",
                 bodies: Sequence[str] = ()):
        if mujoco is None:
            raise ImportError("MujocoRolloutLogger needs the mujoco package")
        self.model, self.data = model, data
        self.floor_id = model.geom(floor).id
        self.feet = {k: _body_ids(model, v) for k, v in feet.items()}
        self.foot_names = {k: list(v) for k, v in feet.items()}
        self.bodies = list(bodies)
        self._body_idx = [model.body(n).id for n in self.bodies]
        self.mass = float(model.body_subtreemass[0])
        self._rows: list[tuple] = []
        self._control = 0

    def record(self):
        """Log the current (already stepped) state. Called by control_step after each mj_step."""
        m, d = self.model, self.data
        ws = d.qacc_warmstart.copy()
        mujoco.mj_forward(m, d)                      # contacts and forces for the current state
        mujoco.mj_subtreeVel(m, d)                    # subtree_linvel is not updated by mj_forward
        d.qacc_warmstart[:] = ws                      # keep the trajectory bitwise unchanged
        force, cop, other = contact_grf(m, d, self.floor_id, self.feet)
        self._rows.append((
            d.time, self._control, d.qpos.copy(), d.qvel.copy(), d.ctrl.copy(), d.qfrc_actuator.copy(),
            np.stack([force[k] for k in self.feet]), np.stack([cop[k] for k in self.feet]), other,
            d.subtree_com[0].copy(), d.subtree_linvel[0].copy(), d.xpos[self._body_idx].copy(),
        ))

    def control_step(self, ctrl, n_substeps: int):
        """Apply `ctrl` for `n_substeps` physics steps, logging after each (as env.step would)."""
        self.data.ctrl[:] = ctrl
        for _ in range(n_substeps):
            mujoco.mj_step(self.model, self.data)
            self.record()
        self._control += 1

    def arrays(self) -> dict[str, np.ndarray]:
        cols = list(zip(*self._rows)) if self._rows else [[]] * 12
        keys = ("time", "control_step", "qpos", "qvel", "ctrl", "qfrc_actuator", "grf", "cop", "grf_other",
                "com_pos", "com_vel", "body_pos")
        out = {k: np.asarray(v) for k, v in zip(keys, cols)}
        out.update(dt=np.float64(self.model.opt.timestep), mass=np.float64(self.mass), gravity=np.float64(G),
                   feet=np.array(list(self.feet)), bodies=np.array(self.bodies),
                   mujoco_version=np.array(mujoco.__version__))
        return out
