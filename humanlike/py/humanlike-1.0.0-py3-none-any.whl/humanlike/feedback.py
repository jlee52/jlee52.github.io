"""Feedback signature: lateral foot-placement control.

Input format (vis_hum `ft_ctl_*.npy`, one row per rollout session / human subject):
    gains    [n, 101, 5]  phase-resolved OLS coefficients [g0, b_xpel, b_ypel, b_vxpel, b_vypel]
    ctl_mag  [n, 101]     relative predictive power  dR^2(phi) = R^2_pelvis - R^2_foot

FPGD (manuscript Eq. for d_i(phi)): per-phase Mahalanobis distance of each query gain vector
to the reference gain distribution, with shrinkage + ridge regularised covariance
    S~ = (1 - a) S + a s I + lam s I,   s = max(tr(S)/p, 1),   a = 0.1, lam = 1e-6
and pseudo-inverse; summarised per trajectory as the AUC over the gait cycle.
"""
from __future__ import annotations

import numpy as np

PHASES = slice(1, 101)   # phase 0 excluded: foot state is degenerate at heel strike
GAIN_COLS = slice(1, 5)  # drop intercept g0, keep the 4 pelvis-state gains


def _reg_cov(x: np.ndarray, shrinkage: float, ridge: float) -> np.ndarray:
    p = x.shape[1]
    cov = np.atleast_2d(np.cov(x, rowvar=False)) if x.shape[0] >= 2 else np.eye(p)
    if cov.shape != (p, p) or not np.isfinite(cov).all():
        cov = np.eye(p)
    s = max(np.trace(cov) / p, 1.0)
    return (1 - shrinkage) * cov + (shrinkage + ridge) * s * np.eye(p)


def fpgd_curves(ref_gains, query_gains, shrinkage=0.1, ridge=1e-6) -> np.ndarray:
    """Phase-resolved Mahalanobis distance d_i(phi), shape [n_query, n_phase].

    Both inputs are [n, n_phase, p] arrays already restricted to the gain features used.
    """
    ref, qry = np.asarray(ref_gains, float), np.asarray(query_gains, float)
    if ref.shape[1:] != qry.shape[1:]:
        raise ValueError(f"phase/feature mismatch {ref.shape[1:]} vs {qry.shape[1:]}")
    d = np.full(qry.shape[:2], np.nan)
    for t in range(ref.shape[1]):
        r = ref[:, t][np.isfinite(ref[:, t]).all(axis=1)]
        if r.shape[0] < 2:
            continue
        mu, inv = r.mean(axis=0), np.linalg.pinv(_reg_cov(r, shrinkage, ridge))
        delta = qry[:, t] - mu
        ok = np.isfinite(delta).all(axis=1)
        d[ok, t] = np.sqrt(np.einsum("ij,jk,ik->i", delta[ok], inv, delta[ok]))
    return d


def fpgd(ref_gains, query_gains, shrinkage=0.1, ridge=1e-6, drop_failed=False) -> np.ndarray:
    """Foot placement gain distance: AUC of d_i(phi) per query trajectory (lower = more human-like).

    Accepts the raw vis_hum `gains` arrays [n, 101, 5]; phase/feature selection is applied here.
    Missing phases contribute 0 to the AUC (trapezoid, dx = 1 % gait cycle).

    drop_failed: a trajectory with no valid gain fit at any phase gets NaN instead of AUC = 0.
        False reproduces the published numbers, where such a session scored a perfect 0
        (KINESIS session 0).
    """
    ref = np.asarray(ref_gains, float)[:, PHASES, GAIN_COLS]
    qry = np.asarray(query_gains, float)[:, PHASES, GAIN_COLS]
    curves = fpgd_curves(ref, qry, shrinkage, ridge)
    auc = np.trapezoid(np.nan_to_num(curves), dx=1.0, axis=1)
    if drop_failed:
        auc[~np.isfinite(curves).any(axis=1)] = np.nan
    return auc


def peak_delta_r2(ctl_mag) -> tuple[np.ndarray, np.ndarray]:
    """Peak relative predictive power m_i = max dR^2 and its timing tau_i = argmax (% gait cycle).

    Rows that are entirely NaN (failed fits) are dropped.
    """
    x = np.asarray(ctl_mag, float)
    x = x[~np.all(np.isnan(x), axis=1)]
    return np.nanmax(x, axis=1), np.nanargmax(x, axis=1).astype(float)
