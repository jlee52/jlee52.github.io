"""Joint torques of the MimicKit humanoid (AMP, SMP) by Newton-Euler inverse dynamics.

Isaac Gym's DOF force sensor does not report the position-drive torque (in a static hold it reads
at most 0.8 N m where gravity needs up to 38 N m), and its contact forces have no friction component. The
recorded physics-rate body kinematics are complete, though: body-origin positions, centre-of-mass
velocities and world angular velocities after every physics step, and body orientations at the
control states (slerped in between). The summed body momentum change then equals the measured
normal force exactly, and gives the total external wrench.

    single support  the stance foot carries the whole external wrench: exact
    flight          no external wrench
    double support  the split between the feet is not observable. Every split consistent with the
                    total wrench, the measured normal force of each foot, a centre of pressure in
                    the foot's contact patch and friction inside the cone (mu = 1) is admissible;
                    ``DoubleSupport`` parametrises them; ``solve_rollout`` takes the minimum-effort
                    split as the estimate and the least and greatest joint power over all of them.

Joint wrenches are computed with moment arms halfway through each physics step, which recovers the
applied torques of a synthetic MuJoCo simulation of the same model to 0.02 N m (rms). MimicKit
merges each series of three hinges into a spherical joint whose DOF coordinates are an exponential
map and whose DOF velocities are the child-frame relative angular velocity; the torques below are
the matching child-frame components, so torque x DOF velocity is the joint power. Isaac Gym also
applies the MJCF joint armature (a rotor inertia the body momenta do not see); ``add_armature`` adds
its torque to give the drive torque. Against the torques applied to a fixed-base humanoid in Isaac Gym
(effort mode), the drive torque has median R2 0.84-0.96 per joint group and the summed |power| is
within 5 % (scripts/external/isaac_torque_check/effort_truth_ig.py).
"""
from __future__ import annotations

import os

import numpy as np
from scipy.spatial.transform import Rotation as Rot, Slerp

XML = os.path.expanduser("~/repos/MimicKit/data/assets/humanoid/humanoid.xml")
G = 9.81
MU = 1.0                                                       # MJCF friction (Isaac Gym default)
SOLE = dict(z=-0.05, x=(-0.0435, 0.1335), y=(-0.045, 0.045))   # foot box bottom, foot frame
TOUCH = 0.02                                                   # corner height counted as in contact (contact offset)
MARGIN = 0.01                                                  # CoP tolerance outside the patch (m)
TORSION = 0.03                                                 # free moment bound |Tz| <= mu Fz TORSION
MOMENT_TOL = 0.5                                               # N m: moment imbalance accepted from the 1st relaxation, x4 per further one


class Humanoid:
    """Masses, inertias and joint tree of the MimicKit humanoid, in the recorded body/DOF order."""

    def __init__(self, body_names, dof_names, xml=XML):
        import mujoco
        m = mujoco.MjModel.from_xml_path(xml)
        ids = [mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_BODY, str(n)) for n in body_names]
        self.names = [str(n) for n in body_names]
        self.parent = np.array([ids.index(m.body_parentid[i]) if m.body_parentid[i] in ids else -1 for i in ids])
        self.mass = m.body_mass[ids].copy()
        self.ipos = m.body_ipos[ids].copy()
        Ri = Rot.from_quat(np.roll(m.body_iquat[ids], -1, axis=1)).as_matrix()
        self.inertia = np.einsum("bij,bj,bkj->bik", Ri, m.body_inertia[ids], Ri)    # body frame, about the COM
        dn = [str(n) for n in dof_names]
        self.ndof = len(dn)
        self.dofs = {b: [(dn.index(mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_JOINT, j)), m.jnt_axis[j].copy())
                         for j in range(m.njnt) if m.jnt_bodyid[j] == ids[b] and m.jnt_type[j] == mujoco.mjtJoint.mjJNT_HINGE]
                     for b in range(len(ids))}
        self.order = sorted(range(len(ids)), key=lambda b: -self._depth(b))         # leaves first
        self.feet = [self.names.index("left_foot"), self.names.index("right_foot")]
        self.legs = [self._chain(f) for f in self.feet]                            # foot..thigh (no root)

    def _depth(self, b):
        k = 0
        while self.parent[b] >= 0:
            b, k = self.parent[b], k + 1
        return k

    def _chain(self, b):
        out = []
        while self.parent[b] >= 0:
            out.append(b); b = self.parent[b]
        return out


def armature(dof_names, xml=XML):
    """MJCF joint armature [ndof] in the given DOF order (Isaac Gym applies it as rotor inertia)."""
    import mujoco
    m = mujoco.MjModel.from_xml_path(xml)
    return np.array([m.dof_armature[m.jnt_dofadr[mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_JOINT, str(n))]] for n in dof_names])


def add_armature(tau, dof_vel, dt, arm):
    """Drive torque = Newton-Euler joint torque + armature x DOF acceleration (row t: step t-1 -> t).
    tau, dof_vel [T, ..., ndof]."""
    acc = np.zeros_like(dof_vel)
    acc[1:] = (dof_vel[1:] - dof_vel[:-1]) / dt
    return tau + arm * acc


def physics_rotations(xquat, steps_per_control):
    """Body orientations at the physics steps [T*n, B, 3, 3] from the control states [T, B, 4]
    (xyzw; control state c is physics row c*n - 1), by slerp."""
    n = steps_per_control
    Tc, B = xquat.shape[:2]
    key = np.arange(Tc) * n - 1
    key[0] = 0
    t = np.clip(np.arange(Tc * n), 0, key[-1])
    return np.stack([Slerp(key, Rot.from_quat(xquat[:, b]))(t).as_matrix() for b in range(B)], 1)


def midpoint(R, P):
    """Orientations and positions halfway through each step (row t: between rows t-1 and t)."""
    Pm = P.copy(); Pm[1:] = (P[1:] + P[:-1]) / 2
    Rm = R.copy()
    r1, r0 = Rot.from_matrix(R[1:].reshape(-1, 3, 3)), Rot.from_matrix(R[:-1].reshape(-1, 3, 3))
    Rm[1:] = (r0 * Rot.from_rotvec((r0.inv() * r1).as_rotvec() / 2)).as_matrix().reshape(R[1:].shape)
    return Rm, Pm


def wrenches(h, R, P, V, W, dt):
    """Joint wrenches with no external force; row t is the physics step from row t-1 to t (row 0 zero).

    R [T, B, 3, 3], P [T, B, 3] body orientation and origin, V [T, B, 3] COM velocity, W [T, B, 3]
    world angular velocity, all after each step. Returns F, M [T, B, 3] (the force and the moment
    about the body origin that the parent exerts on each body through its joint; for the root, the
    external wrench the whole body needs) and the midpoint (Rm, Pm) they refer to."""
    T, B = P.shape[:2]
    H = np.einsum("tbij,bjk,tblk,tbl->tbi", R, h.inertia, R, W)    # angular momentum about the COM
    Rm, Pm = midpoint(R, P)
    x = Pm + np.einsum("tbij,bj->tbi", Rm, h.ipos)
    a = np.zeros_like(V); a[1:] = (V[1:] - V[:-1]) / dt
    dH = np.zeros_like(H); dH[1:] = (H[1:] - H[:-1]) / dt
    lin = h.mass[None, :, None] * (a + np.array([0, 0, G]))
    F = np.zeros((T, B, 3)); M = np.zeros((T, B, 3))
    for b in h.order:
        F[:, b] += lin[:, b]
        M[:, b] += dH[:, b] + np.cross(x[:, b] - Pm[:, b], lin[:, b])
        p = h.parent[b]
        if p >= 0:
            F[:, p] += F[:, b]
            M[:, p] += M[:, b] + np.cross(Pm[:, b] - Pm[:, p], F[:, b])
    F[0] = 0; M[0] = 0
    return F, M, Rm, Pm


def torques(h, M, Rm, bodies=None):
    """Per-DOF torques [..., ndof] (child-frame components) from joint moments M [..., B, 3]."""
    tau = np.zeros(M.shape[:-2] + (h.ndof,))
    for b, dl in h.dofs.items():
        if dl and (bodies is None or b in bodies):
            loc = np.einsum("...ji,...j->...i", Rm[..., b, :, :], M[..., b, :])
            for i, ax in dl:
                tau[..., i] = loc @ ax
    return tau


def foot_moment(c, f, tz, pf):
    """Moment about the foot origin pf of a force f at ground point c plus a free moment tz."""
    return np.cross(c - pf, f) + tz[..., None] * np.array([0, 0, 1.0])


def leg_delta(h, leg, Pm, Rm, f, mf):
    """Torque change [..., ndof] of the joints between a foot and the root when that foot receives the
    wrench (f, moment mf about the foot origin)."""
    foot = h.legs[leg][0]
    dM = np.zeros(f.shape[:-1] + (len(h.names), 3))
    for b in h.legs[leg]:
        dM[..., b, :] = mf + np.cross(Pm[..., foot, :] - Pm[..., b, :], f)
    Rb = np.broadcast_to(Rm, f.shape[:-1] + Rm.shape[-3:]) if Rm.ndim == 3 else Rm
    return -torques(h, dM, Rb, bodies=h.legs[leg])


def patch(Rm_f, Pm_f):
    """Ground-plane corners of the foot sole within TOUCH of the ground ([k, 2]; the lowest one if none)."""
    cs = np.array([[x, y, SOLE["z"]] for x in SOLE["x"] for y in SOLE["y"]])[[0, 1, 3, 2]]
    w = Pm_f + cs @ Rm_f.T
    on = w[:, 2] < TOUCH
    return w[on, :2] if on.any() else w[[np.argmin(w[:, 2])], :2]


def closest(pt, poly):
    """Closest points [n, 2] of a convex polygon [k, 2] (k = 1, 2 allowed) to pt [n, 2]."""
    if len(poly) == 1:
        return np.broadcast_to(poly[0], pt.shape).copy()
    inside = outside(pt, poly) == 0
    segs = [(poly[i], poly[(i + 1) % len(poly)]) for i in range(len(poly))] if len(poly) > 2 else [(poly[0], poly[1])]
    best, bd = pt.copy(), np.full(len(pt), np.inf)
    for a, b in segs:
        ab = b - a
        u = np.clip(((pt - a) @ ab) / max(ab @ ab, 1e-12), 0, 1)
        q = a + u[:, None] * ab
        dq = np.linalg.norm(pt - q, axis=1)
        best = np.where((dq < bd)[:, None], q, best); bd = np.minimum(bd, dq)
    return np.where(inside[:, None], pt, best)


def outside(pt, poly):
    """Distance (m) of points [n, 2] outside a convex polygon [k, 2] (0 inside); k = 1, 2 allowed."""
    if len(poly) == 1:
        return np.linalg.norm(pt - poly[0], axis=-1)
    segs = [(poly[i], poly[(i + 1) % len(poly)]) for i in range(len(poly))] if len(poly) > 2 else [(poly[0], poly[1])]
    d = np.full(len(pt), np.inf)
    for a, b in segs:
        ab = b - a
        u = np.clip(((pt - a) @ ab) / max(ab @ ab, 1e-12), 0, 1)
        d = np.minimum(d, np.linalg.norm(pt - (a + u[:, None] * ab), axis=1))
    if len(poly) > 2:
        cen = poly.mean(0)
        inside = np.ones(len(pt), bool)
        for a, b in segs:
            n = np.array([b[1] - a[1], a[0] - b[0]])
            n = n if n @ (cen - a) <= 0 else -n                  # outward normal
            inside &= (pt - a) @ n <= 1e-12
        d[inside] = 0
    return d


class DoubleSupport:
    """Admissible foot wrenches of one double-support step, parametrised by z [n, 5]:
    the left CoP (x, y; in its contact patch), the free moments (as fractions of their bound
    mu Fz TORSION) and s in [0, 1] along the remaining friction freedom. The right CoP follows from
    the horizontal moment balance (admissible within MARGIN of its patch; if no split is, it is moved
    into that band and the moment this leaves unbalanced, the model error of the recorded
    kinematics, is accepted up to a growing tolerance); the
    friction forces from the vertical moment balance, except their component along the line between
    the two CoPs, which s spans within both friction cones.

    Ftot, Mtot: total external force and moment about the world origin; fz [2] measured normal
    forces (left, right), rescaled to the total; Pm, Rm the midpoint body poses."""

    def __init__(self, h, Ftot, Mtot, fz, Pm, Rm, base):
        self.h, self.Mtot, self.Pm, self.Rm, self.base = h, Mtot, Pm, Rm, base
        self.fz = np.asarray(fz, float) * Ftot[2] / max(np.sum(fz), 1e-9)
        self.Fxy = Ftot[:2]
        self.polys = [patch(Rm[f], Pm[f]) for f in h.feet]
        self.margin, self.tol, self.moment_tol = MARGIN, 1.0, 0.0

    def wrench(self, z):
        with np.errstate(divide="ignore", invalid="ignore"):
            return self._wrench(z)

    def _wrench(self, z):
        fz, Fxy, Mt = self.fz, self.Fxy, self.Mtot
        cl = z[:, :2]
        cr_bal = np.c_[(-Mt[1] - cl[:, 0] * fz[0]) / fz[1], (Mt[0] - cl[:, 1] * fz[0]) / fz[1]]
        dist = outside(cr_bal, self.polys[1])
        q = closest(cr_bal, self.polys[1])
        far = dist > self.margin                                  # move into the margin band; imbalance is the rest
        cr = np.where(far[:, None], q + (cr_bal - q) * (self.margin / np.maximum(dist, 1e-12))[:, None], cr_bal)
        imbalance = np.maximum(dist - self.margin, 0) * fz[1]
        tl, tr = (np.clip(z[:, 2 + i], -1, 1) * MU * fz[i] * TORSION * min(self.tol, 4.0) for i in (0, 1))
        r = cl - cr
        rn = np.maximum(np.linalg.norm(r, axis=1), 1e-9)
        u, nrm = r / rn[:, None], np.c_[-r[:, 1], r[:, 0]] / rn[:, None]
        K = Mt[2] - (cr[:, 0] * Fxy[1] - cr[:, 1] * Fxy[0]) - tl - tr
        a = (K / rn)[:, None] * nrm                               # fl = a + lam u
        lo, hi = np.full(len(z), -np.inf), np.full(len(z), np.inf)
        for centre, rad in ((np.zeros(2), MU * fz[0]), (Fxy, MU * fz[1])):    # |a + lam u - centre| <= rad
            b = a - centre
            p = (b * u).sum(1); q = (b * b).sum(1) - (rad * min(self.tol, 1 + 0.05 * np.log2(self.tol) if self.tol < 1e6 else 1e3)) ** 2
            disc = p ** 2 - q
            sq = np.sqrt(np.maximum(disc, 0))
            lo = np.where(disc >= 0, np.maximum(lo, -p - sq), np.inf)
            hi = np.where(disc >= 0, np.minimum(hi, -p + sq), -np.inf)
        ok = (outside(cl, self.polys[0]) <= self.margin) & (imbalance <= self.moment_tol + 1e-9) & (hi >= lo)
        lam = np.where(ok, lo + np.clip(z[:, 4], 0, 1) * np.where(ok, hi - lo, 0), 0)
        fl = a + lam[:, None] * u
        f = np.stack([np.c_[fl, np.full(len(z), fz[0])], np.c_[Fxy - fl, np.full(len(z), fz[1])]], 1)
        return f, np.stack([cl, cr], 1), np.stack([tl, tr], 1), ok

    def torques(self, z):
        h, Pm, Rm = self.h, self.Pm, self.Rm
        f, c, tz, ok = self.wrench(z)
        d = np.zeros((len(z), h.ndof))
        for leg in (0, 1):
            cg = np.c_[c[:, leg], np.zeros(len(z))]
            d += leg_delta(h, leg, Pm, Rm, f[:, leg], foot_moment(cg, f[:, leg], tz[:, leg], Pm[h.feet[leg]]))
        return self.base + d, f, c, ok

    def sample(self, rng, n):
        z = np.c_[rng.dirichlet(np.ones(len(self.polys[0])), n) @ self.polys[0] + rng.normal(0, self.margin / 2, (n, 2)),
                  rng.uniform(-1, 1, (n, 2)), rng.uniform(0, 1, n)]
        return z

    def admissible(self, rng, n=600):
        """Samples with at least 10 admissible ones, relaxing the CoP margin (x2) and the moment,
        torsion and friction tolerances (x4) until there are; returns z [k, 5] and the number of
        relaxations (5: none found, every sample accepted)."""
        for relax in range(5):
            self.margin, self.tol = MARGIN * 2 ** relax, 4.0 ** relax
            self.moment_tol = 0.0 if relax == 0 else MOMENT_TOL * 4.0 ** (relax - 1)
            z = self.sample(rng, n)
            ok = self.wrench(z)[3]
            if ok.sum() >= 10:
                return z[ok], relax
        self.tol, self.moment_tol = 1e6, np.inf
        return self.sample(rng, n), 5

    def optimise(self, z0, objective, rng, iters=8, n=300, elite=0.1):
        """Cross-entropy minimisation of objective(tau [n, ndof]) over admissible z, from samples z0."""
        tau, *_ , ok = self.torques(z0)
        J = np.where(ok, objective(tau), np.inf)
        best_z, best_J = z0[np.argmin(J)], J.min()
        z = z0[np.isfinite(J)] if np.isfinite(J).any() else z0
        Jz = J[np.isfinite(J)] if np.isfinite(J).any() else J
        for _ in range(iters):
            k = max(5, int(len(z) * elite))
            e = z[np.argsort(Jz)[:k]]
            mu, sd = e.mean(0), e.std(0) + np.array([1e-3, 1e-3, 1e-2, 1e-2, 1e-2])
            z = mu + sd * rng.standard_normal((n, 5))
            z[:, 2:4] = np.clip(z[:, 2:4], -1, 1); z[:, 4] = np.clip(z[:, 4], 0, 1)
            z = np.r_[z, best_z[None]]
            tau, *_, ok = self.torques(z)
            Jz = np.where(ok, objective(tau), np.inf)
            if Jz.min() < best_J:
                best_J, best_z = Jz.min(), z[np.argmin(Jz)]
            z, Jz = z[np.isfinite(Jz)], Jz[np.isfinite(Jz)]
            if not len(z):
                break
        return best_z, best_J


def solve_rollout(h, R, P, V, W, Fc, dt, rng, qd=None, thresh=0.01, n=600):
    """Joint torques of one rollout. Fc [T, B, 3] net contact force per body (normal force only);
    qd [T, ndof] DOF velocities (for the double-support power range).

    Returns dict with tau [T, ndof] (minimum-effort split in double support: least sum of squared
    leg torques), grf [T, 2, 3] and cop [T, 2, 2] of the feet (left, right; NaN when not in
    contact), phase [T] (0 flight, 1 left, 2 right, 3 double support), and with qd, apower_lo/hi
    [T]: the least and greatest sum |tau * qd| over the admissible double-support splits (equal to
    the estimate elsewhere; rows without any admissible split, ds_relax 5, keep the estimate as
    the upper value); ds_relax: relaxations needed per double-support row."""
    F, M, Rm, Pm = wrenches(h, R, P, V, W, dt)
    T = len(P)
    base = torques(h, M, Rm)                                   # no external force
    Mtot = M[:, 0] + np.cross(Pm[:, 0], F[:, 0])               # about the world origin
    mg = h.mass.sum() * G
    fz = Fc[:, h.feet, 2]
    on = fz > thresh * mg
    on[0] = False                                              # row 0 has no preceding step
    phase = on[:, 0] * 1 + on[:, 1] * 2
    tau = base.copy()
    grf = np.full((T, 2, 3), np.nan); cp = np.full((T, 2, 2), np.nan)
    for leg in (0, 1):
        rows = np.flatnonzero(phase == leg + 1)
        if not rows.size:
            continue
        f = F[rows, 0]
        with np.errstate(divide="ignore", invalid="ignore"):
            c = np.c_[-Mtot[rows, 1] / f[:, 2], Mtot[rows, 0] / f[:, 2]]
        tz = Mtot[rows, 2] - (c[:, 0] * f[:, 1] - c[:, 1] * f[:, 0])
        cg = np.c_[c, np.zeros(len(rows))]
        mf = foot_moment(cg, f, tz, Pm[rows, h.feet[leg]])
        tau[rows] += leg_delta(h, leg, Pm[rows], Rm[rows], f, mf)
        grf[rows, leg] = f; cp[rows, leg] = c
    legs = _leg_dofs(h)
    apower = None if qd is None else np.abs(tau * qd).sum(1)
    lo_p = None if qd is None else apower.copy()
    hi_p = None if qd is None else apower.copy()
    relax = []
    for t in np.flatnonzero(phase == 3):
        ds = DoubleSupport(h, F[t, 0], Mtot[t], fz[t], Pm[t], Rm[t], base[t])
        z0, rl = ds.admissible(rng, n)
        z, _ = ds.optimise(z0, lambda tq: (tq[:, legs] ** 2).sum(1), rng)
        tq, f, c, _ = ds.torques(z[None])
        tau[t], grf[t], cp[t] = tq[0], f[0], c[0]
        if qd is not None:
            pw = lambda tq: np.abs(tq * qd[t]).sum(1)          # noqa: E731
            lo_p[t] = min(ds.optimise(z0, pw, rng)[1], np.abs(tau[t] * qd[t]).sum())
            hi_p[t] = np.abs(tau[t] * qd[t]).sum() if rl == 5 else max(-ds.optimise(z0, lambda tq: -pw(tq), rng)[1], np.abs(tau[t] * qd[t]).sum())
        relax.append(rl)
    out = dict(tau=tau, grf=grf, cop=cp, phase=phase, ds_relax=np.array(relax, int), wrench_total=np.c_[F[:, 0], Mtot])
    if qd is not None:
        out.update(apower_lo=lo_p, apower_hi=hi_p)
    return out


def _leg_dofs(h):
    return [i for leg in h.legs for b in leg for i, _ in h.dofs[b]]
