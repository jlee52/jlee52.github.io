"""Self-contained HTML report of an evaluation (results of humanlike.engine.evaluate).

No plotting library is needed: charts are inline SVG, so the report is one file that opens anywhere
and the same code runs in the browser runtime.
"""
from __future__ import annotations

import html
import json

import numpy as np

W, H, PAD = 420, 260, 42
MODEL, HUMAN = "#1f6f8b", "#9aa4ad"


def _scale(lo, hi, a, b):
    lo, hi = float(lo), float(hi)
    if hi == lo:
        hi = lo + 1
    return lambda v: a + (np.asarray(v, float) - lo) / (hi - lo) * (b - a)


def _ticks(lo, hi, n=5):
    step = (hi - lo) / (n - 1) if hi > lo else 1
    return [lo + i * step for i in range(n)]


def _axes(xlo, xhi, ylo, yhi, xlabel, ylabel):
    sx, sy = _scale(xlo, xhi, PAD, W - 10), _scale(ylo, yhi, H - PAD, 10)
    out = [f'<line x1="{PAD}" y1="{H - PAD}" x2="{W - 10}" y2="{H - PAD}" class="ax"/>',
           f'<line x1="{PAD}" y1="10" x2="{PAD}" y2="{H - PAD}" class="ax"/>']
    for t in _ticks(xlo, xhi):
        x = sx(t)
        out.append(f'<text x="{x:.1f}" y="{H - PAD + 14}" class="tk" text-anchor="middle">{t:.3g}</text>')
    for t in _ticks(ylo, yhi):
        y = sy(t)
        out.append(f'<line x1="{PAD}" y1="{y:.1f}" x2="{W - 10}" y2="{y:.1f}" class="gr"/>')
        out.append(f'<text x="{PAD - 5}" y="{y + 3:.1f}" class="tk" text-anchor="end">{t:.3g}</text>')
    out.append(f'<text x="{(PAD + W) / 2:.0f}" y="{H - 6}" class="lb" text-anchor="middle">{html.escape(xlabel)}</text>')
    out.append(f'<text transform="translate(12,{H / 2:.0f}) rotate(-90)" class="lb" text-anchor="middle">{html.escape(ylabel)}</text>')
    return out, sx, sy


def scatter(series, xlabel, ylabel):
    """series: [(x, y, color, label, radius)]."""
    xs = np.concatenate([np.asarray(s[0], float) for s in series]); ys = np.concatenate([np.asarray(s[1], float) for s in series])
    ok = np.isfinite(xs) & np.isfinite(ys)
    xlo, xhi, ylo, yhi = xs[ok].min(), xs[ok].max(), ys[ok].min(), ys[ok].max()
    px, py = .05 * (xhi - xlo or 1), .08 * (yhi - ylo or 1)
    out, sx, sy = _axes(xlo - px, xhi + px, ylo - py, yhi + py, xlabel, ylabel)
    for x, y, c, _, r in series:
        for a, b in zip(sx(x), sy(y)):
            if np.isfinite(a) and np.isfinite(b):
                out.append(f'<circle cx="{a:.1f}" cy="{b:.1f}" r="{r}" fill="{c}" fill-opacity=".55"/>')
    return _svg(out, [(c, l) for _, _, c, l, _ in series])


def lines(series, xlabel, ylabel, band=None):
    """series: [(x, y, color, label)]; band: (x, lo, hi, color)."""
    vals = [np.asarray(s[1], float) for s in series] + ([np.asarray(band[1]), np.asarray(band[2])] if band else [])
    ys = np.concatenate(vals)
    x = np.asarray(series[0][0], float)
    py = .08 * (np.nanmax(ys) - np.nanmin(ys) or 1)
    out, sx, sy = _axes(x.min(), x.max(), np.nanmin(ys) - py, np.nanmax(ys) + py, xlabel, ylabel)
    if band:
        bx, lo, hi, c = band
        pts = [f"{a:.1f},{b:.1f}" for a, b in zip(sx(bx), sy(hi))] + [f"{a:.1f},{b:.1f}" for a, b in zip(sx(bx)[::-1], sy(lo)[::-1])]
        out.append(f'<polygon points="{" ".join(pts)}" fill="{c}" fill-opacity=".35"/>')
    for xx, yy, c, _ in series:
        pts = " ".join(f"{a:.1f},{b:.1f}" for a, b in zip(sx(xx), sy(yy)))
        out.append(f'<polyline points="{pts}" fill="none" stroke="{c}" stroke-width="2"/>')
    legend = [(c, l) for _, _, c, l in series] + ([(band[3], "human mean ± SD")] if band else [])
    return _svg(out, legend)


def _svg(parts, legend):
    leg = "".join(f'<span><i style="background:{c}"></i>{html.escape(l)}</span>' for c, l in legend)
    return (f'<figure><svg viewBox="0 0 {W} {H}" role="img">{"".join(parts)}</svg>'
            f'<figcaption class="legend">{leg}</figcaption></figure>')


def _fmt(v, d=3):
    if v is None:
        return "–"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, (int, float)):
        return "0" if abs(v) < 1e-4 else f"{v:.{d}g}"
    return html.escape(str(v))


def _status(st):
    cls = {"ok": "ok", "skipped": "skip", "error": "err"}[st["status"]]
    return f'<span class="pill {cls}">{st["status"]}</span>'


def render(res: dict) -> str:
    ds = res.get("dataset", {})
    S = res.get("stages", {})
    parts = [f"<h1>{html.escape(ds.get('name', 'Data set'))}</h1>",
             f"<p class='sub'>{res.get('n_rollouts', 0)} rollouts · {html.escape(ds.get('simulator', '') or '')} "
             f"{html.escape(ds.get('skeleton', '') or '')}</p>"]
    v = res["validation"]
    rows = "".join(f"<tr><td>{k}</td><td>{'available' if c['available'] else 'not available'}</td><td>{html.escape(c['reason'])}</td></tr>"
                   for k, c in v["capabilities"].items())
    parts.append(f"<section><h2>Data</h2><table><tr><th>Capability</th><th></th><th>What is missing</th></tr>{rows}</table>"
                 + "".join(f"<p class='warn'>{html.escape(w)}</p>" for w in v["warnings"][:10]) + "</section>")
    rows = "".join(f"<tr><td>{html.escape(st['title'])}</td><td>{_status(st)}</td><td>{html.escape(st.get('reason', '') or '')}</td>"
                   f"<td>{_fmt(st.get('seconds'))}</td></tr>" for st in S.values())
    parts.append(f"<section><h2>Analyses</h2><table><tr><th>Analysis</th><th>Status</th><th>Reason</th><th>s</th></tr>{rows}</table></section>")

    if S.get("gait_scaling", {}).get("status") == "ok":
        gs = S["gait_summary"]["result"]["rollouts"]
        sp = [r["speed"] for r in gs]
        sec = ["<section><h2>Feedforward signature</h2><p>Jensen–Shannon divergence (bits, 0 = identical, 1 = disjoint) of the "
               "speed–stride length and speed–stride frequency distributions from the reference.</p><div class='grid'>"]
        rows = []
        for name, r in S["gait_scaling"]["result"].items():
            if "skipped" in r:
                rows.append(f"<tr><td>{html.escape(name)}</td><td colspan=3>{html.escape(r['skipped'])}</td></tr>")
                continue
            rows.append(f"<tr><td>{html.escape(name)}</td><td>{r['n']}</td><td>{_fmt(r['js_stride_length'])}</td><td>{_fmt(r['js_stride_frequency'])}</td></tr>")
            R = r["reference"]
            for key, rk, lab in (("stride_length", "stride_lengths", "stride length (m)"), ("stride_frequency", "stride_frequencies", "stride frequency (1/s)")):
                sec.append(scatter([(R["speeds"], R[rk], HUMAN, name, 2.2), (sp, [x[key] for x in gs], MODEL, ds.get("name", "model"), 2.8)],
                                   "speed (m/s)", lab))
        sec.insert(1, f"<table><tr><th>Reference</th><th>n</th><th>JS stride length</th><th>JS stride frequency</th></tr>{''.join(rows)}</table>")
        parts.append("".join(sec) + "</div></section>")

    if S.get("feedback", {}).get("status") == "ok":
        fb = S["feedback"]["result"]
        rows = []
        for name, r in fb["references"].items():
            c = r["comparison"]
            rows.append(f"<tr><td>{html.escape(name)}</td><td>{_fmt(r['fpgd_mean'], 4)} ± {_fmt(r['fpgd_sd'], 3)}</td>"
                        f"<td>{_fmt(c.get('peak_dr2', {}).get('model_mean'))} vs {_fmt(c.get('peak_dr2', {}).get('reference_mean'))}"
                        f" (p {_fmt(c.get('peak_dr2', {}).get('p'), 2)})</td>"
                        f"<td>{_fmt(c.get('peak_timing', {}).get('model_mean'))} vs {_fmt(c.get('peak_timing', {}).get('reference_mean'))}"
                        f" (p {_fmt(c.get('peak_timing', {}).get('p'), 2)})</td></tr>")
        mag = np.asarray(S["foot_placement"]["result"]["ctl_mag"], float)
        fig = lines([(np.arange(mag.shape[1]), np.nanmean(mag, 0), MODEL, "model, mean over groups")], "gait cycle (%)",
                    "relative predictive power ΔR²") if mag.ndim == 2 and mag.size else ""
        parts.append("<section><h2>Feedback signature</h2><p>FPGD: distance of the foot-placement gains from the reference "
                     "(lower = closer). Peak ΔR² and its timing (% of the gait cycle), model vs reference (Welch / Games–Howell).</p>"
                     f"<table><tr><th>Reference</th><th>FPGD</th><th>Peak ΔR²</th><th>Peak timing (%)</th></tr>{''.join(rows)}</table>"
                     f"<div class='grid'>{fig}</div></section>")

    if S.get("energetics", {}).get("status") == "ok":
        en = S["energetics"]["result"]
        fit = en.get("fit") or {}
        parts.append("<section><h2>Energetic signature</h2>"
                     f"<p>Two-Gaussian classification: <b>{html.escape(en['label'])}</b> ({html.escape(en['reason'])}); "
                     f"walking and running optima {_fmt(fit.get('mu1'))} and {_fmt(fit.get('mu2'))} m/s, R² {_fmt(fit.get('r2'))}, DW {_fmt(fit.get('dw'))}.</p>"
                     f"<div class='grid'>{scatter([(en['speed'], en['cot'], MODEL, 'rollouts', 3)], 'speed (m/s)', 'mechanical COT')}</div></section>")

    if S.get("sagittal", {}).get("status") == "ok":
        sg = S["sagittal"]["result"]
        rows = "".join(f"<tr><td>{html.escape(f['label'])}</td><td>{_fmt(f['median_diff'])} {html.escape(f['unit'])}</td>"
                       f"<td>{_fmt(f['median_z'])}</td><td>{_fmt(f['consistent'])}</td></tr>" for f in sg["features"].values())
        C = np.asarray(sg["mean_cycle"], float)
        figs = "".join(lines([(np.arange(101), C[:, i], MODEL, f"{j}, mean over rollouts")], "gait cycle (%)", f"{j} angle (deg)")
                       for i, j in enumerate(("hip", "knee", "ankle")))
        parts.append(f"<section><h2>Sagittal joint angles</h2><p>{sg['consistent_features']} of 8 features within the human range "
                     f"(|median robust z| ≤ 2, {sg['n']} rollouts at the human speeds).</p>"
                     f"<table><tr><th>Feature</th><th>Median difference</th><th>Median z</th><th>Consistent</th></tr>{rows}</table>"
                     f"<div class='grid'>{figs}</div></section>")

    if S.get("gait_phases", {}).get("status") == "ok":
        m = S["gait_phases"]["result"]["median"]
        parts.append("<section><h2>Phases of the stride</h2><table><tr><th>Double support</th><th>Single support</th><th>Flight</th>"
                     f"<th>Rollouts with flight</th></tr><tr><td>{100 * m['double_support']:.1f}%</td><td>{100 * m['single_support']:.1f}%</td>"
                     f"<td>{100 * m['flight']:.1f}%</td><td>{100 * m['rollouts_with_flight']:.0f}%</td></tr></table>"
                     "<p>Humans walking at 0.9–1.5 m/s: about 21% double support and no flight.</p></section>")
    if S.get("kinetic_principles", {}).get("status") == "ok":
        kp = S["kinetic_principles"]["result"]
        mark = {True: '<span class="pill ok">consistent</span>', False: '<span class="pill err">not</span>', None: "n/a"}
        kind = {"magnitude": "median robust z", "direction": "slope on speed", "sign": "share of rollouts", "shape": "vertex speed (m/s)"}
        rows = "".join(f"<tr><td>{x['key']}</td><td>{html.escape(x['prediction'])}</td><td>{kind[x['kind']]}</td>"
                       f"<td>{_fmt(x['value'])}</td><td>{_fmt(x['human_value'])}</td><td>{mark[x['consistent']]}</td></tr>"
                       for x in kp["predictions"])
        by = " · ".join(f"{k} {html.escape(v['title'])}: {v['score']}" for k, v in kp["by_principle"].items())
        notes = []
        if not kp["joint_kinetics"]:
            notes.append("No sagittal joint moments: the joint-work predictions are n/a.")
        notes.append("Work and impulse " + ("made dimensionless with leg length (Hof 1996)." if kp["normalized"]
                                           else "per kilogram (no subject.leg_length_m)."))
        parts.append(f"<section><h2>Kinetic gait and biomechanical principles</h2><p><b>{kp['consistent']} of {kp['evaluated']}</b> "
                     f"predictions consistent with human walking ({kp['rollouts']} rollouts, {kp['strides']} strides of the "
                     f"{kp['foot']} foot at {kp['human_range'][0]:.2f}–{kp['human_range'][1]:.2f} m/s). {by}</p>"
                     f"<table><tr><th></th><th>Prediction</th><th>Measure</th><th>Model</th><th>Human</th><th></th></tr>{rows}</table>"
                     f"<p class='sub'>{' '.join(html.escape(n) for n in notes)} Criteria: |median z| ≤ 2; slope CI on the predicted "
                     "side of zero; at least 80% of the human share; concave with the vertex inside the speed range.</p></section>")
    body = "\n".join(parts)
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(ds.get('name', 'Evaluation'))} · humanlike report</title><style>{CSS}</style></head>
<body><main>{body}<details><summary>Raw results (JSON)</summary><pre>{html.escape(json.dumps(res, indent=1)[:200000])}</pre></details></main></body></html>"""


CSS = """
:root{--bg:#f6f7f8;--fg:#1c2329;--muted:#5a6570;--card:#fff;--line:#d9dee3}
@media (prefers-color-scheme:dark){:root{--bg:#14191d;--fg:#e4e9ed;--muted:#9aa5ae;--card:#1c2329;--line:#2f383f}}
body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1000px;margin:0 auto;padding:24px 16px 48px}
h1{margin:0 0 4px;font-size:1.5rem} h2{font-size:1.15rem;margin:0 0 8px} .sub{color:var(--muted);margin:0 0 20px}
section{background:var(--card);border:1px solid var(--line);border-radius:6px;padding:16px;margin:0 0 18px}
table{border-collapse:collapse;width:100%;font-size:.9rem;margin:6px 0 10px;font-variant-numeric:tabular-nums}
th,td{border-bottom:1px solid var(--line);padding:5px 8px;text-align:left} th{color:var(--muted);font-weight:600}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}
figure{margin:0} svg{width:100%;height:auto} .ax{stroke:var(--muted)} .gr{stroke:var(--line)}
.tk{font-size:10px;fill:var(--muted)} .lb{font-size:11px;fill:var(--fg)}
.legend{font-size:.8rem;color:var(--muted);display:flex;gap:12px;flex-wrap:wrap}
.legend i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:4px;vertical-align:middle}
.pill{padding:1px 8px;border-radius:10px;font-size:.8rem} .ok{background:#d6efe3;color:#145a3a} .skip{background:#eceff1;color:#4b5761}
.err{background:#f8d7d7;color:#7a1d1d} .warn{color:#8a5a00;font-size:.85rem;margin:2px 0}
pre{font-size:.75rem;max-height:400px;overflow:auto}
"""
