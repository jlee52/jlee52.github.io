"""Gait events from body positions.

Foot strike: a local maximum of the anteroposterior distance of the foot ahead of the pelvis
(the kinematic heel-strike criterion of Zeni et al., 2008, Gait & Posture 27:710-714), after a
4th-order zero-phase low-pass filter at 6 Hz. Peaks must exceed the mean and have a prominence of
at least 40 % of the largest peak after the first, as in the manuscript's analysis
(scripts/curate_mimickit_rollouts.py detect_hs). The walking direction is the first principal
component of the horizontal pelvis path.
"""
from __future__ import annotations

import numpy as np
from scipy.signal import butter, find_peaks, sosfiltfilt

CUTOFF_HZ = 6.0


def horizontal_axes(up: int) -> list[int]:
    return [i for i in range(3) if i != up]


def heading(pelvis: np.ndarray, up: int = 2) -> np.ndarray:
    """Unit vector (3D, horizontal) of the first principal component of the pelvis path, oriented
    in the direction of travel."""
    h = horizontal_axes(up)
    xy = np.asarray(pelvis, float)[:, h]
    xy = xy[np.isfinite(xy).all(1)]
    c = xy - xy.mean(0)
    _, _, vt = np.linalg.svd(c, full_matrices=False)
    d = vt[0]
    if np.dot(xy[-1] - xy[0], d) < 0:
        d = -d
    out = np.zeros(3)
    out[h] = d
    return out


def lowpass(x: np.ndarray, fs: float, cutoff: float = CUTOFF_HZ, order: int = 4) -> np.ndarray:
    if cutoff >= 0.5 * fs:
        return np.asarray(x, float)
    sos = butter(order, cutoff / (0.5 * fs), output="sos")
    return sosfiltfilt(sos, np.asarray(x, float), axis=0)


def foot_strikes(pelvis: np.ndarray, foot: np.ndarray, fs: float, up: int = 2, direction=None) -> np.ndarray:
    """Sample indices of the foot strikes of `foot` ([T, 3] positions; pelvis likewise)."""
    d = heading(pelvis, up) if direction is None else np.asarray(direction, float)
    src = lowpass(np.asarray(pelvis, float) @ d, fs)
    tgt = lowpass(np.asarray(foot, float) @ d, fs)
    diff = tgt - src
    diff = diff - diff.mean()
    pks, _ = find_peaks(diff, height=0, prominence=0.02)
    ref = (diff[pks[0] + 1:].max() if pks.size and pks[0] + 1 < len(diff) else diff.max())
    peaks, _ = find_peaks(diff, height=0, prominence=ref * 0.4)
    return np.sort(peaks)
