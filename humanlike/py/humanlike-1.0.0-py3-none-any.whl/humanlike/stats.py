"""Group comparisons as reported in the manuscript: Levene -> Welch ANOVA -> Games-Howell,
with Cohen's d and the 95% CI of the mean difference (diff +/- t_{.975,df} * se).

Implemented with scipy only (no pingouin), so the same code runs in the browser (Pyodide). The
formulas follow pingouin 0.5 (homoscedasticity, welch_anova, pairwise_gameshowell, compute_effsize),
which produced the published tables; tests/test_stats.py checks the two agree.
"""
from __future__ import annotations

from itertools import combinations

import numpy as np
import pandas as pd
from scipy import stats


def to_long(groups: dict[str, np.ndarray]) -> pd.DataFrame:
    return pd.DataFrame([(g, float(v)) for g, vals in groups.items() for v in vals
                         if np.isfinite(v)], columns=["group", "value"])


def levene_p(samples: list[np.ndarray]) -> float:
    """Levene's test (median-centred, as scipy and pingouin's default)."""
    return float(stats.levene(*samples, center="median").pvalue)


def welch_anova(samples: list[np.ndarray]) -> dict:
    """Welch's one-way ANOVA. np2: partial eta squared of the classical ANOVA (SS_between / SS_total)."""
    n = np.array([len(x) for x in samples], float)
    m = np.array([np.mean(x) for x in samples])
    v = np.array([np.var(x, ddof=1) for x in samples])
    k = len(samples)
    w = n / v
    mw = np.sum(w * m) / np.sum(w)
    num = np.sum(w * (m - mw) ** 2) / (k - 1)
    lam = 3 * np.sum((1 - w / w.sum()) ** 2 / (n - 1)) / (k ** 2 - 1)
    F = num / (1 + 2 * lam * (k - 2) / 3)
    df2 = 1 / lam
    allx = np.concatenate(samples)
    ss_between = np.sum(n * (m - allx.mean()) ** 2)
    ss_total = np.sum((allx - allx.mean()) ** 2)
    return {"F": float(F), "df1": float(k - 1), "df2": float(df2), "p": float(stats.f.sf(F, k - 1, df2)),
            "np2": float(ss_between / ss_total)}


def cohen_d(a, b) -> float:
    """Cohen's d with the pooled SD (independent samples)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    na, nb = len(a), len(b)
    sp = np.sqrt(((na - 1) * np.var(a, ddof=1) + (nb - 1) * np.var(b, ddof=1)) / (na + nb - 2))
    return float((a.mean() - b.mean()) / sp)


def games_howell(groups: dict[str, np.ndarray]) -> pd.DataFrame:
    """Games-Howell pairwise comparisons; pairs in sorted group order, A < B (as pingouin)."""
    names = sorted(groups)
    k = len(names)
    rows = []
    for a, b in combinations(names, 2):
        xa, xb = np.asarray(groups[a], float), np.asarray(groups[b], float)
        va, vb, na, nb = np.var(xa, ddof=1), np.var(xb, ddof=1), len(xa), len(xb)
        diff = xa.mean() - xb.mean()
        T = diff / np.sqrt(va / na + vb / nb)
        df = (va / na + vb / nb) ** 2 / ((va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1))
        p = stats.studentized_range.sf(np.sqrt(2) * abs(T), k, df)
        rows.append({"A": a, "B": b, "mean_A": xa.mean(), "mean_B": xb.mean(), "diff": diff,
                     "se": np.sqrt(va / na + vb / nb), "T": T, "df": df, "pval": min(float(p), 1.0)})
    return pd.DataFrame(rows)


def compare_groups(groups: dict[str, np.ndarray]) -> dict:
    df = to_long(groups)
    order = list(groups)
    clean = {g: df.value[df.group == g].to_numpy() for g in order if (df.group == g).any()}
    desc = (df.groupby("group", sort=False)["value"].agg(n="count", mean="mean", sd="std")
              .reindex(order).reset_index())
    gh = games_howell(clean)
    t = stats.t.ppf(0.975, gh["df"])
    gh["ci_low"], gh["ci_high"] = gh["diff"] - t * gh["se"], gh["diff"] + t * gh["se"]
    gh["cohen_d"] = [cohen_d(clean[a], clean[b]) for a, b in zip(gh.A, gh.B)]
    samples = list(clean.values())
    return {
        "descriptives": desc,
        "levene_p": levene_p(samples),
        "welch": welch_anova(samples),
        "posthoc": gh[["A", "B", "mean_A", "mean_B", "diff", "se", "T", "df", "pval",
                       "cohen_d", "ci_low", "ci_high"]],
    }
