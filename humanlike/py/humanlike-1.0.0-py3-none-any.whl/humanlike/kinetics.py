"""Kinetic gait features from ground reaction forces (GRF) and joint torques, shared by the human
reference (Camargo et al. 2021 force plates and inverse dynamics) and the simulated rollouts.

Conventions
  * forces in body weights (BW), joint moments in N m / kg, powers in W / kg, work in J / kg
  * GRF low-pass filtered (4th-order zero-phase Butterworth, FILTER_HZ) before events and features,
    as force-plate data; signals sampled too slowly for the filter are used as recorded
  * stance = vertical GRF above CONTACT_BW; a stride runs from one foot strike to the next of
    the same foot
  * anteroposterior (AP) force along the walking direction: negative = braking, positive = propulsion
  * joint angles, moments and powers are sagittal, + = flexion / dorsiflexion moment

Per stride: speed, stance fraction, vertical first peak, mid-stance valley and second peak, braking
and propulsive impulse, peak braking and propulsive force, and the positive and negative work of
the hip, knee and ankle over the stride. The `tot_*` impulses use the total AP force of both feet over
the whole stride.

Centre-of-mass (COM) features (COM_FEATURES, `com_features`), from both feet's GRF and the COM velocity
and height:
  * double support: fraction of the stride with both feet in contact
  * step-to-step transition (individual-limbs method, Donelan, Kram & Kuo 2002): during the double
    support that starts at the stride's foot strike, the negative work of the leading (reference) leg
    on the COM (collision) and the positive work of the trailing leg (push-off), J/kg, with leg power
    F_leg . v_COM; and the time of the trailing leg's peak power relative to the foot strike (% stride)
  * pendular energy recovery (Cavagna, Thys & Zamboni 1976): R = (W_f + W_v - W_ext) / (W_f + W_v),
    with W the summed positive increments over the stride of the horizontal kinetic energy (W_f), of
    the potential plus vertical kinetic energy (W_v) and of their sum (W_ext), %
For force-plate data the COM velocity and height come from integrating the total GRF over the stride
(`com_from_grf`); for the simulations they are the simulated COM.
"""
from __future__ import annotations

import numpy as np
from scipy.interpolate import interp1d
from scipy.signal import butter, sosfiltfilt

FILTER_HZ = 20.0
CONTACT_BW = 0.05
MIN_STANCE_S = 0.10
JOINTS = ("Hip", "Knee", "Ankle")
FEATURES = ("speed", "stride_time", "stance_frac", "fz_peak1", "fz_valley", "fz_peak2", "brake_impulse",
            "propel_impulse", "brake_peak", "propel_peak", "tot_brake_impulse", "tot_propel_impulse",
            *[f"{j.lower()}_{s}_work" for j in JOINTS for s in ("pos", "neg")],
            "double_support", "collision_work", "pushoff_work", "pushoff_peak_time", "recovery")
COM_FEATURES = ("double_support", "collision_work", "pushoff_work", "pushoff_peak_time", "recovery")
G = 9.81


def lowpass(x, fs, hz=FILTER_HZ, axis=0):
    """Zero-phase 4th-order Butterworth low-pass; returned unchanged if fs <= 2.5 * hz."""
    x = np.asarray(x, dtype=float)
    if fs <= 2.5 * hz or x.shape[axis] < 30:
        return x
    return sosfiltfilt(butter(4, hz / (0.5 * fs), output="sos"), x, axis=axis)


def foot_strikes(fz_bw, fs):
    """Indices where the vertical GRF (BW) rises through CONTACT_BW after at least MIN_STANCE_S of swing
    or stance on either side (rejects flicker at contact)."""
    on = np.asarray(fz_bw) > CONTACT_BW
    up = np.flatnonzero(~on[:-1] & on[1:]) + 1
    down = np.flatnonzero(on[:-1] & ~on[1:]) + 1
    keep, n = [], int(MIN_STANCE_S * fs)
    for u in up:
        nxt = down[down > u]
        if nxt.size and nxt[0] - u >= n and (not keep or u - keep[-1] >= 2 * n):
            keep.append(u)
    return np.array(keep, dtype=int)


def resample(x, n=101):
    x = np.asarray(x, dtype=float)
    return interp1d(np.linspace(0, 100, len(x)), x, axis=0)(np.linspace(0, 100, n))


def stride_features(fz, fap, mom, power, fs, speed, power_fs=None, fap_total=None):
    """Features of one stride. Arrays run from a foot strike to the next strike of the same foot, both
    included (humanlike.gait): the features use the samples of the stride (all but the last), the
    101-sample cycles all of them (0 % and 100 % at the strikes).

    fz, fap: vertical and AP GRF (BW) at fs; mom, power: [n, 3] hip/knee/ankle (N m/kg, W/kg) at
    power_fs (defaults to fs); fap_total: AP force of both feet (BW) at fs.
    Returns (feature dict, cycles dict of 101-sample curves)."""
    cz, cap = np.asarray(fz, float), np.asarray(fap, float)
    cmom, cp = np.asarray(mom, float), np.asarray(power, float)
    cft = np.full(len(cz), np.nan) if fap_total is None else np.asarray(fap_total, float)
    fz, fap, mom, power = cz[:-1], cap[:-1], cmom[:-1], cp[:-1]
    fap_total = None if fap_total is None else cft[:-1]
    pfs = power_fs or fs
    on = fz > CONTACT_BW
    off = np.flatnonzero(~on)
    st_end = int(off[0]) if off.size else len(fz)                    # first sample of swing
    stance = slice(0, st_end)
    sz, sa = fz[stance], fap[stance]
    half = max(1, st_end // 2)
    i1 = int(np.argmax(sz[:half])); i2 = half + int(np.argmax(sz[half:])) if st_end > half else i1
    valley = float(sz[i1:i2 + 1].min()) if i2 > i1 else np.nan
    dt = 1.0 / fs
    f = dict(speed=float(speed), stride_time=len(fz) / fs, stance_frac=st_end / len(fz),
             fz_peak1=float(sz[i1]), fz_valley=valley, fz_peak2=float(sz[i2]) if st_end > half else np.nan,
             brake_impulse=float(np.clip(sa, None, 0).sum() * dt), propel_impulse=float(np.clip(sa, 0, None).sum() * dt),
             brake_peak=float(sa.min()), propel_peak=float(sa.max()))
    ft = np.full(len(fz), np.nan) if fap_total is None else np.asarray(fap_total, float)
    f["tot_brake_impulse"] = float(np.clip(ft, None, 0).sum() * dt)
    f["tot_propel_impulse"] = float(np.clip(ft, 0, None).sum() * dt)
    p = np.asarray(power, float)
    for k, j in enumerate(JOINTS):
        f[f"{j.lower()}_pos_work"] = float(np.clip(p[:, k], 0, None).sum() / pfs)
        f[f"{j.lower()}_neg_work"] = float(np.clip(p[:, k], None, 0).sum() / pfs)
    f.update(dict.fromkeys(COM_FEATURES, np.nan))                     # filled by the caller (com_features)
    cyc = dict(fz=resample(cz), fap=resample(cap), fap_total=resample(cft), moment=resample(cmom), power=resample(cp))
    return f, cyc


def com_from_grf(f_total, fs, speed):
    """COM velocity [n, 3] (AP, ML, vertical; m/s) and height [n] (m) over one steady stride from the
    total GRF of both feet [n, 3] (BW, same axes): the integral of the acceleration g (F - e_z), with
    the drift removed so that the stride is periodic, mean AP velocity = speed (treadmill belt speed,
    i.e. the overground frame), mean ML and vertical velocity = 0, and mean height 0."""
    a = G * (np.asarray(f_total, float) - np.array([0.0, 0.0, 1.0]))
    v = np.cumsum(a, axis=0) / fs
    n = len(v)
    v -= np.outer(np.arange(n) / max(n - 1, 1), v[-1] - v[0])          # periodic
    v -= v.mean(0)
    v[:, 0] += speed
    z = np.cumsum(v[:, 2]) / fs
    z -= np.linspace(0, 1, n) * (z[-1] - z[0])
    return v, z - z.mean()


def com_features(f_ref, f_con, v, z, fs, i0, i1, pre=None):
    """Step-to-step transition and pendular-recovery features of the stride [i0, i1).

    f_ref, f_con: GRF of the reference (stride) foot and of the other foot [n, 3] (BW; AP, ML,
    vertical); v [n, 3] COM velocity (m/s; AP absolute, ML, vertical); z [n] COM height (m); all on
    one time base at fs, covering at least [i0 - pre, i1) where pre (samples, default a quarter
    stride) is the window searched for the trailing leg's power peak before the foot strike."""
    f_ref, f_con, v, z = (np.asarray(x, float) for x in (f_ref, f_con, v, z))
    n = i1 - i0
    pre = n // 4 if pre is None else pre
    out = dict.fromkeys(COM_FEATURES, np.nan)
    both = (f_ref[i0:i1, 2] > CONTACT_BW) & (f_con[i0:i1, 2] > CONTACT_BW)
    out["double_support"] = float(both.mean())                           # fraction of the stride
    p_ref = G * np.sum(f_ref * v, axis=1)                                # W/kg
    p_con = G * np.sum(f_con * v, axis=1)
    # double support from the foot strike to the other foot's toe-off
    if f_con[i0, 2] > CONTACT_BW:
        off = np.flatnonzero(f_con[i0:i1, 2] <= CONTACT_BW)
        if off.size:
            j = i0 + int(off[0])
            out["collision_work"] = float(np.clip(p_ref[i0:j], None, 0).sum() / fs)
            out["pushoff_work"] = float(np.clip(p_con[i0:j], 0, None).sum() / fs)
            k0 = max(0, i0 - pre)
            out["pushoff_peak_time"] = float((k0 + np.argmax(p_con[k0:j]) - i0) / n * 100)
    ep = G * z[i0:i1] + 0.5 * v[i0:i1, 2] ** 2                           # potential + vertical kinetic, J/kg
    ek = 0.5 * (v[i0:i1, 0] ** 2 + v[i0:i1, 1] ** 2)                       # horizontal kinetic
    pos = lambda e: float(np.clip(np.diff(e), 0, None).sum())            # noqa: E731
    wf, wv, wext = pos(ek), pos(ep), pos(ek + ep)
    if wf + wv > 0:
        out["recovery"] = 100 * (wf + wv - wext) / (wf + wv)
    return out


def rollout_strides(fz, fap_xy, comv, mom, pw, fs, pfs, start, ok=None, fxy_total=None, feet=None, comz=None, pelvis=None):
    """Feature rows and cycles of the strides of one rollout. fz [n] (BW); fap_xy [n, 2] horizontal GRF
    of the foot (BW); comv [n, 3]; mom, pw [m, 3] at pfs; ok(a, b) -> bool filters strides by
    physics-row range; fxy_total [n, 2]: horizontal force of both feet (BW); feet [n, 2, 3]: GRF of the
    stride foot and of the other foot (BW, world axes) and comz [n] COM height (m) for the COM features;
    pelvis [n, 3] (m): the stride speed (humanlike.gait.stride_speed). Cycles include both strikes.
    comv None: no centre-of-mass data; the walking direction is the pelvis's and the COM velocity and
    height of each stride come from integrating the total GRF of the feet (com_from_grf), as for the
    force-plate data of the human reference."""
    fzf = lowpass(fz, fs); fxy = lowpass(fap_xy, fs)
    fxt = lowpass(fxy_total, fs) if fxy_total is not None else None
    from .gait import stride_speed
    pv = np.gradient(np.asarray(pelvis, float)[:, :2], 1 / fs, axis=0)
    grf_com = comv is None
    if grf_com:
        comv = np.c_[pv, np.zeros(len(pv))]
    hs = foot_strikes(fzf, fs)
    hs = hs[hs >= start]
    rows, cycs = [], []
    for a, b in zip(hs[:-1], hs[1:]):
        if ok is not None and not ok(a, b):
            continue
        vxy = comv[a:b, :2].mean(0)                            # walking direction of the stride
        if np.linalg.norm(vxy) < 1e-3:
            continue
        u2 = vxy / np.linalg.norm(vxy)
        sp = stride_speed(None, a, b, fs, vel=pv)
        fap = fxy[a:b + 1] @ u2
        pa, pb = int(round(a * pfs / fs)), int(round(b * pfs / fs))
        if pb - pa < 4:
            continue
        f, c = stride_features(fzf[a:b + 1], fap, mom[pa:pb + 1], pw[pa:pb + 1], fs, sp, power_fs=pfs,
                               fap_total=None if fxt is None else fxt[a:b + 1] @ u2)
        pre = (b - a) // 4
        if feet is not None and a >= pre:                      # COM features in walking-direction axes
            u = np.r_[u2, 0.0]; w = np.array([-u[1], u[0], 0.0]); e = np.array([0.0, 0.0, 1.0])
            axes = np.stack([u, w, e], 1)
            fr, fc = (lowpass(feet[a - pre:b, i], fs) @ axes for i in (0, 1))
            if grf_com:                                        # periodic stride, preceded by its own end
                vc, zc = com_from_grf(fr[pre:] + fc[pre:], fs, sp)
                f.update(com_features(fr, fc, np.r_[vc[-pre:], vc], np.r_[zc[-pre:], zc], fs, pre, pre + b - a, pre))
            else:
                f.update(com_features(fr, fc, comv[a - pre:b] @ axes, comz[a - pre:b], fs, pre, pre + b - a, pre))
        rows.append([f[k] for k in FEATURES]); cycs.append(c)
    return rows, cycs
