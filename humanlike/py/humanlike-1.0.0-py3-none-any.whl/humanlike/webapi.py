"""The two calls behind the web app, shared by the browser runtime (Pyodide, web/app/worker.js) and the
local server (`humanlike serve`):

    inspect(path)                     what the file is and what the mapping step can offer
                                      (CSV header and a proposed column mapping, C3D marker labels and
                                      force plates, BVH joints, Minari profile metadata, HLB contents)
    run(path, kind, options, ...)     convert with the chosen options, validate, evaluate, render the
                                      report; returns {"results", "report_html", "summary"}

`path` is a file (.hlb, .c3d, .bvh, .csv) or a Minari dataset directory.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

KINDS = {".hlb": "hlb", ".c3d": "c3d", ".bvh": "bvh", ".csv": "csv", ".txt": "csv"}


def kind_of(path) -> str:
    p = Path(path)
    if p.is_dir():
        return "minari"
    k = KINDS.get(p.suffix.lower())
    if k is None:
        raise ValueError(f"{p.name}: unsupported file type (use .hlb, .c3d, .bvh, .csv or a Minari dataset folder)")
    return k


def _csv_proposal(header: list) -> dict:
    """Proposed CSV mapping {signal: [columns]} from the naming conventions of the CSV adapter."""
    from .adapters.csv import _columns_for
    from .format.spec import FIELDS
    out = {}
    for f in FIELDS:
        c = _columns_for(f.name, header, {})
        if c:
            out[f.name] = c
    return out


def inspect(path) -> dict:
    kind = kind_of(path)
    p = Path(path)
    out = {"kind": kind, "name": p.stem if kind != "minari" else p.name}
    if kind == "csv":
        with open(p, newline="") as fh:
            header = [h.strip() for h in fh.readline().split(",")]
            first = fh.readline().split(",")
        out.update(header=header, proposal=_csv_proposal(header), has_time="time" in [h.lower() for h in header],
                   first_row=[x.strip() for x in first])
    elif kind == "c3d":
        from .adapters.c3d import FEET, PELVIS
        from .adapters.c3d_reader import force_platforms, read_c3d
        c = read_c3d(p)
        plates = [x for x in force_platforms(c) if x is not None]
        names = c.parameters.get("SUBJECTS", {}).get("NAMES")
        out.update(labels=c.labels, rate=c.rate, frames=len(c.points), units=c.point_units, plates=len(plates),
                   subject=(names[0] if isinstance(names, list) and names else None),
                   proposal={"pelvis": next((list(s) for s in PELVIS if all(m in c.labels for m in s)), []),
                             "left_foot": FEET["left"] if FEET["left"] in c.labels else None,
                             "right_foot": FEET["right"] if FEET["right"] in c.labels else None})
    elif kind == "bvh":
        from .adapters.bvh import LEFT, PELVIS, RIGHT, _find, parse_bvh
        joints, dt, motion = parse_bvh(p.read_text())
        names = [j.name for j in joints if not j.name.endswith("_end")]

        def guess(c):
            try:
                return names[_find(names, c)]
            except KeyError:
                return None
        out.update(joints=names, rate=1 / dt, frames=len(motion),
                   proposal={"pelvis": guess(PELVIS), "left_foot": guess(LEFT), "right_foot": guess(RIGHT)})
    elif kind == "minari":
        from .adapters.minari_io import META, data_dir
        meta = json.loads((data_dir(p) / "metadata.json").read_text())
        out.update(dataset_id=meta.get("dataset_id"), episodes=meta.get("total_episodes"), steps=meta.get("total_steps"),
                   data_format=meta.get("data_format"), profile=meta.get(META))
    else:
        from .format import read, validate
        ds = read(p)
        out.update(name=ds.name, rollouts=len(ds.rollouts), capabilities=validate(ds).to_dict()["capabilities"])
    return out


def load(path, kind: str, options: dict):
    """Convert the input with the options chosen in the mapping step."""
    o = {k: v for k, v in (options or {}).items() if v not in (None, "")}
    name = o.pop("name", None) or Path(path).stem
    if kind == "hlb":
        from .format import read
        ds = read(path)
    elif kind == "minari":
        from .adapters import minari_io
        ds = minari_io.read(path, name=name)
    elif kind == "c3d":
        from .adapters.c3d import convert
        feet = {k: o.pop(f"{k}_foot") for k in ("left", "right") if f"{k}_foot" in o}
        ts = o.pop("treadmill_speed", None)
        if ts not in (None, "auto"):
            ts = float(ts)
        ds = convert(path, name, feet=feet or None, treadmill_speed=ts, **_num(o, ("mass_kg", "leg_length_m")))
    elif kind == "bvh":
        from .adapters.bvh import convert
        ds = convert(path, name, **_num(o, ("mass_kg", "leg_length_m")))
    else:
        from .adapters.csv import convert
        ds = convert(path, name, **_num(o, ("fs", "mass_kg", "leg_length_m")))
    if kind in ("hlb", "minari"):
        for key in ("mass_kg", "leg_length_m"):
            if key in o:
                ds.meta.setdefault("subject", {})[key] = float(o[key])
    return ds


def _num(o: dict, keys) -> dict:
    return {k: (float(v) if k in keys else v) for k, v in o.items()}


def run(path, kind: str, options: dict | None = None, references: dict | None = None, progress=None, cache=None) -> dict:
    from .engine import evaluate
    from .report import render
    ds = load(path, kind, options or {})
    res = evaluate(ds, references=references, progress=progress, cache=cache)
    st = res["stages"]
    summary = {"name": ds.name, "rollouts": len(ds.rollouts), "ok": res["validation"]["ok"],
               "stages": {k: v["status"] for k, v in st.items()}}
    return {"results": res, "report_html": render(res), "summary": summary}


def run_json(path, kind, options_json="{}", progress=None) -> str:
    """run() for the browser worker: options and the return value as JSON strings."""
    out = run(path, kind, json.loads(options_json or "{}"), progress=progress)
    return json.dumps(out, default=lambda x: x.tolist() if isinstance(x, np.ndarray) else str(x))
