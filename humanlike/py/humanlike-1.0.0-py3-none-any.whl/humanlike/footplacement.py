"""Lateral foot-placement control model (manuscript Methods, Feedback signature; Supplement S1).

Produces the `ft_ctl` arrays that humanlike.feedback consumes:
    gains    [n_groups, 101, 5]  phase-resolved OLS coefficients [g0, b_x, b_y, b_vx, b_vy]
    ctl_mag  [n_groups, 101]     dR^2(phi) = R^2(pelvis-state model) - R^2(swing-foot baseline)
    ctl_intercept [n_groups]     R^2 of the pelvis-state model at heel strike (phase 0)

Pipeline
    stride_features()          body trajectories + heel strikes -> per-stride inputs and target
    mirror_right()             reflect right-limb strides into the left-limb convention
    foot_placement_control()   per-group normalisation + phase-wise regression -> ft_ctl dict

Everything takes plain arrays, so it works for simulations (any physics backend), motion
capture and the preprocessed Camargo et al. (2021) strides alike. A group is the unit of
replication: one rollout session (simulation) or one subject (human).
"""
from __future__ import annotations

import numpy as np
from scipy.interpolate import interp1d
from scipy.signal import detrend
from scipy.stats import linregress

N_PHASE = 101


def path_tortuosity(xy: np.ndarray) -> float:
    """Path length / straight-line distance (>= 1)."""
    if len(xy) < 2:
        raise ValueError("path needs at least two points")
    length = np.sum(np.linalg.norm(np.diff(xy, axis=0), axis=1))
    chord = np.linalg.norm(xy[-1] - xy[0])
    if chord == 0:
        return 1.0 if length == 0 else float("inf")
    return float(length / chord)


# --------------------------------------------------------------------------- #
# 1. Stride extraction from trajectories
# --------------------------------------------------------------------------- #
def stride_features(pelvis, lead, trail, heel_strikes, dt, tortuosity_thr=1.02, legacy_expert=False):
    """Time-normalised, heading-aligned strides of one trajectory.

    pelvis, lead, trail: [T, 3] world positions (lead = the reference limb whose consecutive
    heel strikes delimit a stride). heel_strikes: frame indices of the lead limb.

    Returns (foot_in [n,101,4], pelvis_in [n,101,4], target [n,2], tortuosity [n]):
    inputs are [x, y, vx, vy] relative to the trailing foot at the end of the stride, in a
    frame whose x axis is the initial pelvis heading; target is the realised lead-foot
    placement [r_x, r_y]. Strides with tortuosity >= tortuosity_thr are dropped.

    Trajectories are processed in float64. With float32 input (Isaac Gym rollouts), results
    depended on the CPU's SIMD code path: the lateral pelvis velocity at heel strike is zero by
    construction of the heading-aligned frame, so its float32 rounding residue was fitted as a
    gain of order 1e5 at phase 0, and all other values differed at the 1e-8 level.

    legacy_expert: reproduce the expert reference fits (AMASS, KIT; loco-benchmark
    process_amass.ipynb), whose stride loop normalised the heading in place
    (`fwd_vec = pel_vel[st, :2]; fwd_vec /= norm`). Because fwd_vec is a view, this overwrote
    the pelvis velocity at each stride's first frame with a unit vector before interpolation.
    """
    pelvis, lead, trail = (np.asarray(a, dtype=np.float64) for a in (pelvis, lead, trail))
    t_norm = np.linspace(0, 100, N_PHASE)
    pel_v = np.gradient(pelvis, dt, axis=0)
    lead_v = np.gradient(lead, dt, axis=0)
    foot_in, pel_in, target, tort_out = [], [], [], []
    if heel_strikes is None or len(heel_strikes) < 2:
        return _stack(foot_in, pel_in, target, tort_out)

    for st, end in zip(heel_strikes[:-1], heel_strikes[1:]):
        if end <= st + 2:                                    # cubic interpolation needs 4 samples
            continue
        heading = pel_v[st, :2]
        nrm = np.linalg.norm(heading)
        if legacy_expert:
            heading /= (nrm + 1e-12)        # in place: modifies pel_v[st, :2] (see docstring)
        else:
            if not np.isfinite(nrm) or nrm < 1e-12:
                continue
            heading = heading / (nrm + 1e-12)
        angle = np.arctan2(heading[0], heading[1]) - np.pi / 2
        c, s = np.cos(angle), np.sin(angle)
        rot = np.array([[c, s], [-s, c]])
        p0 = lead[st, :2]
        t_cur = np.linspace(0, 100, end - st)

        def aligned(pos, vel=None):
            p = np.hstack([(pos[st:end, :2] - p0) @ rot, pos[st:end, 2:3]])
            p = interp1d(t_cur, p, axis=0, kind="cubic")(t_norm)
            if vel is None:
                return p
            return p, interp1d(t_cur, vel[st:end, :2] @ rot, axis=0, kind="cubic")(t_norm)

        try:
            lead_p, lead_pv = aligned(lead, lead_v)
            pel_p, pel_pv = aligned(pelvis, pel_v)
            trail_p = aligned(trail)
        except ValueError:
            continue
        ref = trail_p[-1]                                     # trailing foot at end of stride
        try:
            tort = path_tortuosity((pel_p - ref)[:, :2])
        except ValueError:
            continue
        if not np.isfinite(tort) or not tort < tortuosity_thr:
            continue
        foot_in.append(np.hstack([(lead_p - ref)[:, :2], lead_pv]))
        pel_in.append(np.hstack([(pel_p - ref)[:, :2], pel_pv]))
        target.append((lead_p[-1] - ref)[:2])
        tort_out.append(tort)
    return _stack(foot_in, pel_in, target, tort_out)


def _stack(foot_in, pel_in, target, tort):
    if not foot_in:
        return (np.empty((0, N_PHASE, 4)), np.empty((0, N_PHASE, 4)), np.empty((0, 2)), np.empty(0))
    return np.asarray(foot_in), np.asarray(pel_in), np.asarray(target), np.asarray(tort)


def mirror_right(foot_in, pelvis_in, target):
    """Reflect right-limb strides into the left-limb convention (negate mediolateral terms)."""
    f, p, t = foot_in.copy(), pelvis_in.copy(), target.copy()
    for a in (f, p):
        a[:, :, 1] *= -1
        a[:, :, 3] *= -1
    t[:, 1] *= -1
    return f, p, t


# --------------------------------------------------------------------------- #
# 2. Phase-wise regression
# --------------------------------------------------------------------------- #
def _ols(X, y):
    ok = ~np.isnan(X).any(axis=1) & ~np.isnan(y)
    X, y = X[ok], y[ok]
    if len(y) <= X.shape[1]:
        return np.nan, np.full(X.shape[1], np.nan)
    coef, res, *_ = np.linalg.lstsq(X, y, rcond=None)
    sst = np.sum((y - y.mean()) ** 2)
    ssr = res[0] if res.size else np.sum((y - X @ coef) ** 2)
    return (1 - ssr / sst if sst != 0 else np.nan), coef


def pelvis_model(pelvis_in, target, groups, direction=1):
    """R^2 [g,101] and gains [g,101,5] of target ~ g0 + G(phi) s_pel(phi), per group.

    Normalisation within each group (Supplement): x_pel linearly detrended over the stride,
    vx_pel centred by its stride mean, y_pel and vy_pel centred by their phase-wise ensemble
    mean; r_x regressed on mean stride velocity (direction 0) or r_y centred (direction 1).
    """
    ids = np.unique(groups)
    n_t, n_f = pelvis_in.shape[1:]
    r2 = np.zeros((len(ids), n_t))
    gains = np.zeros((len(ids), n_t, n_f + 1))
    for i, g in enumerate(ids):
        m = groups == g
        x = pelvis_in[m].copy()
        y = target[m, direction].copy()
        x[:, :, 1] -= np.nanmean(x[:, :, 1], axis=0)
        x[:, :, 3] -= np.nanmean(x[:, :, 3], axis=0)
        mean_v = np.nanmean(x[:, :, 2], axis=1)
        x[:, :, 2] -= mean_v[:, None]
        x[:, :, 0] = detrend(x[:, :, 0], axis=1, type="linear")
        if direction == 0:
            fit = linregress(mean_v, y)
            y = y - (mean_v * fit.slope + fit.intercept)
        else:
            y = y - np.nanmean(y)
        if len(y) <= 1:
            r2[i], gains[i] = np.nan, np.nan
            continue
        for t in range(n_t):
            r2[i, t], gains[i, t] = _ols(np.column_stack([np.ones(len(y)), x[:, t]]), y)
    return r2, gains


def foot_baseline(foot_in, target, groups, direction=1):
    """R^2 [g,101] of the swing-foot-state baseline (no input normalisation; target centred)."""
    ids = np.unique(groups)
    r2 = np.zeros((len(ids), foot_in.shape[1]))
    for i, g in enumerate(ids):
        m = groups == g
        x, y = foot_in[m], target[m, direction] - np.nanmean(target[m, direction])
        if len(y) <= 1:
            r2[i] = np.nan
            continue
        for t in range(foot_in.shape[1]):
            r2[i, t], _ = _ols(np.column_stack([np.ones(len(y)), x[:, t]]), y)
    return r2


def foot_placement_control(pelvis_in, foot_in, target, groups, direction=1) -> dict:
    """The ft_ctl dict used by humanlike.feedback (mediolateral direction by default)."""
    r2, gains = pelvis_model(pelvis_in, target, groups, direction)
    r2_bs = foot_baseline(foot_in, target, groups, direction)
    return {"ctl_mag": r2 - r2_bs, "ctl_intercept": r2[:, 0], "gains": gains}


def random_groups(keys, n_groups, seed=42) -> dict:
    """Pseudo-sessions for single-trajectory data (expert motion capture): sample
    n_groups * (len(keys) // n_groups) keys without replacement and split them into n_groups
    groups, as in the expert reference fits (numpy default_rng). Returns {key: group}; keys
    left over are not used."""
    keys = np.asarray(keys)
    size = len(keys) // n_groups
    picked = np.random.default_rng(seed).choice(keys, size=n_groups * size, replace=False)
    return {k: g for g, ks in enumerate(picked.reshape(n_groups, size)) for k in ks}


def from_trajectories(trajectories, dt, tortuosity_thr=1.02, direction=1, legacy_expert=False) -> dict:
    """Convenience: ft_ctl from many trajectories, both limbs pooled per group.

    trajectories: iterable of dicts with keys group, pelvis, l_foot, r_foot ([T,3] each),
    l_heel_strikes, r_heel_strikes.
    """
    parts = []
    for tr in trajectories:
        for side, lead, trail in (("l", "l_foot", "r_foot"), ("r", "r_foot", "l_foot")):
            f, p, t, _ = stride_features(tr["pelvis"], tr[lead], tr[trail], tr[f"{side}_heel_strikes"],
                                         dt, tortuosity_thr, legacy_expert)
            if side == "r":
                f, p, t = mirror_right(f, p, t)
            parts.append((side, f, p, t, np.full(len(t), tr["group"])))
    # left-limb strides first, then mirrored right-limb strides (as in the original analysis)
    parts.sort(key=lambda x: x[0])
    f, p, t, g = (np.concatenate([x[i] for x in parts]) for i in range(1, 5))
    return foot_placement_control(p, f, t, g, direction)
