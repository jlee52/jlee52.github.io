"""Content-addressed cache of stage results.

A stage's result is reused when nothing it depends on has changed. Its key is the SHA-256 of
    the stage name, the fingerprint of the humanlike source code (every .py file of the package),
    the fingerprint of the data set (metadata and every array), the keys of the stages it runs after,
    the references it reads (names and their checksums in the bundle manifest) and its options.
Each entry holds the stage's result and the intermediate arrays it passes to later stages. Entries
are written as JSON plus an .npz of the arrays (no pickle, so reading a cache never runs code).

    DirCache(path)   files under path (default $HUMANLIKE_CACHE or ~/.cache/humanlike)
    MemoryCache()    a dict, for the browser and tests
"""
from __future__ import annotations

import hashlib
import io
import json
import os
from pathlib import Path

import numpy as np

_CODE: str | None = None


def code_fingerprint() -> str:
    """SHA-256 of the package's Python sources: any change to the code invalidates every entry."""
    global _CODE
    if _CODE is None:
        h = hashlib.sha256()
        root = Path(__file__).resolve().parent
        for f in sorted(root.rglob("*.py")):
            h.update(str(f.relative_to(root)).encode()); h.update(f.read_bytes())
        _CODE = h.hexdigest()
    return _CODE


def data_fingerprint(ds) -> str:
    h = hashlib.sha256(json.dumps(ds.meta, sort_keys=True, default=str).encode())
    for r in ds.rollouts:
        h.update(json.dumps(r.meta, sort_keys=True, default=str).encode())
        for name in sorted(r.arrays):
            a = np.ascontiguousarray(r.arrays[name])
            h.update(f"{name}|{a.dtype.str}|{a.shape}".encode()); h.update(a.tobytes())
    return h.hexdigest()


def stage_key(**parts) -> str:
    return hashlib.sha256(json.dumps(parts, sort_keys=True, default=str).encode()).hexdigest()


# --- serialization: nested dicts / lists of arrays, numbers, strings, DataFrames -------------------
def pack(obj, arrays: dict):
    if isinstance(obj, np.ndarray) and obj.dtype != object:
        k = f"a{len(arrays)}"
        arrays[k] = obj
        return {"__nd__": k}
    if isinstance(obj, dict):
        return {"__dict__": [[pack(k, arrays), pack(v, arrays)] for k, v in obj.items()]}
    if isinstance(obj, (list, tuple)):
        return {"__list__": [pack(v, arrays) for v in obj], "tuple": isinstance(obj, tuple)}
    if hasattr(obj, "to_dict") and hasattr(obj, "columns"):
        return {"__df__": pack(obj.to_dict(orient="list"), arrays), "columns": [str(c) for c in obj.columns]}
    if isinstance(obj, np.generic):
        return obj.item()
    if isinstance(obj, float) and not np.isfinite(obj):
        return {"__float__": repr(obj)}
    return obj


def unpack(obj, arrays: dict):
    if isinstance(obj, dict):
        if "__nd__" in obj:
            return arrays[obj["__nd__"]]
        if "__dict__" in obj:
            return {unpack(k, arrays): unpack(v, arrays) for k, v in obj["__dict__"]}
        if "__list__" in obj:
            v = [unpack(x, arrays) for x in obj["__list__"]]
            return tuple(v) if obj.get("tuple") else v
        if "__df__" in obj:
            import pandas as pd
            return pd.DataFrame(unpack(obj["__df__"], arrays), columns=obj["columns"])
        if "__float__" in obj:
            return float(obj["__float__"])
    return obj


def encode(entry: dict) -> tuple[bytes, bytes]:
    arrays: dict = {}
    meta = json.dumps(pack(entry, arrays)).encode()
    buf = io.BytesIO()
    np.savez(buf, **arrays)
    return meta, buf.getvalue()


def decode(meta: bytes, npz: bytes) -> dict:
    with np.load(io.BytesIO(npz), allow_pickle=False) as z:
        arrays = {k: z[k] for k in z.files}
    return unpack(json.loads(meta), arrays)


class MemoryCache:
    def __init__(self):
        self.store: dict = {}

    def get(self, key):
        v = self.store.get(key)
        return None if v is None else decode(*v)

    def put(self, key, entry):
        self.store[key] = encode(entry)


class DirCache:
    def __init__(self, path=None):
        self.path = Path(path or os.environ.get("HUMANLIKE_CACHE") or Path.home() / ".cache" / "humanlike")
        self.path.mkdir(parents=True, exist_ok=True)

    def _files(self, key):
        d = self.path / key[:2]
        return d / f"{key}.json", d / f"{key}.npz"

    def get(self, key):
        j, z = self._files(key)
        if not (j.exists() and z.exists()):
            return None
        try:
            return decode(j.read_bytes(), z.read_bytes())
        except Exception:                  # a damaged entry is a miss
            return None

    def put(self, key, entry):
        j, z = self._files(key)
        j.parent.mkdir(exist_ok=True)
        meta, npz = encode(entry)
        for f, b in ((z, npz), (j, meta)):                      # json last: it marks the entry complete
            tmp = f.with_suffix(f.suffix + ".tmp")
            tmp.write_bytes(b)
            os.replace(tmp, f)

    def info(self) -> dict:
        files = list(self.path.rglob("*.json"))
        size = sum(f.stat().st_size for f in self.path.rglob("*") if f.is_file())
        return {"path": str(self.path), "entries": len(files), "bytes": size}

    def clear(self) -> int:
        n = 0
        for f in self.path.rglob("*"):
            if f.is_file() and f.suffix in (".json", ".npz", ".tmp"):
                f.unlink(); n += 1
        return n
