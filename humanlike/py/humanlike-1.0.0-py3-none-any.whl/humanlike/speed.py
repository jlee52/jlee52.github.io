"""Speed-matched sensitivity analyses.

Models were rolled out over different speed ranges (e.g. KINESIS 0.5-1.1 m/s, AMP/SMP
1.3-3.7 m/s), so pooled comparisons mix model differences with speed differences. These
helpers restrict comparisons to the speeds every compared dataset actually covers.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .feedforward import js_divergence


def common_range(*speeds) -> tuple[float, float]:
    """Overlap [lo, hi] of the speed ranges; lo > hi means no overlap."""
    s = [np.asarray(v, float)[np.isfinite(v)] for v in speeds]
    return max(v.min() for v in s), min(v.max() for v in s)


def js_common_support(ref: dict, sim: dict, feature: str) -> dict:
    """JS divergence after restricting reference and model samples to their shared speed range."""
    lo, hi = common_range(ref["speeds"], sim["speeds"])
    if lo >= hi:
        return {"lo": lo, "hi": hi, "js_bits": np.nan, "ref_kept": 0.0, "sim_kept": 0.0}
    r = (ref["speeds"] >= lo) & (ref["speeds"] <= hi)
    m = (sim["speeds"] >= lo) & (sim["speeds"] <= hi)
    return {"lo": lo, "hi": hi,
            "js_bits": js_divergence(ref["speeds"][r], ref[feature][r], sim["speeds"][m], sim[feature][m]),
            "ref_kept": float(r.mean()), "sim_kept": float(m.mean())}


def shared_bins(df: pd.DataFrame, models: list[str]) -> list[float]:
    """Speed bins present for every model in `models` (df: long table with model, speed_bin)."""
    sets = [set(df.loc[df.model == m, "speed_bin"]) for m in models]
    return sorted(set.intersection(*sets)) if sets else []
