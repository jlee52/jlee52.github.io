"""Loaders for the final vis_hum data format.

The BFM `tot_results_*.npy` files are 1-2 GB pickled dicts (they carry qpos/qvel/qfrc time
series). Only the small per-trajectory arrays are needed, so they are extracted once into
an .npz cache keyed by the source file's size and mtime.
"""
from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np

GAIT_KEYS = ("speeds", "stride_lengths", "stride_frequencies", "cot", "target_speeds")
CACHE = Path(__file__).resolve().parent.parent / ".cache"


def _load_dict(path: Path) -> dict:
    if path.suffix == ".npz":                       # curated data (no pickle)
        with np.load(path) as z:
            return {k: z[k] for k in z.files}
    obj = np.load(path, allow_pickle=True)          # original vis_hum pickled dicts
    return obj.item() if obj.dtype == object and obj.shape == () else obj


def load_gait(path: Path, min_speed: float | None = None) -> dict[str, np.ndarray]:
    st = path.stat()
    tag = hashlib.sha1(f"{path.resolve()}|{st.st_size}|{st.st_mtime_ns}".encode()).hexdigest()[:12]
    cached = CACHE / f"{path.stem}-{tag}.npz"
    if cached.exists():
        d = dict(np.load(cached))
    else:
        raw = _load_dict(path)
        d = {k: np.asarray(raw[k], float) for k in GAIT_KEYS if k in raw}
        CACHE.mkdir(exist_ok=True)
        np.savez(cached, **d)
    if min_speed is not None:
        keep = d["speeds"] > min_speed
        d = {k: v[keep] if v.shape[:1] == keep.shape else v for k, v in d.items()}
    return d


def load_feedback(path: Path) -> dict[str, np.ndarray]:
    raw = _load_dict(path)
    return {k: np.asarray(raw[k], float) for k in ("gains", "ctl_mag") if k in raw}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()
