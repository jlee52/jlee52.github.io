"""Validation of an HLB data set: errors (cannot be analysed), warnings, and which analyses its data
support, with the reason when one is not available."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .io import Dataset
from .spec import CAPABILITIES, DATASET_META, FIELD, ROLLOUT_META


@dataclass
class Report:
    errors: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    capabilities: dict = field(default_factory=dict)      # name -> (available, reason)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict:
        return {"ok": self.ok, "errors": self.errors, "warnings": self.warnings,
                "capabilities": {k: {"available": a, "reason": r} for k, (a, r) in self.capabilities.items()}}


def _meta_get(meta: dict, dotted: str):
    cur = meta
    for k in dotted.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur


def validate(ds: Dataset) -> Report:
    rep = Report()
    for k, (req, _) in DATASET_META.items():
        if req and not ds.meta.get("dataset", {}).get(k):
            rep.errors.append(f"dataset.{k} is missing")
    up = ds.meta.get("frame", {}).get("up", "z")
    if up not in ("x", "y", "z"):
        rep.errors.append(f"frame.up must be x, y or z (got {up!r})")
    if ds.meta.get("dataset", {}).get("sagittal_side", "left") not in ("left", "right"):
        rep.errors.append("dataset.sagittal_side must be 'left' or 'right'")
    if not ds.rollouts:
        rep.errors.append("no rollouts")
    ids = [r.meta.get("id") for r in ds.rollouts]
    if len(set(ids)) != len(ids):
        rep.errors.append("rollout ids are not unique")
    present = {}
    for r in ds.rollouts:
        for k, (req, _) in ROLLOUT_META.items():
            if req and r.meta.get(k) is None:
                rep.errors.append(f"rollout {r.meta.get('id')}: {k} is missing")
        fs = r.meta.get("fs")
        if fs is not None and not (np.isfinite(fs) and fs > 0):
            rep.errors.append(f"rollout {r.id}: fs must be positive")
        T = None
        for name, arr in r.arrays.items():
            f = FIELD.get(name)
            if f is None:
                rep.warnings.append(f"rollout {r.id}: unknown array {name!r} ignored")
                continue
            a = np.asarray(arr)
            if f.shape.startswith("T"):
                T = a.shape[0] if T is None else T
                if a.shape[0] != T:
                    rep.errors.append(f"rollout {r.id}: {name} has {a.shape[0]} samples, expected {T}")
                if f.shape == "T,3" and (a.ndim != 2 or a.shape[1] != 3):
                    rep.errors.append(f"rollout {r.id}: {name} must have shape [T, 3], got {list(a.shape)}")
                if a.dtype.kind == "f" and not np.isfinite(a).all():
                    rep.warnings.append(f"rollout {r.id}: {name} contains non-finite values")
            present.setdefault(name, 0)
            present[name] += 1
        if T is not None and fs:
            if T / float(fs) < 3:
                rep.warnings.append(f"rollout {r.id}: only {T / float(fs):.1f} s of data; a few strides are needed")
        if "joint_torque" in r.arrays and "joint_vel" in r.arrays and \
                np.shape(r.arrays["joint_torque"]) != np.shape(r.arrays["joint_vel"]):
            rep.errors.append(f"rollout {r.id}: joint_torque and joint_vel shapes differ")
    pos = ds.rollouts[0].arrays.get("pelvis_pos") if ds.rollouts else None
    if pos is not None and len(pos):
        h = float(np.nanmedian(np.asarray(pos)[:, "xyz".index(up) if up in "xyz" else 2]))
        if not 0.3 < abs(h) < 2.0:
            rep.warnings.append(f"median pelvis height {h:.2f} along frame.up={up}: check units (m) and the up axis")
    n = len(ds.rollouts)
    for cap, spec in CAPABILITIES.items():
        missing = [a for a in spec["arrays"] if present.get(a, 0) < n]
        meta_missing = [m for m in spec["meta"] if _meta_get(ds.meta, m) is None]
        if missing or meta_missing:
            why = ", ".join([*(f"array {a}" for a in missing), *(f"metadata {m}" for m in meta_missing)])
            rep.capabilities[cap] = (False, f"needs {why}")
            if cap == "core":
                rep.errors.append(f"required data missing: {why}")
        else:
            rep.capabilities[cap] = (True, "")
    return rep
