"""HLB format v1: the input of the benchmark.

A data set is one model (or one group of human subjects) and holds rollouts (trajectories). Each
rollout belongs to a group, the unit of replication of the feedback signature (one rollout session
of a policy, or one human subject). Positions are in metres in a right-handed world frame with the
vertical axis given by ``frame.up``; the walking direction is found from the data.

Container (``.hlb``): a zip archive with
    hlb.json                               metadata (FORMAT, VERSION, dataset, subject, frame, rollouts)
    rollouts/<rollout id>/<array>.npy      arrays, one file per array

Arrays per rollout (T samples at ``fs`` Hz). The required arrays give the feedforward and feedback
signatures and the phases of the stride; each optional group switches on further analyses.
"""
from __future__ import annotations

from dataclasses import dataclass

FORMAT = "hlb"
VERSION = "1.0"


@dataclass(frozen=True)
class Field:
    name: str
    shape: str           # "T,3", "T,J", "n", ...
    unit: str
    required: bool
    group: str           # capability it belongs to
    doc: str


FIELDS = [
    Field("pelvis_pos", "T,3", "m", True, "core", "pelvis (or root) position, a proxy of the centre of mass"),
    Field("left_foot_pos", "T,3", "m", True, "core", "left foot position (ankle or foot body origin)"),
    Field("right_foot_pos", "T,3", "m", True, "core", "right foot position"),
    Field("pelvis_vel", "T,3", "m/s", False, "core", "pelvis velocity; differentiated from pelvis_pos if absent"),
    Field("left_heel_strikes", "n", "sample", False, "core", "left foot strikes; detected if absent"),
    Field("right_heel_strikes", "n", "sample", False, "core", "right foot strikes; detected if absent"),
    Field("joint_torque", "T,J", "N m", False, "energetics", "actuated joint torques (generalized forces)"),
    Field("joint_vel", "T,J", "rad/s", False, "energetics", "matching joint velocities"),
    Field("sagittal_angles", "T,3", "deg", False, "sagittal",
          "hip, knee, ankle sagittal angles of one leg (dataset.sagittal_side), + = flexion / dorsiflexion"),
    Field("left_grf", "T,3", "N", False, "kinetics", "floor force on the left foot, world frame"),
    Field("right_grf", "T,3", "N", False, "kinetics", "floor force on the right foot, world frame"),
    Field("com_pos", "T,3", "m", False, "kinetics", "whole-body centre of mass; the pelvis is used if absent"),
    Field("com_vel", "T,3", "m/s", False, "kinetics", "centre-of-mass velocity; differentiated from com_pos if absent"),
    Field("sagittal_moments", "T,3", "N m", False, "joint_kinetics",
          "hip, knee, ankle sagittal joint moments of the sagittal_angles leg, + = flexion / dorsiflexion"),
    Field("sagittal_powers", "T,3", "W", False, "joint_kinetics",
          "matching joint powers; moment x angular velocity of sagittal_angles if absent"),
]
FIELD = {f.name: f for f in FIELDS}

# capabilities: which analyses a data set supports, and what each needs beyond the core arrays
CAPABILITIES = {
    "core": {"arrays": ["pelvis_pos", "left_foot_pos", "right_foot_pos"], "meta": [],
             "enables": ["events", "gait_summary", "gait_scaling", "foot_placement", "feedback"]},
    "energetics": {"arrays": ["joint_torque", "joint_vel"], "meta": ["subject.mass_kg"],
                   "enables": ["energetics"]},
    "sagittal": {"arrays": ["sagittal_angles"], "meta": [], "enables": ["sagittal"]},
    "kinetics": {"arrays": ["left_grf", "right_grf"], "meta": ["subject.mass_kg"],
                 "enables": ["gait_phases", "kinetic_principles"]},
    "joint_kinetics": {"arrays": ["sagittal_angles", "sagittal_moments"], "meta": ["subject.mass_kg"],
                       "enables": ["kinetic_principles (joint-work predictions)"]},
}

ROLLOUT_META = {   # key: (required, doc)
    "id": (True, "unique rollout identifier"),
    "group": (True, "unit of replication (session or subject)"),
    "fs": (True, "sampling rate of the arrays (Hz)"),
    "commanded_speed": (False, "commanded or target speed (m/s), if any"),
    "fell": (False, "True if the agent fell; such rollouts are excluded"),
    "skip_s": (False, "initial seconds to discard (start-up transient)"),
}
DATASET_META = {
    "name": (True, "model or data set name"),
    "kind": (False, "'simulation' or 'human'"),
    "simulator": (False, "physics engine, e.g. MuJoCo, Isaac Gym"),
    "skeleton": (False, "body model, e.g. SMPL humanoid, MyoLeg"),
    "description": (False, "free text"),
    "sagittal_side": (False, "'left' (default) or 'right': the leg of sagittal_angles and sagittal_moments, "
                             "and the reference foot of the sagittal and kinetic analyses"),
}
