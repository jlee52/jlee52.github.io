"""Energetic signature: bimodal speed-COT structure.

Manuscript: z-scored COT vs speed is fit with
    y(x) = c + a1 exp(-(x-mu1)^2 / 2 sig1^2) + a2 exp(-(x-mu2)^2 / 2 sig2^2)
by bounded soft-L1 least squares (walking optimum mu1 in [0.5, 2.0], running optimum
mu2 in [2.2, 4.0] m/s). A model is human-like (PASS) only if the residuals are random
(Durbin-Watson in [1.5, 2.5], Wald-Wolfowitz runs p >= 0.05) and the geometry is valid.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import curve_fit
from statsmodels.sandbox.stats.runs import runstest_1samp
from statsmodels.stats.stattools import durbin_watson


@dataclass(frozen=True)
class COTCriteria:
    # optimiser bounds
    mu1_bounds: tuple = (0.5, 2.0)
    mu2_bounds: tuple = (2.2, 4.0)
    sigma_bounds: tuple = (0.05, 0.6)
    # residual randomness
    dw_range: tuple = (1.5, 2.5)
    runs_alpha: float = 0.05
    # fit quality
    r2_threshold: float = 0.60
    rmse_threshold: float = 0.80
    # geometry
    min_depth: float = 0.5
    min_separation: float = 1.2
    blend_multiplier: float = 1.0
    max_abs_amplitude: float = 10.0


PARAMS = ("c", "a1", "mu1", "sig1", "a2", "mu2", "sig2")


def mechanical_cot(abs_power, dt, path, mass, g=9.80665):
    """Mechanical cost of transport, the same definition for every model: the summed absolute joint
    power sum_t sum_j |tau_j qdot_j| at every physics step (abs_power [T], W) times the physics time
    step, over m g d, with d the path length of `path` [N, 3] (the rollout's reference trajectory)."""
    d = np.linalg.norm(np.diff(np.asarray(path, float), axis=0), axis=1).sum()
    return float(np.sum(abs_power) * dt / (g * d * mass)) if d > 0 else 0.0


def two_gaussian(x, c, a1, mu1, sig1, a2, mu2, sig2):
    return (c + a1 * np.exp(-((x - mu1) ** 2) / (2 * sig1 ** 2))
              + a2 * np.exp(-((x - mu2) ** 2) / (2 * sig2 ** 2)))


def zscore(v):
    v = np.asarray(v, float)
    return (v - np.nanmean(v)) / np.nanstd(v)


def fit_cot(speeds, cot, cfg: COTCriteria = COTCriteria()) -> dict:
    """Fit the two-Gaussian model to z-scored COT. Returns parameters and diagnostics."""
    x, y = np.asarray(speeds, float), zscore(cot)
    m = np.isfinite(x) & np.isfinite(y)
    x, y = x[m], y[m]
    if x.size < 10:
        raise ValueError("need >= 10 finite points for the two-Gaussian fit")

    p10, p85 = np.percentile(y, [10, 85])
    s0 = np.mean(cfg.sigma_bounds)
    p0 = [p85, p10 - p85, np.mean(cfg.mu1_bounds), s0, p10 - p85, np.mean(cfg.mu2_bounds), s0]
    lo = [-5, -10, cfg.mu1_bounds[0], cfg.sigma_bounds[0], -10, cfg.mu2_bounds[0], cfg.sigma_bounds[0]]
    hi = [5, 10, cfg.mu1_bounds[1], cfg.sigma_bounds[1], 10, cfg.mu2_bounds[1], cfg.sigma_bounds[1]]
    popt, _ = curve_fit(two_gaussian, x, y, p0=p0, bounds=(lo, hi), maxfev=10000, loss="soft_l1")

    resid = y - two_gaussian(x, *popt)
    ss_tot = np.sum((y - y.mean()) ** 2)
    r_sorted = resid[np.argsort(x)]          # serial tests are along the speed axis
    return {
        **dict(zip(PARAMS, map(float, popt))),
        "n": int(x.size),
        "r2": float(1 - np.sum(resid ** 2) / ss_tot) if ss_tot > 0 else np.nan,
        "rmse": float(np.sqrt(np.mean(resid ** 2))),
        "mae": float(np.mean(np.abs(resid))),
        "dw": float(durbin_watson(r_sorted)),
        "runs_p": float(runstest_1samp(r_sorted, cutoff=0)[1]),
    }


def classify_cot(fit: dict | None, cfg: COTCriteria = COTCriteria()) -> tuple[str, str]:
    """Return ("PASS" | "FAIL", reason). Checks are applied in the order reported in the paper."""
    if fit is None:
        return "FAIL", "fit failed"
    if not (np.isfinite(fit["r2"]) and np.isfinite(fit["rmse"])):
        return "FAIL", "invalid fit metric"
    if fit["dw"] < cfg.dw_range[0]:
        return "FAIL", f"positive autocorrelation (DW={fit['dw']:.2f})"
    if fit["dw"] > cfg.dw_range[1]:
        return "FAIL", f"negative autocorrelation (DW={fit['dw']:.2f})"
    if fit["runs_p"] < cfg.runs_alpha:
        return "FAIL", f"non-random residuals (runs p={fit['runs_p']:.3f})"
    # Gaussian components are order-invariant; label the slower one as walking.
    (a1, mu1, s1), (a2, mu2, s2) = sorted(
        [(fit["a1"], fit["mu1"], fit["sig1"]), (fit["a2"], fit["mu2"], fit["sig2"])],
        key=lambda t: t[1])
    if fit["r2"] < cfg.r2_threshold:
        return "FAIL", f"low R2 ({fit['r2']:.2f})"
    if fit["rmse"] > cfg.rmse_threshold:
        return "FAIL", f"high RMSE ({fit['rmse']:.2f})"
    if max(abs(a1), abs(a2)) > cfg.max_abs_amplitude:
        return "FAIL", "unstable amplitude"
    if s1 + s2 > (mu2 - mu1) * cfg.blend_multiplier:
        return "FAIL", "valleys blend together"
    if a1 > -cfg.min_depth or a2 > -cfg.min_depth:
        return "FAIL", "valleys not deep enough"
    if mu2 - mu1 < cfg.min_separation:
        return "FAIL", f"optima too close (dmu={mu2 - mu1:.2f})"
    return "PASS", f"R2={fit['r2']:.2f}, mu1={mu1:.2f}, mu2={mu2:.2f}"
