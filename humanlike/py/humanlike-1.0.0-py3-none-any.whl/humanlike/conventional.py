"""Conventional kinematic metric: MPJAE between speed-matched gait cycles.

A joint is a chain of hinge DoFs in one body (e.g. SMPL ``L_Elbow_x/y/z``, AMP ``right_knee``,
MyoLeg ``hip_flexion_r/hip_adduction_r/hip_rotation_r``). Its rotation is the product of the
hinge rotations in chain order, R = exp(q1 a1) exp(q2 a2) ..., and the per-joint error is the
geodesic angle between the simulated and reference rotations, computed from unit quaternions:

    theta_j(t) = 2 arccos |<q_s, q_r>|                    (= |q_s - q_r| for a single hinge)
    MPJAE      = mean over joints j and time t of theta_j(t)

This is the SO(3) geodesic distance used for joint-angle errors of SMPL-based models (e.g. 3DPW,
von Marcard et al. 2018). Unlike a norm of Euler-angle differences it does not depend on how a
rotation is split across the hinges: near gimbal lock (middle hinge at +-90 deg, e.g. a flexed
SMPL elbow) different hinge values describe nearly the same rotation.

Matching: each simulated trajectory is paired with the reference trajectory in the same speed
bin that minimises the metric (top-1), as in the manuscript.
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial.transform import Rotation


def load_angles(path: Path) -> dict:
    with np.load(path) as z:
        return {k: z[k] for k in z.files}


def speed_bin(speed, centers) -> np.ndarray:
    """Centre of the nearest speed bin (edges halfway between centres), rounded to 0.1 m/s."""
    centers = np.asarray(centers, float)
    edges = np.r_[-np.inf, (centers[:-1] + centers[1:]) / 2, np.inf]
    return np.round(centers[np.digitize(np.asarray(speed, float), edges) - 1], 1)


def group_joints(dof, explicit: dict | None = None) -> dict[str, list[int]]:
    """Joints as lists of DoF indices in chain order. Without `explicit`, DoFs named
    ``<joint>_x/_y/_z`` form one joint and any other DoF is a joint of its own."""
    dof = [str(d) for d in dof]
    if explicit:
        return {j: [dof.index(d) for d in ds] for j, ds in explicit.items()}
    joints: dict[str, list[int]] = {}
    for i, d in enumerate(dof):
        joints.setdefault(re.sub(r"_[xyz]$", "", d), []).append(i)
    return joints


def joint_quaternions(angles: np.ndarray, axes: np.ndarray) -> np.ndarray:
    """[..., k] hinge angles about `axes` [k, 3] (chain order) -> unit quaternions [..., 4]."""
    shape = angles.shape[:-1]
    a = angles.reshape(-1, angles.shape[-1]).astype(float)
    rot = Rotation.from_rotvec(a[:, :1] * axes[0])
    for i in range(1, a.shape[1]):
        rot = rot * Rotation.from_rotvec(a[:, i:i + 1] * axes[i])
    return rot.as_quat().reshape(*shape, 4)


def joint_angle_error(sim: np.ndarray, ref: np.ndarray, axes: np.ndarray) -> np.ndarray:
    """Geodesic angle (rad) between two joint rotations, element-wise over leading dims."""
    if axes.shape[0] == 1:
        return np.abs(sim[..., 0].astype(float) - ref[..., 0])
    dot = np.abs(np.sum(joint_quaternions(sim, axes) * joint_quaternions(ref, axes), axis=-1))
    return 2 * np.arccos(np.clip(dot, 0.0, 1.0))


def mpjae(sim: np.ndarray, ref: np.ndarray, joints: dict[str, list[int]], axes: np.ndarray) -> float:
    """MPJAE (rad) between two gait cycles [T, D]: mean over the given joints and over time."""
    return float(np.mean([joint_angle_error(sim[:, idx], ref[:, idx], axes[idx]).mean()
                          for idx in joints.values()]))


def match_top1(sim: dict, ref: dict, joints: dict[str, list[int]], centers) -> pd.DataFrame:
    """Pair every simulated cycle with the minimising reference cycle in its speed bin.

    sim/ref: curated joint-angle dicts (angles [n, T, D], axes, speed, traj).
    Returns one row per matched simulated trajectory (unmatched bins are dropped).
    """
    axes = sim["axes"]
    sb, rb = speed_bin(sim["speed"], centers), speed_bin(ref["speed"], centers)
    # per-joint rotations once per trajectory: [n, T, J, 4] (single hinges kept as angles)
    def prep(a):
        return [(a[..., idx].astype(float) if len(idx) == 1 else joint_quaternions(a[..., idx], axes[idx]))
                for idx in joints.values()]
    ps, pr = prep(sim["angles"]), prep(ref["angles"])
    rows = []
    for b in np.unique(sb):
        cand = np.flatnonzero(rb == b)
        if cand.size == 0:
            continue
        for i in np.flatnonzero(sb == b):
            err = np.zeros(cand.size)
            for s, r in zip(ps, pr):
                if s.shape[-1] == 1:
                    e = np.abs(s[i][None, :, 0] - r[cand][..., 0])
                else:
                    e = 2 * np.arccos(np.clip(np.abs(np.sum(s[i][None] * r[cand], axis=-1)), 0.0, 1.0))
                err += e.mean(axis=1)
            err /= len(ps)
            k = int(np.argmin(err))
            rows.append({"speed_bin": float(b), "sim_traj": str(sim["traj"][i]), "ref_traj": str(ref["traj"][cand[k]]),
                         "n_candidates": int(cand.size), "mpjae_rad": float(err[k])})
    return pd.DataFrame(rows)


def sagittal_angle(d: dict, dof: str, sign: int) -> np.ndarray:
    """Sagittal joint angle [n, T] in degrees from a curated dict, + = flexion / dorsiflexion."""
    i = [str(x) for x in d["dof"]].index(dof)
    return sign * np.degrees(d["angles"][..., i].astype(float))
