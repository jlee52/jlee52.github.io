"""`humanlike serve`: the web app with a local Python back end (native speed, large data sets, every
reference in the local bundle). Listens on 127.0.0.1 by default, so the data never leave the computer.

    GET  /                       the web app (humanlike/web)
    GET  /references/<file>      the reference bundle (humanlike.references)
    GET  /api/ping
    POST /api/session            -> {"session": id}; a temporary directory for the upload
    POST /api/upload?session&path   the request body is written to <session>/<path>
    GET  /api/inspect?session    humanlike.webapi.inspect of the upload
    POST /api/run?session        body: mapping options (JSON); response: NDJSON lines
                                 {"type": "progress", ...} ... {"type": "result", "result": ...}
"""
from __future__ import annotations

import json
import mimetypes
import shutil
import tempfile
import threading
import traceback
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qs, unquote, urlparse

WEB = Path(__file__).resolve().parent / "web"


class Handler(BaseHTTPRequestHandler):
    root: Path = None            # session directories
    cache = None
    refs: Path = None

    def log_message(self, fmt, *args):     # quiet
        pass

    # -- helpers -------------------------------------------------------------------------------
    def _send(self, code, body: bytes, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, default=str).encode())

    def _session(self, q) -> Path:
        sid = q.get("session", [""])[0]
        if not sid or not all(c in "0123456789abcdef" for c in sid):
            raise ValueError("bad session")
        d = self.root / sid
        if not d.is_dir():
            raise ValueError("unknown session")
        return d

    @staticmethod
    def _target(d: Path) -> Path:
        entries = sorted(d.iterdir())
        if not entries:
            raise ValueError("nothing uploaded")
        return entries[0]

    # -- routes --------------------------------------------------------------------------------
    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        try:
            if u.path == "/api/ping":
                return self._json({"ok": True})
            if u.path == "/api/inspect":
                from .webapi import inspect
                return self._json(inspect(self._target(self._session(q))))
            if u.path.startswith("/references/") and self.refs is not None:
                f = (self.refs / PurePosixPath(unquote(u.path[len("/references/"):])).name)
                return self._file(f)
            rel = unquote(u.path).lstrip("/") or "index.html"
            f = (WEB / rel).resolve()
            if WEB.resolve() not in f.parents and f != WEB.resolve():
                return self._send(404, b"not found", "text/plain")
            return self._file(f)
        except Exception as e:
            return self._send(400, str(e).encode(), "text/plain")

    def _file(self, f: Path):
        if not f.is_file():
            return self._send(404, b"not found", "text/plain")
        ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
        if f.suffix == ".js":
            ctype = "text/javascript"
        self._send(200, f.read_bytes(), ctype)

    def do_POST(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        try:
            n = int(self.headers.get("Content-Length", 0) or 0)
            if u.path == "/api/session":
                sid = uuid.uuid4().hex
                (self.root / sid).mkdir()
                return self._json({"session": sid})
            if u.path == "/api/upload":
                d = self._session(q)
                rel = PurePosixPath(q.get("path", [""])[0])
                if rel.is_absolute() or ".." in rel.parts or not rel.parts:
                    raise ValueError("bad path")
                dst = d.joinpath(*rel.parts)
                dst.parent.mkdir(parents=True, exist_ok=True)
                with open(dst, "wb") as fh:
                    left = n
                    while left > 0:
                        chunk = self.rfile.read(min(left, 1 << 20))
                        if not chunk:
                            break
                        fh.write(chunk); left -= len(chunk)
                return self._json({"ok": True})
            if u.path == "/api/run":
                options = json.loads(self.rfile.read(n) or b"{}")
                return self._run(self._session(q), options)
            return self._send(404, b"not found", "text/plain")
        except Exception as e:
            return self._send(400, str(e).encode(), "text/plain")

    def _run(self, d: Path, options: dict):
        from .webapi import kind_of, run
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson")
        self.end_headers()

        def line(obj):
            self.wfile.write((json.dumps(obj, default=str) + "\n").encode())
            self.wfile.flush()
        try:
            target = self._target(d)
            out = run(target, kind_of(target), options, cache=self.cache,
                      progress=lambda i, n, stage, status: line({"type": "progress", "i": i, "n": n, "stage": stage,
                                                                  "status": status}))
            from .engine import to_jsonable
            line({"type": "result", "result": to_jsonable(out)})
        except Exception as e:
            line({"type": "error", "message": f"{type(e).__name__}: {e}", "trace": traceback.format_exc(limit=3)})


def serve(host="127.0.0.1", port=8765, cache=True, open_browser=False, ready: threading.Event | None = None):
    from .cache import DirCache
    from .references import Bundle
    root = Path(tempfile.mkdtemp(prefix="humanlike-serve-"))
    try:
        refs = Bundle().path
    except FileNotFoundError:
        refs = None
    handler = type("H", (Handler,), {"root": root, "cache": DirCache() if cache else None, "refs": refs})
    httpd = ThreadingHTTPServer((host, port), handler)
    url = f"http://{host}:{httpd.server_address[1]}/"
    print(f"humanlike: {url}  (data stay on this computer; Ctrl-C to stop)")
    if open_browser:
        import webbrowser
        webbrowser.open(url)
    if ready is not None:
        ready.port = httpd.server_address[1]
        ready.set()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
        shutil.rmtree(root, ignore_errors=True)
