"""C3D motion capture (markers, and force plates for an instrumented treadmill) as an HLB data set.

Each C3D file is one rollout; its group is the subject name stored in the file (SUBJECTS:NAMES) or
the file name. The pelvis is the mean of the pelvis markers present (default Plug-in Gait: LASI, RASI,
LPSI, RPSI, or SACR in place of the posterior markers) and each foot is its heel marker (LHEE, RHEE),
as used for kinematic foot-strike detection (Zeni et al. 2008). Gaps up to `max_gap_s` are filled
linearly; the longest stretch where all of these markers are present is kept.

Treadmill trials (`treadmill_speed`, in m/s or "auto" to estimate it from the feet in stance) are
converted to over-ground coordinates by moving every position forward by the belt travel, so that
speed and stride length follow the same definition as for over-ground walking. Force plates are
included for treadmill trials (each sample of each loaded plate given to the foot nearest to its
centre of pressure, at the marker rate); over-ground plates, which a subject crosses with a few
steps only, are left out unless `forces=True`.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from .c3d_reader import force_platforms, read_c3d
from .core import from_arrays
from .mocap import UNITS, belt_motion, fill_gaps, longest_valid, plates_to_feet, to_rate, treadmill_to_ground

PELVIS = (("LASI", "RASI", "LPSI", "RPSI"), ("LASI", "RASI", "SACR"))
FEET = {"left": "LHEE", "right": "RHEE"}
TOES = {"left": "LTOE", "right": "RTOE"}


def _files(inputs):
    if isinstance(inputs, (str, Path)):
        p = Path(inputs)
        return sorted(p.glob("*.c3d")) if p.is_dir() else [p]
    return [Path(x) for x in inputs]


def _pelvis(c, markers):
    sets = [markers] if markers else PELVIS
    for s in sets:
        if all(m in c.labels for m in s):
            return np.mean(np.stack([c.marker(m) for m in s]), 0), s
    raise KeyError(f"no pelvis markers {sets} in {c.labels[:30]}...")


def _events(c, side: str):
    E = c.parameters.get("EVENT", {})
    ctx, lab, times = [], [], []
    for k in ("", "2", "3", "4"):
        if f"CONTEXTS{k}" not in E:
            break
        ctx += list(E[f"CONTEXTS{k}"]); lab += list(E[f"LABELS{k}"])
        times += list(np.asarray(E[f"TIMES{k}"], float).reshape(-1, 2) @ [60.0, 1.0])
    t = np.array([tt for cc, ll, tt in zip(ctx, lab, times) if cc.lower() == side and ll.lower() == "foot strike"])
    return np.unique(np.round(t * c.rate).astype(int) - (c.first_frame - 1))


def convert(inputs, name: str, *, pelvis=None, feet=None, up="z", treadmill_speed=None, forces="auto",
            events="detect", max_gap_s: float = 0.1, mass_kg=None, leg_length_m=None, **meta):
    """inputs: a .c3d file, a directory of them, or a list. pelvis: marker names averaged for the pelvis;
    feet: {"left": marker, "right": marker}. treadmill_speed: None (over ground), a speed in m/s or
    "auto". forces: "auto" (treadmill trials only), True or False. events: "detect" (foot strikes from
    the markers, as for simulations) or "c3d" (the file's Foot Strike events)."""
    feet = {**FEET, **(feet or {})}
    upi = "xyz".index(up)
    rollouts = []
    for f in _files(inputs):
        c = read_c3d(f)
        s = UNITS.get(c.point_units.strip().lower(), 1e-3)
        gap = int(round(max_gap_s * c.rate))
        P, used = _pelvis(c, pelvis)
        arrays = {"pelvis_pos": fill_gaps(P * s, gap),
                  **{f"{k}_foot_pos": fill_gaps(c.marker(m) * s, gap) for k, m in feet.items()}}
        use_forces = forces is True or (forces == "auto" and treadmill_speed is not None)
        grf = None
        if use_forces:
            plates = [p for p in force_platforms(c) if p is not None]
            if plates and c.analog_rate:
                per = int(round(c.analog_rate / c.rate))
                n = len(P)
                plates = [{"force": to_rate(p["force"], per)[:n], "cop": to_rate(p["cop"], per)[:n]} for p in plates]
                mid = {}
                for k in feet:                                       # foot centre for the plate assignment
                    toe = TOES[k] if TOES[k] in c.labels else None
                    hee = arrays[f"{k}_foot_pos"]
                    mid[k] = (hee + fill_gaps(c.marker(toe) * s, gap)) / 2 if toe else hee
                mid = {k: v[:len(plates[0]["force"])] for k, v in mid.items()}
                grf = plates_to_feet(plates, mid, upi)
        seg = longest_valid(*arrays.values())
        if grf is not None:
            seg = slice(seg.start, min(seg.stop, len(grf["left"])))
            arrays.update({f"{k}_grf": grf[k] for k in grf})
        arrays = {k: v[seg] for k, v in arrays.items()}
        if seg.stop - seg.start < 3 * c.rate:
            continue
        info = {}
        if treadmill_speed is not None:
            fv = [arrays["left_grf"][:, upi], arrays["right_grf"][:, upi]] if "left_grf" in arrays else None
            v_est, u = belt_motion([arrays["left_foot_pos"], arrays["right_foot_pos"]], c.rate, upi, fv)
            v = v_est if treadmill_speed == "auto" else float(treadmill_speed)
            arrays = treadmill_to_ground(arrays, c.rate, v, u, ("pelvis_pos", "left_foot_pos", "right_foot_pos"))
            info = {"treadmill_speed": v, "belt_speed_estimate": v_est}
        if events == "c3d":
            for k in ("left", "right"):
                hs = _events(c, k) - seg.start
                arrays[f"{k}_heel_strikes"] = hs[(hs >= 0) & (hs < seg.stop - seg.start)]
        group = (c.parameters.get("SUBJECTS", {}).get("NAMES") or [f.stem])
        group = group[0] if isinstance(group, list) else str(group)
        rollouts.append({"id": f.stem, "group": group, "fs": float(c.rate), "source": f.name,
                         "pelvis_markers": list(used), **info, "arrays": arrays})
    if not rollouts:
        raise ValueError("no usable trial (each needs 3 s with the pelvis and heel markers)")
    meta.setdefault("kind", "human")
    meta.setdefault("skeleton", "markers")
    return from_arrays(name, rollouts, mass_kg=mass_kg, leg_length_m=leg_length_m, up=up, **meta)
