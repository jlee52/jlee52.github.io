"""Converters from simulator logs and curated data to the HLB format.

    curated   data/curated/<model>/rollouts.npz of the manuscript (pelvis and feet, 30 Hz, foot strikes)
    mimickit  MimicKit / Isaac Gym steering rollouts with physics-rate states, torques and GRF
              (scripts/external/mimickit_run_steering_experiments_grf.py)
    c3d       C3D motion capture: pelvis and heel markers, force plates of instrumented treadmills
    bvh       BVH animation / motion-capture files: pelvis and feet by forward kinematics
    csv       CSV tables with columns named after the HLB arrays
    arrays    generic: build a data set from in-memory arrays (any simulator or motion capture)
"""
from .core import from_arrays

ADAPTERS = {"curated": "humanlike.adapters.curated:convert", "mimickit": "humanlike.adapters.mimickit:convert",
            "c3d": "humanlike.adapters.c3d:convert", "bvh": "humanlike.adapters.bvh:convert",
            "csv": "humanlike.adapters.csv:convert"}

__all__ = ["from_arrays", "ADAPTERS"]
