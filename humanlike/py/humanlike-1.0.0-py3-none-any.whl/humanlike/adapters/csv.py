"""CSV tables (one file per rollout, or one file with a rollout column) as an HLB data set.

Columns are named after the HLB arrays (humanlike.format.spec.FIELDS) with an axis or index suffix:
    pelvis_pos_x, pelvis_pos_y, pelvis_pos_z, left_foot_pos_x, ..., left_grf_z,
    sagittal_angles_hip, sagittal_angles_knee, sagittal_angles_ankle (or _0, _1, _2),
    joint_torque_0 ... joint_torque_J-1, left_heel_strikes (0/1 marks at the strike samples)
Shorter names are accepted for the core arrays (pelvis_x, lfoot_x, left_foot_x, rfoot_x, ...). Any
other naming can be mapped with `columns` ({"pelvis_pos": ["PX", "PY", "PZ"], ...}). The sampling rate
comes from a `time` column (s) or `fs`; lengths are converted from `units`. Rollout and group come
from `rollout` / `group` columns if present, otherwise from the file name.
"""
from __future__ import annotations

import csv as _csv
from pathlib import Path

import numpy as np

from ..format.spec import FIELD, FIELDS
from .core import from_arrays
from .mocap import UNITS

ALIASES = {"pelvis_pos": ("pelvis", "root", "com"), "left_foot_pos": ("left_foot", "lfoot", "l_foot"),
           "right_foot_pos": ("right_foot", "rfoot", "r_foot")}
AXES = ("x", "y", "z")
SAGITTAL = ("hip", "knee", "ankle")
LENGTH = {f.name for f in FIELDS if f.unit in ("m", "m/s")}


def _read(path: Path):
    with open(path, newline="") as fh:
        rows = list(_csv.reader(fh))
    head = [h.strip() for h in rows[0]]
    body = [r for r in rows[1:] if r and any(x.strip() for x in r)]
    cols = {h: [r[k] if k < len(r) else "" for r in body] for k, h in enumerate(head)}
    return cols


def _num(v):
    return np.array([float(x) if x.strip() not in ("", "nan", "NaN") else np.nan for x in v])


def _columns_for(field: str, header: list, mapping: dict):
    if field in mapping:
        return mapping[field]
    low = {h.lower(): h for h in header}
    f = FIELD[field]
    if f.shape == "n":
        return [low[field]] if field in low else None
    for base in (field, *ALIASES.get(field, ())):
        for suff in (AXES, SAGITTAL if field.startswith("sagittal") else (), ("0", "1", "2")):
            if suff and all(f"{base}_{a}" in low for a in suff):
                return [low[f"{base}_{a}"] for a in suff]
    if f.shape == "T,J":
        idx = sorted((int(h.rsplit("_", 1)[1]), h) for h in header
                     if h.lower().startswith(field + "_") and h.rsplit("_", 1)[1].isdigit())
        return [h for _, h in idx] or None
    return None


def convert(inputs, name: str, *, fs=None, units="m", columns=None, up="z", mass_kg=None, leg_length_m=None, **meta):
    """inputs: a .csv file, a directory of them, or a list."""
    paths = sorted(Path(inputs).glob("*.csv")) if isinstance(inputs, (str, Path)) and Path(inputs).is_dir() else \
        [Path(inputs)] if isinstance(inputs, (str, Path)) else [Path(p) for p in inputs]
    s = UNITS[units]
    mapping = columns or {}
    rollouts = []
    for p in paths:
        cols = _read(p)
        header = list(cols)
        ids = cols.get("rollout") or [p.stem] * len(next(iter(cols.values())))
        groups = cols.get("group") or [p.stem] * len(ids)
        for rid in dict.fromkeys(ids):
            m = np.array([x == rid for x in ids])
            sub = {h: [v for v, k in zip(vals, m) if k] for h, vals in cols.items()}
            if "time" in sub:
                t = _num(sub["time"])
                rate = 1 / float(np.median(np.diff(t)))
            elif fs:
                rate = float(fs)
            else:
                raise ValueError(f"{p.name}: no time column; give fs")
            arrays = {}
            for f in FIELDS:
                c = _columns_for(f.name, header, mapping)
                if not c:
                    continue
                if f.shape == "n":
                    marks = _num(sub[c[0]])
                    arrays[f.name] = np.flatnonzero(marks > 0.5)
                    continue
                a = np.stack([_num(sub[h]) for h in c], 1)
                arrays[f.name] = a * s if f.name in LENGTH else a
            missing = [k for k in ("pelvis_pos", "left_foot_pos", "right_foot_pos") if k not in arrays]
            if missing:
                raise ValueError(f"{p.name}: no columns for {', '.join(missing)} (see humanlike.adapters.csv)")
            g = groups[int(np.flatnonzero(m)[0])]
            rollouts.append({"id": str(rid), "group": str(g), "fs": rate, "source": p.name, "arrays": arrays})
    meta.setdefault("kind", "simulation")
    return from_arrays(name, rollouts, mass_kg=mass_kg, leg_length_m=leg_length_m, up=up, **meta)
