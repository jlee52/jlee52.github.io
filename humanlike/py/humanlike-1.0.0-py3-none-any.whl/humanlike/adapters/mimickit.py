"""MimicKit / Isaac Gym steering rollouts as an HLB data set.

Input: a directory of steering_speed_<v>_mps.npz files written by
scripts/external/mimickit_run_steering_experiments_grf.py (one file per commanded speed, one column
per environment), with physics-rate body states (phys_body_pos), joint torques (torque, from inverse
dynamics), DOF velocities (phys_dof_vel) and foot GRFs (grf: left, right). The physics-rate arrays are
used, so the HLB rollouts are at the physics rate (120 Hz). Each commanded speed is a group; the first
`skip_s` seconds (10 s, as in the manuscript) are discarded. The sagittal angles, moments and powers are
those of one leg (`side`, right by default as in the manuscript's joint-level analyses); the centre of
mass is the mass-weighted mean of the body centres of mass.
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np

from .core import from_arrays

FALL_HEIGHT = 0.5
LEG_LENGTH_M = 0.8814   # hip joint centre to sole, neutral pose (scripts/curate_leg_length.py)
BODY_COM = {   # centre of mass of each body in its frame (MimicKit humanoid.xml, inertial pos)
    "pelvis": (0.0, 0.0, 0.11319496268656717),
    "torso": (-0.0028192824469260797, 0.0, 0.14793846898582283),
    "head": (0.0, 0.0, 0.175),
    "right_upper_arm": (0.0, -0.13, 0.0),
    "right_lower_arm": (0.0, -0.11125, 0.0),
    "right_hand": (0.0, 0.0, 0.0),
    "left_upper_arm": (0.0, 0.13, 0.0),
    "left_lower_arm": (0.0, 0.11125, 0.0),
    "left_hand": (0.0, 0.0, 0.0),
    "right_thigh": (0.0, 0.0, -0.19999999999999998),
    "right_shin": (0.0, 0.0, -0.1925),
    "right_foot": (0.045, 0.0, -0.0225),
    "left_thigh": (0.0, 0.0, -0.19999999999999998),
    "left_shin": (0.0, 0.0, -0.1925),
    "left_foot": (0.045, 0.0, -0.0225),
}
# sagittal DOFs of each leg (sign: + = flexion / dorsiflexion), as the manuscript
# (pipeline.yaml conventional.sagittal.joints.amp_humanoid)
SAGITTAL = {side: ((f"{side}_hip_y", -1), (f"{side}_knee", 1), (f"{side}_ankle_y", -1)) for side in ("left", "right")}


def convert(directory, name: str, speeds=None, skip_s: float = 10.0, rate: str = "physics", side: str = "right", **meta):
    """rate "physics" (default): physics-rate arrays with torques, GRFs, sagittal moments and the centre
    of mass. rate "control": the control-rate (30 Hz) body positions and root velocity only, as the
    manuscript's gait summaries."""
    from scipy.spatial.transform import Rotation
    files = sorted(Path(directory).glob("steering_speed_*_mps.npz"), key=lambda p: float(re.search(r"([\d.]+)_mps", p.name).group(1)))
    rollouts, mass = [], None
    for f in files:
        v = float(re.search(r"([\d.]+)_mps", f.name).group(1))
        if speeds is not None and not any(abs(v - s) < 1e-6 for s in speeds):
            continue
        d = np.load(f, allow_pickle=True)
        names = [str(b) for b in d["body_names"]]
        ip, il, ir = names.index("pelvis"), names.index("left_foot"), names.index("right_foot")
        mass = float(d["body_mass"].sum())
        dofs = [str(n) for n in d["dof_names"]]
        sag_idx = [dofs.index(n) for n, _ in SAGITTAL[side]]
        sag_sign = np.array([sg for _, sg in SAGITTAL[side]], float)
        bm = d["body_mass"].astype(float)
        ipos = np.array([BODY_COM[n] for n in names])
        control = rate == "control"
        fs = 1 / float(d["dt"] if control else d["phys_dt"])
        E = d["phys_body_pos"].shape[1]
        for e in range(E):
            fell = bool(d["root_pos"][:, e, 2].min() < FALL_HEIGHT)
            base = {"id": f"v{v:.2f}_e{e:02d}", "group": f"{v:.2f}", "fs": fs, "commanded_speed": v, "fell": fell, "skip_s": skip_s}
            if control:
                X = d["xpos"][:, e].astype(float)
                rollouts.append({**base, "arrays": {"pelvis_pos": X[:, ip], "left_foot_pos": X[:, il], "right_foot_pos": X[:, ir],
                                                    "pelvis_vel": d["root_vel"][:, e].astype(float),
                                                    "sagittal_angles": np.degrees(d["dof_pos"][:, e][:, sag_idx].astype(float)) * sag_sign}})
                continue
            P = d["phys_body_pos"][:, e].astype(float)
            rot = Rotation.from_quat(d["phys_body_rot"][:, e].reshape(-1, 4).astype(float)).as_matrix().reshape(len(P), -1, 3, 3)
            com = ((P + np.einsum("tbij,bj->tbi", rot, ipos)) * bm[None, :, None]).sum(1) / mass
            comv = (d["phys_body_vel"][:, e].astype(float) * bm[None, :, None]).sum(1) / mass
            tq = d["torque"][:, e][:, sag_idx].astype(float)
            rollouts.append({**base,
                             "arrays": {"pelvis_pos": P[:, ip], "left_foot_pos": P[:, il], "right_foot_pos": P[:, ir],
                                        "pelvis_vel": d["phys_body_vel"][:, e, ip].astype(float),
                                        "joint_torque": d["torque"][:, e].astype(float),
                                        "joint_vel": d["phys_dof_vel"][:, e].astype(float),
                                        "left_grf": d["grf"][:, e, 0].astype(float), "right_grf": d["grf"][:, e, 1].astype(float),
                                        "sagittal_angles": np.degrees(d["phys_dof_pos"][:, e][:, sag_idx].astype(float)) * sag_sign,
                                        "sagittal_moments": tq * sag_sign,
                                        "sagittal_powers": tq * d["phys_dof_vel"][:, e][:, sag_idx].astype(float),
                                        "com_pos": com, "com_vel": comv}})
    meta.setdefault("simulator", "Isaac Gym")
    meta.setdefault("skeleton", "MimicKit humanoid")
    meta.setdefault("sagittal_side", side)
    meta.setdefault("leg_length_m", LEG_LENGTH_M)
    return from_arrays(name, rollouts, mass_kg=mass, **meta)
