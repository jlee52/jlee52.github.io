"""Minimal C3D reader in numpy (no compiled dependencies, so it also runs in the browser).

Follows the C3D file format specification (Motion Lab Systems, "The C3D File Format: A Technical User
Guide"): a 512-byte header, the parameter section (groups and parameters) and the 3D point and analog
data, in Intel, DEC or MIPS (big-endian) processor formats, with integer or floating-point storage.
Force platforms of type 2 (Fx, Fy, Fz, Mx, My, Mz per plate) are converted to forces, moments about
the plate origin and centres of pressure in the laboratory frame.

    c = read_c3d("trial.c3d")
    c.points        [frames, markers, 3] (NaN where a marker is missing), in c.point_units
    c.labels        marker labels;  c.rate  point rate (Hz)
    c.analog        [samples, channels] scaled analog data;  c.analog_rate
    c.parameters    {GROUP: {PARAM: value}}
    force_platforms(c)   list of {"force", "cop"} [analog samples, 3] in the lab frame (N, m)
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

INTEL, DEC, MIPS = 84, 85, 86


@dataclass
class C3D:
    points: np.ndarray
    labels: list
    rate: float
    point_units: str
    analog: np.ndarray
    analog_labels: list
    analog_rate: float
    first_frame: int
    parameters: dict = field(default_factory=dict)

    def marker(self, name: str) -> np.ndarray:
        return self.points[:, self.labels.index(name)]


def _dec_to_ieee(raw: bytes) -> np.ndarray:
    """DEC (VAX F) 32-bit floats to IEEE: swap the 16-bit words, reinterpret, divide by 4."""
    w = np.frombuffer(raw, dtype="<u2").reshape(-1, 2)[:, ::-1].copy()
    f = w.view("<u4").view("<f4").ravel() / 4.0
    return f.astype(np.float32)


class _Reader:
    def __init__(self, buf: bytes, proc: int):
        self.buf, self.proc = buf, proc
        self.e = ">" if proc == MIPS else "<"

    def i8(self, o): return struct.unpack_from("b", self.buf, o)[0]
    def u8(self, o): return self.buf[o]
    def i16(self, o): return struct.unpack_from(self.e + "h", self.buf, o)[0]
    def u16(self, o): return struct.unpack_from(self.e + "H", self.buf, o)[0]

    def f32(self, o, n=1):
        raw = self.buf[o:o + 4 * n]
        if self.proc == DEC:
            return _dec_to_ieee(raw)
        return np.frombuffer(raw, dtype=self.e + "f4", count=n)


def _parse_parameters(r: _Reader, start: int) -> dict:
    groups, params = {}, {}
    o = start + 4
    end = len(r.buf)
    while o < end - 2:
        nlen, gid = r.i8(o), r.i8(o + 1)
        if nlen == 0:
            break
        name = r.buf[o + 2:o + 2 + abs(nlen)].decode("latin-1").strip().upper()
        p = o + 2 + abs(nlen)
        nxt = r.i16(p)
        body = p + 2
        if gid < 0:
            groups[-gid] = name
        else:
            t, nd = r.i8(body), r.u8(body + 1)
            dims = [r.u8(body + 2 + k) for k in range(nd)]
            d = body + 2 + nd
            n = int(np.prod(dims)) if dims else 1
            size = abs(t)
            if t == -1:
                raw = r.buf[d:d + n]
                if nd <= 1:
                    val = raw.decode("latin-1").rstrip()
                else:
                    w = dims[0]
                    val = [raw[k * w:(k + 1) * w].decode("latin-1").strip() for k in range(n // w)] if w else []
            elif t == 1:
                val = np.frombuffer(r.buf, dtype="u1", count=n, offset=d).copy()
            elif t == 2:
                val = np.frombuffer(r.buf, dtype=r.e + "i2", count=n, offset=d).copy()
            elif t == 4:
                val = r.f32(d, n).copy()
            else:
                val = None
            if t != -1 and val is not None:
                val = val.reshape(dims[::-1]) if nd > 1 else (val if nd == 1 else val[0])
            params.setdefault(gid, {})[name] = val
            del size
        if nxt == 0:
            break
        o = p + nxt
    return {groups.get(g, str(g)): ps for g, ps in params.items()}


def _labels(P: dict, group: str, key: str, n: int) -> list:
    out, k = [], ""
    while len(out) < n:
        v = P.get(group, {}).get(f"{key}{k}")
        if v is None:
            break
        out += [v] if isinstance(v, str) else list(v)
        k = 2 if k == "" else k + 1
    out = out[:n]
    return out + [f"{key[:-1] if key.endswith('S') else key}{i}" for i in range(len(out), n)]


def read_c3d(path_or_bytes) -> C3D:
    buf = bytes(path_or_bytes) if isinstance(path_or_bytes, (bytes, bytearray)) else Path(path_or_bytes).read_bytes()
    pblock = buf[0]
    if buf[1] != 0x50:
        raise ValueError("not a C3D file (header key 0x50 missing)")
    pstart = 512 * (pblock - 1)
    proc = buf[pstart + 3]
    if proc not in (INTEL, DEC, MIPS):
        proc = INTEL
    r = _Reader(buf, proc)
    n_pts, n_an_frame = r.u16(2), r.u16(4)
    first, last = r.u16(6), r.u16(8)
    scale = float(r.f32(12)[0])
    data_block = r.u16(16)
    rate = float(r.f32(20)[0])
    P = _parse_parameters(r, pstart)
    pt = P.get("POINT", {})
    n_pts = int(pt.get("USED", n_pts))
    scale = float(pt.get("SCALE", scale))
    rate = float(pt.get("RATE", rate))
    data_block = int(pt.get("DATA_START", data_block)) or data_block
    n_frames = last - first + 1
    if "FRAMES" in pt:                                          # stored as int16; unsigned for long files
        n_frames = int(np.uint16(np.int16(pt["FRAMES"]))) if int(pt["FRAMES"]) < 0 else int(pt["FRAMES"])
    an = P.get("ANALOG", {})
    n_ch = int(an.get("USED", 0))
    per = n_an_frame // n_ch if n_ch else 0
    is_float = scale < 0
    word = 4 if is_float else 2
    frame_words = 4 * n_pts + n_ch * per
    o = 512 * (data_block - 1)
    avail = (len(buf) - o) // (word * frame_words) if frame_words else 0
    n_frames = min(n_frames, avail)
    raw = buf[o:o + n_frames * frame_words * word]
    if is_float:
        vals = _dec_to_ieee(raw) if proc == DEC else np.frombuffer(raw, dtype=r.e + "f4")
    else:
        vals = np.frombuffer(raw, dtype=r.e + "i2").astype(np.float32)
    vals = vals.reshape(n_frames, frame_words)
    pts = vals[:, :4 * n_pts].reshape(n_frames, n_pts, 4).astype(float)
    xyz = pts[..., :3] * (1.0 if is_float else abs(scale))
    resid = pts[..., 3]
    bad = (resid < 0) | np.all(xyz == 0, axis=-1)              # negative residual word: point invalid
    xyz[bad] = np.nan
    A = vals[:, 4 * n_pts:].reshape(n_frames * per, n_ch).astype(float) if n_ch else np.zeros((0, 0))
    if n_ch:
        off = np.asarray(an.get("OFFSET", np.zeros(n_ch)), float).ravel()[:n_ch]
        sc = np.asarray(an.get("SCALE", np.ones(n_ch)), float).ravel()[:n_ch]
        gen = float(an.get("GEN_SCALE", 1.0))
        if not is_float and str(an.get("FORMAT", "SIGNED")).upper().startswith("UNSIGNED"):
            A = np.where(A < 0, A + 65536, A)
        A = (A - off) * sc * gen
    units = pt.get("UNITS", "mm")
    return C3D(points=xyz, labels=_labels(P, "POINT", "LABELS", n_pts), rate=rate,
               point_units=units if isinstance(units, str) else str(units),
               analog=A, analog_labels=_labels(P, "ANALOG", "LABELS", n_ch),
               analog_rate=float(an.get("RATE", rate * per)) if n_ch else 0.0, first_frame=first, parameters=P)


def _unit_scale(units: str) -> float:
    return {"mm": 1e-3, "cm": 1e-2, "m": 1.0}.get(units.strip().lower(), 1e-3)


def force_platforms(c: C3D) -> list[dict]:
    """Type-2 force platforms in the laboratory frame, at the analog rate: the force channels rotated
    into the lab (N; the sign convention of the channels varies between systems, so callers orient
    the vertical force themselves) and the centre of pressure on the plate surface (m). Checked
    against ezc3d (force and centre of pressure identical)."""
    fp = c.parameters.get("FORCE_PLATFORM", {})
    n = int(np.asarray(fp.get("USED", 0)).ravel()[0]) if "USED" in fp else 0
    if not n or not c.analog.size:
        return []
    types = np.atleast_1d(fp.get("TYPE", [2] * n)).astype(int)
    ch = np.asarray(fp["CHANNEL"]).reshape(n, -1).astype(int)        # stored as integers or floats
    corners = np.asarray(fp["CORNERS"], float).reshape(n, 4, 3)
    origin = np.asarray(fp.get("ORIGIN", np.zeros((n, 3))), float).reshape(n, 3)
    s = _unit_scale(c.point_units)
    units = c.parameters.get("ANALOG", {}).get("UNITS", [])
    out = []
    for k in range(n):
        if types[k] != 2:
            out.append(None)
            continue
        X = c.analog[:, ch[k, :6] - 1]
        mu = [str(u).replace(" ", "").replace(".", "").lower() for u in np.atleast_1d(units)[ch[k, 3:6] - 1]] \
            if len(np.atleast_1d(units)) >= ch[k, 5] else ["nmm"] * 3
        F = X[:, :3]
        M = X[:, 3:6] * np.array([1e-3 if u in ("nmm", "mmn") else 1.0 for u in mu])
        cs = corners[k] * s
        ax = cs[0] - cs[1]; ax /= np.linalg.norm(ax)
        ay = cs[0] - cs[3]; ay -= ax * (ay @ ax); ay /= np.linalg.norm(ay)
        az = np.cross(ax, ay)
        R = np.stack([ax, ay, az], 1)                          # plate -> lab
        o = origin[k] * s
        if o[2] > 0:                                           # origin given towards the top surface
            o = -o
        centre = cs.mean(0)
        po = centre - R @ o                                    # plate origin in the lab (below the surface)
        Fl = F @ R.T
        with np.errstate(invalid="ignore", divide="ignore"):
            # centre of pressure on the surface, in plate coordinates (surface at z = -o_z above the origin)
            h = -o[2]
            cx = (-M[:, 1] - F[:, 0] * h) / F[:, 2]
            cy = (M[:, 0] - F[:, 1] * h) / F[:, 2]
        cop = np.c_[cx, cy, np.zeros(len(F))] @ R.T + po
        cop += az * ((centre - cop) @ az)[:, None]             # onto the plane of the plate surface
        out.append({"force": Fl, "cop": cop, "corners": cs})
    return out
