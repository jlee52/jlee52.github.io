"""BVH motion files (animation and motion-capture exports) as an HLB data set.

The hierarchy is parsed and the joint positions are computed by forward kinematics: each joint's local
transform is its OFFSET plus any position channels, followed by its rotation channels applied in the
order listed (intrinsic Euler angles, degrees). Each file is one rollout (group: the file's parent
directory, the subject of CMU-style names <subject>_<trial>, or `group`). The pelvis and feet are joints found by name (common conventions are tried:
Hips / Pelvis, LeftFoot / LeftAnkle, ...; a "prefix:" such as "mixamorig:" is ignored) or given
explicitly. BVH is usually y-up; lengths are converted to metres from `units` (m, cm, mm, in, or cmu: the
CMU motion capture unit, 1/0.45 inch), or guessed ("auto") as the unit that gives an adult pelvis-to-foot
height (0.6-1.3 m).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .core import from_arrays
from .mocap import UNITS, guess_units

PELVIS = ("hips", "hip", "pelvis", "root")
LEFT = ("leftfoot", "leftankle", "lfoot", "l_foot", "lankle", "l_ankle", "left_foot", "left_ankle")
RIGHT = ("rightfoot", "rightankle", "rfoot", "r_foot", "rankle", "r_ankle", "right_foot", "right_ankle")


@dataclass
class Joint:
    name: str
    parent: int
    offset: np.ndarray
    channels: list


def parse_bvh(text: str):
    """(joints, frame_time, motion [frames, channels])."""
    tok = text.replace("{", " { ").replace("}", " } ").split()
    i, joints, stack = 0, [], []
    while tok[i].upper() != "MOTION":
        t = tok[i].upper()
        if t in ("ROOT", "JOINT"):
            joints.append(Joint(tok[i + 1], stack[-1] if stack else -1, np.zeros(3), []))
            i += 2
        elif t == "END":                                     # End Site: a leaf without channels
            joints.append(Joint(f"{joints[stack[-1]].name}_end", stack[-1], np.zeros(3), []))
            i += 2
        elif t == "{":
            stack.append(len(joints) - 1); i += 1
        elif t == "}":
            stack.pop(); i += 1
        elif t == "OFFSET":
            joints[stack[-1]].offset = np.array(tok[i + 1:i + 4], float); i += 4
        elif t == "CHANNELS":
            n = int(tok[i + 1]); joints[stack[-1]].channels = tok[i + 2:i + 2 + n]; i += 2 + n
        else:
            i += 1
    i += 1
    n_frames = int(tok[i + 1]); i += 2                      # Frames: N
    frame_time = float(tok[i + 2]); i += 3                  # Frame Time: dt
    n_ch = sum(len(j.channels) for j in joints)
    motion = np.array(tok[i:i + n_frames * n_ch], float).reshape(n_frames, n_ch)
    return joints, frame_time, motion


def forward_kinematics(joints, motion) -> np.ndarray:
    """World positions [frames, joints, 3] in file units."""
    from scipy.spatial.transform import Rotation
    T = len(motion)
    pos = np.zeros((T, len(joints), 3))
    rot = np.zeros((T, len(joints), 3, 3))
    c = 0
    for k, j in enumerate(joints):
        local_t = np.tile(j.offset, (T, 1))
        R = np.tile(np.eye(3), (T, 1, 1))
        order, angles = "", []
        for ch in j.channels:
            v = motion[:, c]; c += 1
            axis = ch[0].upper()
            if ch.lower().endswith("position"):
                local_t[:, "XYZ".index(axis)] += v
            else:
                order += axis; angles.append(v)
        if order:
            R = Rotation.from_euler(order, np.stack(angles, 1), degrees=True).as_matrix()
        if j.parent < 0:
            pos[:, k], rot[:, k] = local_t, R
        else:
            pr = rot[:, j.parent]
            pos[:, k] = pos[:, j.parent] + np.einsum("tij,tj->ti", pr, local_t)
            rot[:, k] = pr @ R
    return pos


def _find(names, candidates, given=None):
    if given is not None:
        return names.index(given)
    plain = [n.split(":")[-1].lower().replace(" ", "") for n in names]
    for cnd in candidates:
        if cnd in plain:
            return plain.index(cnd)
    raise KeyError(f"none of {candidates} among the joints {names[:20]}...; give the joint name explicitly")


def _files(inputs):
    if isinstance(inputs, (str, Path)):
        p = Path(inputs)
        return sorted(p.glob("*.bvh")) if p.is_dir() else [p]
    return [Path(x) for x in inputs]


def convert(inputs, name: str, *, pelvis=None, left_foot=None, right_foot=None, up="y", units="auto",
            group=None, mass_kg=None, leg_length_m=None, **meta):
    """inputs: a .bvh file, a directory of them, or a list. pelvis, left_foot, right_foot: joint names
    (found automatically if None). units: "m", "cm", "mm", "in", "cmu" or "auto"."""
    upi = "xyz".index(up)
    rollouts = []
    for f in _files(inputs):
        joints, dt, motion = parse_bvh(Path(f).read_text())
        names = [j.name for j in joints]
        X = forward_kinematics(joints, motion)
        ip, il, ir = _find(names, PELVIS, pelvis), _find(names, LEFT, left_foot), _find(names, RIGHT, right_foot)
        u = units
        if units == "auto":
            u = guess_units(float(np.median(X[:, ip, upi] - np.minimum(X[:, il, upi], X[:, ir, upi]))))
        s = UNITS[u]
        m = re.fullmatch(r"(\d+)_\d+", f.stem)                  # CMU trial names: <subject>_<trial>
        g = group or (f"subject {m.group(1)}" if m else f.parent.name)
        rollouts.append({"id": f.stem, "group": g, "fs": 1 / dt, "source": f.name,
                         "joints": {"pelvis": names[ip], "left_foot": names[il], "right_foot": names[ir]}, "units": u,
                         "arrays": {"pelvis_pos": X[:, ip] * s, "left_foot_pos": X[:, il] * s, "right_foot_pos": X[:, ir] * s}})
    meta.setdefault("kind", "human")
    meta.setdefault("skeleton", "BVH")
    return from_arrays(name, rollouts, mass_kg=mass_kg, leg_length_m=leg_length_m, up=up, **meta)
