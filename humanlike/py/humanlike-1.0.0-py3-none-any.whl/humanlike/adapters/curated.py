"""The manuscript's curated rollouts (data/curated/<model>/rollouts.npz: pelvis, left and right foot
positions at 30 Hz, foot strikes, session group) as an HLB data set. Converting AMP, SMP or KINESIS
and evaluating reproduces the manuscript's feedback signature (tests/test_engine.py)."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from .core import from_arrays


def convert(path, name: str, **meta):
    d = np.load(Path(path))
    xo, lo, ro = d["xpos_offsets"], d["lhs_offsets"], d["rhs_offsets"]
    fs = 1 / float(d["dt"])
    rollouts = []
    for i, (g, key) in enumerate(zip(d["group"], d["key"])):
        x = d["xpos"][xo[i]:xo[i + 1]].astype(float)
        rollouts.append({"id": f"{key}_{i}", "group": str(key), "fs": fs,
                         "arrays": {"pelvis_pos": x[:, 0], "left_foot_pos": x[:, 1], "right_foot_pos": x[:, 2],
                                    "left_heel_strikes": d["lhs"][lo[i]:lo[i + 1]].astype(int),
                                    "right_heel_strikes": d["rhs"][ro[i]:ro[i + 1]].astype(int)}})
    return from_arrays(name, rollouts, **meta)
