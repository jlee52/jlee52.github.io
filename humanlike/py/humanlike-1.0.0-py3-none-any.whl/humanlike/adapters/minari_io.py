"""Minari mapping of the humanlike locomotion profile (docs/oss/PROFILE.md).

A Minari dataset (Farama Foundation; HDF5 or Arrow) carries the profile as follows:
    dataset          one model (or one group of human subjects)
    metadata.json    "humanlike_profile": {"profile", "version", "samples_per_step", "fs", "up", "mass_kg",
                     "leg_length_m", "sagittal_side", "name", "kind", "simulator", "skeleton"}
    episode          one rollout; episode metadata (optional): "group", "commanded_speed", "fell", "skip_s"
    step infos       infos["humanlike"][<signal>]: the samples of the profile signal recorded since the
                     previous step, shape [samples_per_step, ...] (e.g. pelvis_pos [k, 3], left_grf [k, 3]);
                     foot strikes as boolean signals left_heel_strike / right_heel_strike [k]
The entry Minari stores at reset (index 0) is not used: an episode of n steps gives n x k samples, the
samples of step i covering the interval of action i. Signal names, shapes, units and sign conventions
are those of humanlike.format.spec.FIELDS; fs is the rate of the profile signals (k / control period).

    read(path_or_id) -> Dataset            a Minari dataset (directory or registered id) as a data set;
                                           needs only h5py (HDF5) or pyarrow (Arrow), not minari
    annotate(path_or_id, mass_kg=..., ...) add the profile metadata to a dataset recorded with DataCollector
    write(ds, dataset_id, ...)             export a data set to Minari (placeholder observations/actions)
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from ..format import Dataset, Rollout
from ..format.spec import FIELD

PROFILE = "humanlike-locomotion"
VERSION = "1.0"
KEY = "humanlike"
META = "humanlike_profile"
STRIKES = {"left_heel_strike": "left_heel_strikes", "right_heel_strike": "right_heel_strikes"}


def _open(path_or_id):
    import minari
    return minari.MinariDataset(data_dir(path_or_id))


def is_minari(path) -> bool:
    p = Path(str(path))
    return p.is_dir() and ((p / "data" / "metadata.json").exists() or (p / "metadata.json").exists())


def data_dir(path_or_id) -> Path:
    """The directory holding metadata.json: a dataset directory, its data/ folder, or a registered id
    under $MINARI_DATASETS_PATH (default ~/.minari/datasets)."""
    import os
    p = Path(str(path_or_id))
    if not p.exists():
        root = Path(os.environ.get("MINARI_DATASETS_PATH") or Path.home() / ".minari" / "datasets")
        p = root / str(path_or_id)
    if (p / "data" / "metadata.json").exists():
        return p / "data"
    if (p / "metadata.json").exists():
        return p
    raise FileNotFoundError(f"{path_or_id}: not a Minari dataset (no metadata.json)")


def _episodes(d: Path, fmt: str):
    """(episode metadata, {signal: [steps + 1, ...]}) per episode, read with h5py or pyarrow only, so
    that reading needs neither the minari package nor its dependencies (and runs in Pyodide)."""
    if fmt == "hdf5":
        import h5py
        with h5py.File(d / "main_data.hdf5", "r") as f:
            names = sorted((k for k in f if k.startswith("episode_")), key=lambda k: int(k.split("_")[1]))
            for n in names:
                g = f[n]
                em = {k: (v.decode() if isinstance(v, bytes) else v.item() if hasattr(v, "item") else v)
                      for k, v in g.attrs.items()}
                info = g.get("infos", {}).get(KEY) if "infos" in g else None
                yield em, None if info is None else {s: info[s][()] for s in info}
    else:
        import json
        import pyarrow as pa
        eps = sorted((x for x in d.iterdir() if x.is_dir() and x.name.isdigit()), key=lambda x: int(x.name))
        for e in eps:
            em = json.loads((e / "metadata.json").read_text()) if (e / "metadata.json").exists() else {"id": int(e.name)}
            tables = []
            for part in sorted(e.glob("*.arrow")):
                with pa.memory_map(str(part)) as src:
                    tables.append(pa.ipc.open_file(src).read_all())
            t = pa.concat_tables(tables)
            if "infos" not in t.column_names:
                yield em, None
                continue
            infos = t.column("infos").combine_chunks()
            if KEY not in [f.name for f in infos.type]:
                yield em, None
                continue
            h = infos.field(KEY)
            out = {}
            for i, fld in enumerate(h.type):
                col = h.field(i)
                shape = tuple(int(x) for x in (fld.metadata or {}).get(b"shape", b"").decode().split(",") if x)
                vals = np.asarray(col.flatten() if pa.types.is_fixed_size_list(col.type) else col.to_numpy(zero_copy_only=False))
                out[fld.name] = vals.reshape(len(col), *shape) if shape else vals.reshape(len(col), -1).squeeze(-1) \
                    if vals.size == len(col) else vals.reshape(len(col), -1)
            yield em, out


def read(path_or_id, name: str | None = None) -> Dataset:
    import json
    d = data_dir(path_or_id)
    meta = json.loads((d / "metadata.json").read_text())
    prof = meta.get(META)
    if not prof:
        raise ValueError(f"{path_or_id}: no '{META}' metadata; add it with humanlike.adapters.minari_io.annotate")
    k, fs = int(prof.get("samples_per_step", 1)), float(prof["fs"])
    rollouts = []
    for em, info in _episodes(d, meta.get("data_format", "hdf5")):
        eid = em.get("id")
        if info is None:
            raise ValueError(f"episode {eid}: no infos['{KEY}'] (record the episodes with record_infos=True)")
        arrays = {}
        for sig, val in info.items():
            a = np.asarray(val)[1:]                               # drop the reset entry
            sample_ndim = 0 if sig in STRIKES else 1 if sig in FIELD else a.ndim - 2
            if a.ndim == sample_ndim + 2:                         # [steps, k, ...] -> [steps * k, ...]
                a = a.reshape(a.shape[0] * a.shape[1], *a.shape[2:])
            elif not (a.ndim == sample_ndim + 1 and k == 1):
                raise ValueError(f"episode {eid}: infos['{KEY}']['{sig}'] has shape {np.shape(val)}; "
                                 f"expected [steps + 1, {k}, ...]")
            if sig in STRIKES:
                arrays[STRIKES[sig]] = np.flatnonzero(a.astype(bool).ravel())
            elif sig in FIELD:
                arrays[sig] = a.astype(float)
        rm = {"id": str(em.get("rollout_id", eid)), "group": str(em.get("group", "0")), "fs": fs}
        for key in ("commanded_speed", "fell", "skip_s"):
            if key in em:
                v = em[key]
                rm[key] = bool(v) if key == "fell" else float(v)
        rollouts.append(Rollout(rm, arrays))
    ds_meta = {"dataset": {k2: prof[k2] for k2 in ("kind", "simulator", "skeleton", "sagittal_side") if prof.get(k2) is not None},
               "subject": {k2: float(prof[k2]) for k2 in ("mass_kg", "leg_length_m") if prof.get(k2) is not None},
               "frame": {"up": prof.get("up", "z"), "units": "m"}}
    ds_meta["dataset"]["name"] = name or prof.get("name") or meta.get("dataset_id", "minari")
    ds_meta["dataset"]["source"] = f"minari:{meta.get('dataset_id')}"
    return Dataset(ds_meta, rollouts)


def annotate(path_or_id, *, fs: float, samples_per_step: int = 1, up: str = "z", mass_kg=None, leg_length_m=None,
             sagittal_side=None, name=None, kind="simulation", simulator=None, skeleton=None, episodes=None):
    """Add the profile metadata to a Minari dataset; episodes: optional list of per-episode dicts
    (group, commanded_speed, fell, skip_s), in episode order."""
    md = _open(path_or_id)
    prof = {"profile": PROFILE, "version": VERSION, "samples_per_step": int(samples_per_step), "fs": float(fs), "up": up,
            "mass_kg": mass_kg, "leg_length_m": leg_length_m, "sagittal_side": sagittal_side, "name": name, "kind": kind,
            "simulator": simulator, "skeleton": skeleton}
    md.storage.update_metadata({META: {k: v for k, v in prof.items() if v is not None}})
    if episodes is not None:
        md.storage.update_episode_metadata(episodes)
    return md


def write(ds: Dataset, dataset_id: str, *, samples_per_step: int = 1, data_format: str = "hdf5", root=None, **minari_kw):
    """Export to Minari. Observations are the core positions (pelvis, left foot, right foot) at the last
    sample of each step and actions a zero placeholder: the profile signals are in the step infos."""
    import os
    import gymnasium as gym
    import minari
    from minari.data_collector import EpisodeBuffer
    if root is not None:
        os.environ["MINARI_DATASETS_PATH"] = str(Path(root).resolve())
    k = int(samples_per_step)
    eps, epmeta = [], []
    for i, r in enumerate(ds.rollouts):
        T = len(r.arrays["pelvis_pos"]) // k * k
        n = T // k
        info = {}
        for sig, a in r.arrays.items():
            f = FIELD.get(sig)
            if f is None:
                continue
            if f.shape == "n":
                flag = np.zeros(T, bool)
                hs = np.asarray(a, int)
                flag[hs[hs < T]] = True
                sig, a = {v: k2 for k2, v in STRIKES.items()}[sig], flag
            a = np.asarray(a)[:T].reshape(n, k, *np.shape(a)[1:])
            info[sig] = np.concatenate([a[:1], a], 0)             # reset entry: a copy of the first step
        core = np.concatenate([np.asarray(r.arrays[s], float)[:T][k - 1::k] for s in ("pelvis_pos", "left_foot_pos", "right_foot_pos")], 1)
        obs = np.concatenate([core[:1], core], 0)
        eps.append(EpisodeBuffer(id=i, observations=obs, actions=np.zeros((n, 1), np.float32), rewards=list(np.zeros(n)),
                                 terminations=[False] * n, truncations=[False] * (n - 1) + [True], infos={KEY: info}))
        epmeta.append({"rollout_id": r.id, "group": str(r.meta["group"]),
                       **{key: r.meta[key] for key in ("commanded_speed", "fell", "skip_s") if r.meta.get(key) is not None}})
    obs_space = gym.spaces.Box(-np.inf, np.inf, (9,), np.float64)
    act_space = gym.spaces.Box(-1.0, 1.0, (1,), np.float32)
    minari_kw.setdefault("description", f"{ds.name}: humanlike locomotion profile {VERSION} (signals in infos['{KEY}'])")
    md = minari.create_dataset_from_buffers(dataset_id, eps, observation_space=obs_space, action_space=act_space,
                                            data_format=data_format, **minari_kw)
    fs = {r.fs for r in ds.rollouts}
    if len(fs) != 1:
        raise ValueError("Minari export needs one sampling rate for all rollouts")
    d, s = ds.meta.get("dataset", {}), ds.meta.get("subject", {})
    annotate(md.storage.data_path, fs=fs.pop(), samples_per_step=k, up=ds.meta.get("frame", {}).get("up", "z"),
             mass_kg=s.get("mass_kg"), leg_length_m=s.get("leg_length_m"), sagittal_side=d.get("sagittal_side"),
             name=ds.name, kind=d.get("kind", "simulation"), simulator=d.get("simulator"), skeleton=d.get("skeleton"),
             episodes=epmeta)
    return md
