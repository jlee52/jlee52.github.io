"""Generic construction of an HLB data set from arrays."""
from __future__ import annotations

from ..format import Dataset, Rollout


def from_arrays(name: str, rollouts: list[dict], *, mass_kg=None, leg_length_m=None, up="z", kind="simulation",
                simulator=None, skeleton=None, description=None, sagittal_side=None) -> Dataset:
    """rollouts: dicts with the rollout metadata (id, group, fs, and optionally commanded_speed, fell,
    skip_s) and an "arrays" dict named as in humanlike.format.spec.FIELDS."""
    meta = {"dataset": {k: v for k, v in dict(name=name, kind=kind, simulator=simulator, skeleton=skeleton,
                                                 description=description, sagittal_side=sagittal_side).items()
                         if v is not None},
            "subject": {k: v for k, v in dict(mass_kg=mass_kg, leg_length_m=leg_length_m).items() if v is not None},
            "frame": {"up": up, "units": "m"}}
    out = []
    for r in rollouts:
        r = dict(r)
        arrays = r.pop("arrays")
        out.append(Rollout(r, dict(arrays)))
    return Dataset(meta, out)
