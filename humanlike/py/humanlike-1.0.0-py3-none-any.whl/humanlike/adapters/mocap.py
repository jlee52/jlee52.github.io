"""Helpers shared by the motion-capture adapters (C3D, BVH, CSV): gap filling, valid segments,
treadmill-to-ground conversion, belt speed, and assignment of force-plate forces to the feet."""
from __future__ import annotations

import numpy as np

UNITS = {"m": 1.0, "cm": 1e-2, "mm": 1e-3, "in": 0.0254, "cmu": 0.0254 / 0.45}   # cmu: CMU mocap ASF/BVH unit


def guess_units(leg_height: float) -> str:
    """Unit whose pelvis-to-foot height is that of an adult leg (0.6-1.3 m), the closest to 0.9 m."""
    ok = {u: abs(leg_height * f - 0.9) for u, f in UNITS.items() if 0.6 <= leg_height * f <= 1.3}
    if not ok:
        raise ValueError(f"pelvis-to-foot height {leg_height:.3g} fits no unit ({', '.join(UNITS)}); give units")
    return min(ok, key=ok.get)


def fill_gaps(X: np.ndarray, max_gap: int) -> np.ndarray:
    """Linear interpolation of NaN runs of at most max_gap samples, per column; longer gaps stay NaN."""
    X = np.array(X, float)
    flat = X.reshape(len(X), -1)
    t = np.arange(len(X))
    for j in range(flat.shape[1]):
        x = flat[:, j]
        bad = np.isnan(x)
        if not bad.any() or bad.all():
            continue
        edges = np.diff(np.r_[0, bad.astype(int), 0])
        for a, b in zip(np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)):
            if b - a <= max_gap and a > 0 and b < len(x):
                x[a:b] = np.interp(t[a:b], [a - 1, b], [x[a - 1], x[b]])
    return flat.reshape(X.shape)


def longest_valid(*arrays) -> slice:
    """Longest run of samples where every array is finite."""
    ok = np.ones(len(arrays[0]), bool)
    for a in arrays:
        ok &= np.isfinite(np.asarray(a, float).reshape(len(a), -1)).all(1)
    if not ok.any():
        return slice(0, 0)
    edges = np.diff(np.r_[0, ok.astype(int), 0])
    starts, ends = np.flatnonzero(edges == 1), np.flatnonzero(edges == -1)
    k = int(np.argmax(ends - starts))
    return slice(int(starts[k]), int(ends[k]))


def _horizontal(up: int):
    return [i for i in range(3) if i != up]


def belt_motion(feet: list, fs: float, up: int, grf_vertical: list | None = None):
    """(speed m/s, unit walking direction [3]) of a treadmill trial from the feet in stance: a foot on the
    belt moves backwards at the belt speed. Stance: vertical GRF above 50 N if given, otherwise the
    lowest 20 % of the foot's height range."""
    h = _horizontal(up)
    vel, w = [], []
    for k, F in enumerate(feet):
        F = np.asarray(F, float)
        v = np.gradient(F[:, h], 1 / fs, axis=0)
        if grf_vertical is not None:
            st = np.asarray(grf_vertical[k]) > 50
        else:
            z = F[:, up]
            st = z < np.nanpercentile(z, 2) + 0.2 * (np.nanpercentile(z, 98) - np.nanpercentile(z, 2))
        st &= np.isfinite(v).all(1)
        vel.append(v[st])
    V = np.concatenate(vel)
    d = -np.median(V, 0)                                   # walking direction: opposite to the belt
    d /= np.linalg.norm(d)
    speed = float(np.median(-(V @ d)))
    u = np.zeros(3)
    u[h] = d
    return speed, u


def treadmill_to_ground(arrays: dict, fs: float, speed: float, direction: np.ndarray, names) -> dict:
    """Positions as if walking over ground: each position array is moved forward by speed x t along the
    walking direction (velocities by speed)."""
    out = dict(arrays)
    t = np.arange(len(next(iter(arrays.values())))) / fs
    for n in names:
        if n in out:
            if n.endswith("_vel"):
                out[n] = np.asarray(out[n], float) + speed * direction
            else:
                out[n] = np.asarray(out[n], float) + speed * t[:, None] * direction
    return out


def to_rate(x: np.ndarray, per: int) -> np.ndarray:
    """Analog samples to the point rate: mean over each frame's `per` samples."""
    x = np.asarray(x, float)
    n = len(x) // per
    return x[:n * per].reshape(n, per, *x.shape[1:]).mean(1)


def plates_to_feet(plates: list, feet: dict, up: int, threshold: float = 20.0):
    """Ground reaction force on each foot from force plates: at every sample, each loaded plate's force
    (oriented so that its vertical component is positive under load) is given to the foot nearest to its
    centre of pressure (horizontal distance). plates: [{"force", "cop"}] at the feet's rate;
    feet: {"left": [T, 3], "right": [T, 3]}. Returns {"left": [T, 3], "right": [T, 3]} (N)."""
    h = _horizontal(up)
    out = {k: np.zeros_like(np.asarray(v, float)) for k, v in feet.items()}
    names = list(feet)
    P = np.stack([np.asarray(feet[k], float)[:, h] for k in names])          # [2, T, 2]
    for pl in plates:
        if pl is None:
            continue
        F, C = np.asarray(pl["force"], float), np.asarray(pl["cop"], float)
        load = np.abs(F[:, up]) > threshold
        if not load.any():
            continue
        if np.median(F[load, up]) < 0:
            F = -F
        d = np.linalg.norm(P - C[None, :, h], axis=-1)                       # [2, T]
        d = np.where(np.isfinite(d), d, np.inf)
        k = np.argmin(d, 0)
        for i, n in enumerate(names):
            m = load & (k == i)
            out[n][m] += F[m]
    return out
