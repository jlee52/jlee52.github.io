"""Reference data bundle: the human and expert data each analysis compares against.

A bundle is a directory with ``manifest.json`` and one ``.npz`` per reference:
    {"version": "1", "references": {name: {"kind": "gait" | "feedback", "file": ..., "license": ...,
                                            "source": ..., "description": ..., "restrict_speed": bool}}}
    gait      speeds, stride_lengths, stride_frequencies   one point per trajectory or subject x speed
    feedback  gains [n, 101, 5], ctl_mag [n, 101]          foot-placement fits per subject or session
    sagittal  angles [subjects, speeds, 101, 3], n_strides, subject, speed   mean gait cycles
    kinetics  features [strides, F], stride_subject, stride_bin, subject, mass_kg, leg_length
              per-stride kinetic features (humanlike.kinetics.FEATURES)

Built by scripts/build_reference_bundle.py. The bundle is looked up in $HUMANLIKE_REFERENCES, then
in references/v1 of the source tree.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

import numpy as np

DEFAULT = Path(__file__).resolve().parent.parent / "references" / "v1"
DEFAULTS = {"gait": ["camargo-treadmill/gait"], "feedback": ["camargo-treadmill/feedback"],
            "sagittal": ["camargo-treadmill/sagittal"], "kinetics": ["camargo-treadmill/kinetics"]}


@dataclass
class Reference:
    name: str
    kind: str
    meta: dict
    data: dict


class Bundle:
    def __init__(self, path=None):
        self.path = Path(path or os.environ.get("HUMANLIKE_REFERENCES") or DEFAULT)
        mf = self.path / "manifest.json"
        if not mf.exists():
            raise FileNotFoundError(f"no reference bundle at {self.path} (build it with scripts/build_reference_bundle.py "
                                    "or set HUMANLIKE_REFERENCES)")
        self.manifest = json.loads(mf.read_text())
        self._cache: dict[str, Reference] = {}

    def names(self, kind: str | None = None) -> list[str]:
        return [n for n, m in self.manifest["references"].items()
                if (kind is None or m["kind"] == kind) and (self.path / m["file"]).exists()]

    def get(self, name: str) -> Reference:
        if name not in self._cache:
            m = self.manifest["references"].get(name)
            if m is None:
                raise KeyError(f"unknown reference {name!r}; available: {', '.join(self.names())}")
            f = self.path / m["file"]
            if not f.exists():
                raise FileNotFoundError(f"reference {name!r} is listed but {f.name} is not in the bundle "
                                        f"(license: {m.get('license', '?')})")
            with np.load(f) as z:
                self._cache[name] = Reference(name, m["kind"], m, {k: z[k] for k in z.files})
        return self._cache[name]
