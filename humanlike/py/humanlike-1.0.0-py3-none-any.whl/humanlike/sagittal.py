"""Sagittal joint angles against human walking with speed as a continuous variable.

Human reference: Camargo et al. (2021) treadmill walking, the mean gait cycle of each subject at each
treadmill speed (0.5-1.85 m/s in 0.05 m/s steps; scripts/curate_camargo_sagittal.py --continuous).
For each feature below, the subject means are fitted by quadratic quantile regression on speed (as
Figure 2): median mu(v) and quartiles. Each model rollout (its gait cycles averaged, as for MPJAE)
whose speed lies in the human range is compared at its own speed:
    difference d = x - mu(v)   (deg or % of the cycle)
    robust z     = d / (IQR(v) / 1.349)
Per model and feature: the median difference and the median z over rollouts (consistent with the human
reference if |median z| <= Z_MAX), a Wilcoxon signed-rank test of z against 0 (Holm-corrected over all
models and features), and between models Welch's ANOVA and Games-Howell on |z|.

Features (gait cycle from foot strike, 0-100 %), with windows from the gait phases of Perry & Burnfield
(2010): initial contact 0-2 %, loading response 2-12 %, mid stance 12-31 %, terminal stance 31-50 %,
pre-swing 50-62 %, initial swing 62-75 %, mid swing 75-87 %, terminal swing 87-100 % (PHASES). Their
joint motions define the features: the knee flexes to about 15 deg in loading response (peak at the
transition to mid stance) and extends to about 0 deg in single-limb support (mid and terminal stance);
the ankle reaches about 20 deg of plantarflexion at the end of pre-swing (toe-off) and returns towards
neutral in initial swing; the knee reaches its peak of about 60 deg at the end of initial swing.
  hip / ankle range of motion     max - min over the cycle
  knee at foot strike             at initial contact (0 %)
  knee loading flexion            max over loading response and mid stance (0-31 %)
  knee midstance minimum          min over single-limb support (12-50 %)
  peak knee flexion, its timing   max over pre-swing and swing (50-100 %)
  push-off plantarflexion timing  ankle min over pre-swing and initial swing (50-75 %)
The phase percentages are those of walking at self-selected speed; windows spanning two phases keep
each event inside them when its timing shifts with speed (human toe-off: 66 % at 0.5 m/s, 59 % at 1.85 m/s).
Absolute hip and ankle angles depend on each skeleton's zero pose and are not compared.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .principles import SpeedModel, Z_MAX

FEATURES = {   # name: (label, unit)
    "hip_excursion": ("hip range of motion", "deg"),
    "knee_swing_peak": ("peak knee flexion", "deg"),
    "knee_peak_time": ("peak knee flexion timing", "%"),
    "knee_early_stance": ("knee loading flexion", "deg"),
    "knee_heel_strike": ("knee at foot strike", "deg"),
    "knee_midstance_min": ("knee midstance minimum", "deg"),
    "ankle_excursion": ("ankle range of motion", "deg"),
    "ankle_pf_time": ("push-off plantarflexion timing", "%"),
}


PHASES = {"IC": (0, 2), "LR": (2, 12), "MSt": (12, 31), "TSt": (31, 50), "PSw": (50, 62), "ISw": (62, 75),
          "MSw": (75, 87), "TSw": (87, 100)}   # % of the gait cycle (Perry & Burnfield 2010)


def _w(first: str, last: str) -> slice:
    """Samples of the 101-point cycle from the start of phase `first` to the end of phase `last`."""
    return slice(PHASES[first][0], PHASES[last][1] + 1)


def features(c: np.ndarray) -> dict:
    """c [..., 101, 3] hip, knee, ankle angles (deg, + = flexion / dorsiflexion) over the gait cycle."""
    hip, knee, ankle = c[..., 0], c[..., 1], c[..., 2]
    sw, po = _w("PSw", "TSw"), _w("PSw", "ISw")
    return {
        "hip_excursion": np.ptp(hip, axis=-1),
        "knee_swing_peak": knee[..., sw].max(-1),
        "knee_peak_time": sw.start + np.argmax(knee[..., sw], -1).astype(float),
        "knee_early_stance": knee[..., _w("IC", "MSt")].max(-1),
        "knee_heel_strike": knee[..., 0],
        "knee_midstance_min": knee[..., _w("MSt", "TSt")].min(-1),
        "ankle_excursion": np.ptp(ankle, axis=-1),
        "ankle_pf_time": po.start + np.argmin(ankle[..., po], -1).astype(float),
    }


def human_table(hum) -> pd.DataFrame:
    """Features of every subject x speed mean cycle (rows with complete data)."""
    A = hum["angles"].astype(float)                       # [subjects, speeds, 101, 3]
    S, V = A.shape[:2]
    ok = np.isfinite(A).all(axis=(2, 3)) & (hum["n_strides"] >= 3)
    f = features(A[ok])
    v = np.tile(hum["speed"], (S, 1))
    return pd.DataFrame({"unit": np.repeat(hum["subject"], V).reshape(S, V)[ok], "speed": v[ok], **f})


def human_bin(hum, first: float, last: float):
    """Each subject's mean gait cycle over all its strides at the treadmill speeds first..last (the speed
    means weighted by their stride counts) -> ([subjects, 101, 3], number of strides)."""
    sel = (hum["speed"] >= first - 1e-9) & (hum["speed"] <= last + 1e-9)
    A, n = hum["angles"][:, sel].astype(float), hum["n_strides"][:, sel].astype(float)
    n = np.where(np.isfinite(A).all(axis=(2, 3)), n, 0)
    w = n[..., None, None]
    with np.errstate(invalid="ignore"):
        H = (np.nan_to_num(A) * w).sum(1) / w.sum(1)
    ok = n.sum(1) > 0
    return H[ok], int(n.sum())


def model_table(angles: dict, cfg: dict) -> dict[str, pd.DataFrame]:
    """Features of each model's rollouts (cycle-averaged sagittal angles), as fig_sagittal."""
    from .conventional import sagittal_angle
    sg, mp = cfg["conventional"]["sagittal"], cfg["conventional"]["mpjae"]
    out = {}
    for m in cfg["models"]:
        spec = mp["models"][m]
        sim = angles[spec["sim"]]
        sk = mp["references"][spec["reference"]]["skeleton"]
        X = np.stack([sagittal_angle(sim, *sg["joints"][sk][j]) for j in ("Hip", "Knee", "Ankle")], axis=-1)
        out[m] = pd.DataFrame({"unit": np.arange(len(X)), "speed": np.asarray(sim["speed"], float), **features(X)})
    return out


def evaluate(hum, angles: dict, cfg: dict) -> dict:
    from scipy.stats import wilcoxon
    from statsmodels.stats.multitest import multipletests

    from .stats import compare_groups

    H = human_table(hum)
    lo, hi = float(H.speed.min()), float(H.speed.max())
    ref = {k: SpeedModel(H.speed.to_numpy(), H[k].to_numpy()) for k in FEATURES}
    models = {m: df[(df.speed >= lo) & (df.speed <= hi)].reset_index(drop=True) for m, df in model_table(angles, cfg).items()}
    rows, zrows = [], []
    for m, df in models.items():
        for k in FEATURES:
            mu, sd = ref[k](df.speed.to_numpy())
            d = df[k].to_numpy() - mu
            z = d / sd
            ok = np.isfinite(z)
            r = dict(model=m, feature=k, n=int(ok.sum()), median_diff=np.nan, median_z=np.nan, z_q25=np.nan, z_q75=np.nan,
                     p=np.nan, consistent=None)
            if ok.sum():
                r.update(median_diff=float(np.median(d[ok])), median_z=float(np.median(z[ok])),
                         z_q25=float(np.percentile(z[ok], 25)), z_q75=float(np.percentile(z[ok], 75)),
                         consistent=bool(abs(np.median(z[ok])) <= Z_MAX))
                if ok.sum() >= 5 and np.any(z[ok] != 0):
                    r["p"] = float(wilcoxon(z[ok]).pvalue)
                zrows += [dict(model=m, feature=k, rollout=u, speed=s, value=x, diff=dd, z=zz)
                          for u, s, x, dd, zz in zip(df.unit[ok], df.speed[ok], df[k][ok], d[ok], z[ok])]
            rows.append(r)
    tests = pd.DataFrame(rows)
    m_ = tests.p.notna()
    tests["p_holm"] = np.nan
    tests.loc[m_, "p_holm"] = multipletests(tests.p[m_], method="holm")[1]
    Z = pd.DataFrame(zrows)
    between = {k: compare_groups({m: np.abs(Z.z[(Z.feature == k) & (Z.model == m)].to_numpy()) for m in models})
               for k in FEATURES}
    return {"tests": tests, "z": Z, "between": between, "human": H, "models": models, "reference": ref,
            "human_range": (lo, hi)}


# --------------------------------------------------------------------------- #
# Waveform shape after range-of-motion normalization
JOINTS = ("Hip", "Knee", "Ankle")


def rom_normalize(c: np.ndarray) -> np.ndarray:
    """Each joint's curve [..., 101, 3] scaled to 0 (its minimum) - 1 (its maximum) over the cycle, which
    removes the skeleton-dependent offset and the range of motion and leaves the waveform shape."""
    lo, hi = c.min(-2, keepdims=True), c.max(-2, keepdims=True)
    with np.errstate(invalid="ignore", divide="ignore"):
        return (c - lo) / (hi - lo)


def shape(hum, angles: dict, cfg: dict) -> dict:
    """Shape distance of each joint: RMS difference (% of the range of motion) between a cycle's
    ROM-normalized curve and the mean ROM-normalized human curve at the nearest treadmill speed.
    Human reference: each subject x speed curve against the mean of the other subjects at that speed
    (leave-one-out), fitted against speed by quadratic quantile regression; models: every rollout in
    the human speed range, robust z against it (consistent if median z <= Z_MAX: no farther from the
    human mean shape than humans are)."""
    from scipy.stats import wilcoxon
    from statsmodels.stats.multitest import multipletests

    from .stats import compare_groups

    A = rom_normalize(hum["angles"].astype(float))                       # [subjects, speeds, 101, 3]
    ok = np.isfinite(A).all(axis=(2, 3)) & (hum["n_strides"] >= 3)
    speeds = hum["speed"]
    rows = []
    for k, v in enumerate(speeds):
        idx = np.flatnonzero(ok[:, k])
        for s in idx:
            ref = A[np.setdiff1d(idx, s), k].mean(0)
            d = 100 * np.sqrt(np.mean((A[s, k] - ref) ** 2, axis=0))
            rows.append({"unit": str(hum["subject"][s]), "speed": float(v), **dict(zip(JOINTS, d))})
    H = pd.DataFrame(rows)
    mean_shape = np.stack([A[ok[:, k], k].mean(0) for k in range(len(speeds))])     # [speeds, 101, 3]
    lo, hi = float(speeds.min()) - .025, float(speeds.max()) + .025
    refm = {j: SpeedModel(H.speed.to_numpy(), H[j].to_numpy()) for j in JOINTS}
    from .conventional import sagittal_angle
    sg, mp = cfg["conventional"]["sagittal"], cfg["conventional"]["mpjae"]
    out, zrows = [], []
    models = {}
    for m in cfg["models"]:
        spec = mp["models"][m]
        sim = angles[spec["sim"]]
        sk = mp["references"][spec["reference"]]["skeleton"]
        X = rom_normalize(np.stack([sagittal_angle(sim, *sg["joints"][sk][j]) for j in JOINTS], axis=-1))
        sp = np.asarray(sim["speed"], float)
        keep = (sp >= lo) & (sp <= hi) & np.isfinite(X).all(axis=(1, 2))
        X, sp = X[keep], sp[keep]
        near = np.abs(sp[:, None] - speeds[None]).argmin(1)
        d = 100 * np.sqrt(np.mean((X - mean_shape[near]) ** 2, axis=1))            # [rollouts, 3]
        models[m] = pd.DataFrame({"unit": np.arange(len(X)), "speed": sp, **dict(zip(JOINTS, d.T))})
        for i, j in enumerate(JOINTS):
            mu, sdv = refm[j](sp)
            z = (d[:, i] - mu) / sdv
            r = dict(model=m, joint=j, n=len(z), median_distance=float(np.median(d[:, i])),
                     human_median=float(np.median(mu)), median_z=float(np.median(z)),
                     consistent=bool(np.median(z) <= Z_MAX), p=float(wilcoxon(z).pvalue) if len(z) >= 5 else np.nan)
            out.append(r)
            zrows += [dict(model=m, joint=j, rollout=u, speed=s, distance=dd, z=zz)
                      for u, s, dd, zz in zip(range(len(z)), sp, d[:, i], z)]
    tests = pd.DataFrame(out)
    tests["p_holm"] = multipletests(tests.p, method="holm")[1]
    Z = pd.DataFrame(zrows)
    between = {j: compare_groups({m: Z.distance[(Z.joint == j) & (Z.model == m)].to_numpy() for m in models})
               for j in JOINTS}
    return {"tests": tests, "z": Z, "between": between, "human": H, "models": models, "reference": refm,
            "mean_shape": mean_shape, "speeds": speeds}
