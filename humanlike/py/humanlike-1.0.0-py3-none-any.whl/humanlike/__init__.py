"""Human-likeness metrics for simulated locomotion, as defined in the manuscript
"Generative AI moves, but not like us" (Methods, Sec. 2.3-2.5).

    feedforward  JS divergence of speed-dependent stride profiles      (Sec. Feedforward signature)
    feedback     FPGD and peak relative predictive power / timing      (Sec. Feedback signature)
    energetics   two-Gaussian COT fit and human-like classification    (Sec. Energetic COT modeling)

Every function takes plain arrays in the final vis_hum data format, so the metrics can be
applied to any new model without the rest of the pipeline.
"""
from .feedforward import js_divergence, kde_divergences
from .feedback import fpgd, peak_delta_r2
from .energetics import COTCriteria, fit_cot, classify_cot

__all__ = ["js_divergence", "kde_divergences", "fpgd", "peak_delta_r2",
           "COTCriteria", "fit_cot", "classify_cot"]
__version__ = "1.0.0"
