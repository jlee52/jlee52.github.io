"""A data set at a glance, before evaluating it: what it holds, how it was recorded, and which analyses its
speeds, rollouts and strides support (humanlike.coverage), without running the analyses.

    humanlike inspect DATA [--json out.json] [--no-strides]          (humanlike.overview)
"""
from __future__ import annotations

import numpy as np

STAGES = ("gait_scaling", "feedback", "energetics", "sagittal", "kinetic_principles")


def inspect(ds, strides: bool = True) -> dict:
    """{dataset, subject, rollouts, signals, provenance, coverage}. strides: also count the foot-placement
    strides per group (the feedback signature's requirement; fits nothing, but detects the strides)."""
    from .coverage import assess, measure
    from .engine import evaluate
    from .format import validate
    rep = validate(ds).to_dict()
    R = ds.rollouts
    fell = [bool(r.meta.get("fell")) for r in R]
    dur = [len(r.arrays["pelvis_pos"]) / r.fs for r in R if "pelvis_pos" in r.arrays]
    cmd = [r.meta.get("commanded_speed") for r in R]
    levels = {}
    for c, f in zip(cmd, fell):
        if c is not None:
            k = f"{float(c):.2f}"
            levels.setdefault(k, [0, 0])
            levels[k][0] += 1
            levels[k][1] += f
    out = {"dataset": dict(ds.meta.get("dataset", {})), "subject": dict(ds.meta.get("subject", {})),
           "rollouts": {"n": len(R), "fell": int(sum(fell)), "groups": len({str(r.meta.get("group")) for r in R}),
                        "fs": sorted({float(r.fs) for r in R}),
                        "seconds": [float(np.min(dur)), float(np.median(dur)), float(np.max(dur))] if dur else None,
                        "skip_s": sorted({float(r.meta.get("skip_s") or 0) for r in R}),
                        "transient_dropped_s": sorted({float(r.meta.get("transient_dropped_s") or 0) for r in R}),
                        "commanded_speeds": {k: {"rollouts": v[0], "fell": v[1]} for k, v in sorted(levels.items(), key=lambda x: float(x[0]))}},
           "signals": {k: v["available"] for k, v in rep["capabilities"].items()},
           "validation": {"ok": rep["ok"], "errors": rep["errors"], "warnings": len(rep["warnings"])},
           "provenance": ds.meta.get("dataset", {}).get("provenance")}
    out["dataset"].pop("provenance", None)
    if not rep["ok"]:
        return out
    only = ["gait_summary"] + (["foot_placement"] if strides else [])
    res = evaluate(ds, only=only, bootstrap=0)
    rows = (res["stages"].get("gait_summary", {}).get("result") or {}).get("rollouts", [])
    ranges = _reference_ranges()
    cov = {}
    for st in STAGES:
        if st == "feedback":
            fp = res["stages"].get("foot_placement", {}).get("result")
            if not strides or fp is None:
                continue
            have = measure(strides_per_group=list(fp.get("strides", [])))
        else:
            lo, hi = ranges.get(st, (-np.inf, np.inf))
            have = measure([x for x in rows if lo <= x["speed"] <= hi])
        c = assess(st, have)
        cov[st] = {"status": c["status"], "missing": c["missing"], "have": c["have"]}
    out["coverage"] = cov
    out["speed"] = [float(np.min([x["speed"] for x in rows])), float(np.max([x["speed"] for x in rows]))] if rows else None
    out["events"] = (res["stages"].get("events", {}).get("result") or {}).get("strike_source")
    return out


def _reference_ranges() -> dict:
    """Speed ranges of the default human references (the analyses compare within them)."""
    try:
        from .references import DEFAULTS, Bundle
        b = Bundle()
        g = b.get(DEFAULTS["gait"][0]).data["speeds"]
        s = b.get(DEFAULTS["sagittal"][0]).data["speed"]
        return {"gait_scaling": (float(g.min()), float(g.max())),
                "sagittal": (float(s.min()) - .025, float(s.max()) + .025),
                "kinetic_principles": (0.54, 2.03)}          # subject x speed-bin means of the kinetic reference
    except (FileNotFoundError, KeyError):
        return {}


def render(info: dict) -> str:
    d, s, r = info["dataset"], info["subject"], info["rollouts"]
    lines = [f"{d.get('name', 'data set')}  ({', '.join(str(d[k]) for k in ('kind', 'simulator', 'skeleton') if d.get(k))})"]
    if s:
        lines.append("  subject: " + ", ".join(f"{k} {v:g}" for k, v in s.items()))
    sec = r["seconds"]
    lines.append(f"  rollouts: {r['n']} ({r['fell']} fell), {r['groups']} groups, "
                 f"{'/'.join(f'{f:g}' for f in r['fs'])} Hz" + (f", {sec[1]:.1f} s (min {sec[0]:.1f}, max {sec[2]:.1f})" if sec else ""))
    t = [f"skip_s {', '.join(f'{x:g}' for x in r['skip_s'])}"]
    if any(r["transient_dropped_s"]):
        t.append(f"dropped while recording {', '.join(f'{x:g}' for x in r['transient_dropped_s'])} s")
    lines.append("  transient: " + "; ".join(t))
    if r["commanded_speeds"]:
        lines.append("  commanded speeds: " + ", ".join(f"{k} ({v['rollouts']}" + (f", {v['fell']} fell)" if v["fell"] else ")")
                                                       for k, v in r["commanded_speeds"].items()))
    if info.get("speed"):
        lines.append(f"  measured speeds: {info['speed'][0]:.2f}-{info['speed'][1]:.2f} m/s")
    if info.get("events"):
        lines.append("  foot strikes: " + ", ".join(f"{k} {v}" for k, v in info["events"].items()) + " (feet x rollouts)")
    lines.append("  signals: " + ", ".join(f"{'+' if v else '-'}{k}" for k, v in info["signals"].items()))
    v = info["validation"]
    lines.append(f"  validation: {'OK' if v['ok'] else 'INVALID'}" + ("" if v["ok"] else ": " + "; ".join(v["errors"]))
                 + (f" ({v['warnings']} warnings: humanlike validate)" if v["warnings"] else ""))
    if info.get("coverage"):
        lines.append("  coverage (humanlike.coverage; docs/oss/COVERAGE.md):")
        for k, c in info["coverage"].items():
            lines.append(f"    {k:<19s} {c['status']:<12s} " + "; ".join(c["missing"]))
    p = info.get("provenance")
    if p:
        lines.append(f"  recorded: {p.get('recorded', '?')} under {(p.get('protocol') or {}).get('name', '?')}, seed {p.get('seed')}, "
                     + ", ".join(f"{k} {x}" for k, x in (p.get("versions") or {}).items()))
    return "\n".join(lines)
