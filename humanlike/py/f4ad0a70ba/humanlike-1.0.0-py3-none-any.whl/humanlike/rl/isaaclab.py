"""Recording the profile signals of an Isaac Lab environment (vectorized, physics rate).

    add_foot_contact_sensors(env_cfg, body_map)    # before gym.make: ground reaction forces with friction
    env = gym.make(task, cfg=env_cfg)
    rec = IsaacLabRecorder(env, body_map)
    obs, _ = env.reset()
    for _ in range(n):
        obs, rew, terminated, truncated, info = env.step(policy(obs))
        rec.after_step(terminated, truncated)       # ends the episodes of the environments that reset
    ds = rec.dataset("MyPolicy")

Isaac Lab steps the physics `decimation` times per env step and calls scene.update after each physics
step; the recorder wraps scene.update and samples every environment after each update:
    positions              robot.data.body_pos_w of the pelvis and the first foot body
    ground reaction force  the floor-on-foot force: normal and friction forces between each foot body
                           and the ground, from one contact sensor per foot body filtered to the ground
                           (add_foot_contact_sensors). Without these sensors the scene's contact sensor
                           is used, whose net_forces_w holds the normal forces only: the horizontal
                           (braking, propulsive) forces are then missing; the recorder warns and labels
                           the data set (grf_source), and check() fails on walking data
    centre of mass         robot.data.body_com_pos_w / body_com_lin_vel_w weighted by the body masses
    joint torque, velocity the drive torque (below) and joint_vel (all joints)
    sagittal joints        joint_pos (deg), applied_torque and power of the body map's joints
    segment orientations   body_quat_w of the body map's segments (~50 Hz, for check() only)
The body map names Isaac Lab bodies and joints; z is up. Checked in Isaac Lab 2.3 / Isaac Sim 5.1 with
the H1 velocity task and its published policy (scripts/check_rl_recorder_isaaclab.py), and against an
object with the same interface (tests/test_rl.py). Friction forces come from the sensor's
friction_forces_w where Isaac Lab provides it (track_friction_forces), else from its PhysX contact view.

Joint torques. With implicit actuators (ImplicitActuator: PD gains handed to PhysX, Isaac Lab's default for
many humanoids) robot.data.applied_torque is Isaac Lab's evaluation of the PD law on the state before the
step, not the effort PhysX applies in its implicit integration. The recorder takes the drive torque from
PhysX instead (joint_torque="auto"): the joint force PhysX transmits along each DOF
(root_physx_view.get_dof_projected_joint_forces) plus the joint armature times the DOF acceleration
(PhysX's mass matrix leaves the armature, a rotor inertia, out). Checked on the H1 task
(scripts/check_isaaclab_torques.py):
    explicit actuators (the applied torque known): R^2 0.998-0.9999 per joint group, summed |power| within 0.1 %
    implicit actuators: applied_torque was off by +4.9 % in summed |power| (knee R^2 0.996)
At a joint limit the transmitted force also holds the passive limit force; there (within 0.01 rad of a
limit) applied_torque is used, and the share of such samples is reported by check(). joint_torque="applied"
keeps robot.data.applied_torque for every joint; "physx" uses the PhysX torque for explicit actuators too.
The first sample of each environment has no acceleration (zero armature torque); the start-up transient
covers it.
"""
from __future__ import annotations

import warnings

import numpy as np

from .bodymap import BodyMap, bodymap


GROUND_PLANE = "/terrain/GroundPlane/CollisionPlane"     # the collision prim of Isaac Lab's flat terrain


def add_foot_contact_sensors(env_cfg, body_map, ground: str | None = None, robot_path: str = "{ENV_REGEX_NS}/Robot",
                             max_contacts: int = 16):
    """Add one contact sensor per foot body, filtered to the ground, to an Isaac Lab env config (before the
    environment is made): scene attributes humanlike_left_foot0, ..., humanlike_right_foot0, ...
    ground: the ground's collision prim; default the flat terrain's (terrain prim path + GROUND_PLANE)."""
    from isaaclab.sensors import ContactSensorCfg
    m = bodymap(body_map)
    if ground is None:
        terrain = getattr(env_cfg.scene, "terrain", None)
        if terrain is None or getattr(terrain, "terrain_type", None) != "plane":
            raise ValueError("pass ground= (the ground's collision prim path) for terrain other than a flat plane")
        ground = terrain.prim_path + GROUND_PLANE
    extra = {"track_friction_forces": True} if "track_friction_forces" in ContactSensorCfg.__dataclass_fields__ else {}
    for side, feet in (("left", m.left_foot), ("right", m.right_foot)):
        for i, b in enumerate(feet):
            setattr(env_cfg.scene, f"humanlike_{side}_foot{i}", ContactSensorCfg(
                prim_path=f"{robot_path}/{b}", update_period=0.0, history_length=1, filter_prim_paths_expr=[ground],
                max_contact_data_count_per_prim=max_contacts, **extra))
    return env_cfg


def _np(x):
    if hasattr(x, "detach"):
        x = x.detach()
    if hasattr(x, "cpu"):
        x = x.cpu()
    return np.array(x, dtype=float)            # a copy: the simulator updates its buffers in place


class IsaacLabRecorder:
    """Records the profile signals of every environment of a running Isaac Lab environment at the physics
    rate (see the module docstring): call after_step(terminated, truncated) after every env step and
    dataset(name) at the end; check() tests a recorded episode; memory options as HumanlikeRecorder."""

    def __init__(self, env, body_map, robot: str = "robot", contact_sensor: str = "contact_forces",
                 fell_height: float | None = 0.5, dtype=None, keep_transient: bool = True, spill_dir=None,
                 joint_torque: str = "auto"):
        u = getattr(env, "unwrapped", env)
        self.env, self.scene = u, u.scene
        self.robot = self.scene[robot]
        self.map: BodyMap = bodymap(body_map)
        names = list(self.robot.body_names)
        self.pelvis = names.index(self.map.pelvis)
        self.lfoot, self.rfoot = names.index(self.map.left_foot[0]), names.index(self.map.right_foot[0])
        self.foot_sensors = {"L": self._scene_sensors("left", len(self.map.left_foot)),
                             "R": self._scene_sensors("right", len(self.map.right_foot))}
        if all(self.foot_sensors.values()):
            self.grf_source = "foot contact sensors filtered to the ground: normal and friction forces"
        else:
            self.foot_sensors = None
            self.sensor = self.scene[contact_sensor]
            snames = list(self.sensor.body_names)
            self.sfeet = {"L": [snames.index(n) for n in self.map.left_foot], "R": [snames.index(n) for n in self.map.right_foot]}
            self.grf_source = f"{contact_sensor}.net_forces_w: normal forces only (no friction)"
            warnings.warn(f"ground reaction forces from {contact_sensor}.net_forces_w, which holds the normal contact "
                          "forces only: the horizontal (braking, propulsive) forces are missing. Call "
                          "humanlike.rl.isaaclab.add_foot_contact_sensors(env_cfg, body_map) before making the "
                          "environment to record normal and friction forces", stacklevel=2)
        joints = list(self.robot.joint_names)
        if self.map.sagittal:
            self.sag = np.array([joints.index(self.map.sagittal[k][0]) for k in ("hip", "knee", "ankle")])
            self.sag_sign = np.array([self.map.sagittal[k][1] for k in ("hip", "knee", "ankle")], float)
        if joint_torque not in ("auto", "applied", "physx"):
            raise ValueError("joint_torque must be 'auto', 'applied' or 'physx'")
        implicit = [n for n, a in (getattr(self.robot, "actuators", None) or {}).items()
                    if type(a).__name__ == "ImplicitActuator"]
        view = getattr(self.robot, "root_physx_view", None)
        can = view is not None and all(hasattr(view, m) for m in
                                       ("get_dof_projected_joint_forces", "get_dof_armatures", "get_dof_limits"))
        self.physx_torque = joint_torque == "physx" or (joint_torque == "auto" and bool(implicit))
        if joint_torque == "physx" and not can:
            raise RuntimeError("joint_torque='physx' needs the PhysX articulation view (get_dof_projected_joint_forces)")
        if self.physx_torque and can:
            self.view = view
            self.armature = _np(view.get_dof_armatures())                  # [N, J]
            self.limits = _np(view.get_dof_limits())                       # [N, J, 2]
            self.qd_prev = None
            self.torque_source = ("PhysX drive torque: projected joint force + armature x joint acceleration "
                                  "(applied_torque within 0.01 rad of a joint limit)")
        else:
            self.physx_torque = False
            self.torque_source = "applied_torque"
            if implicit:
                self.torque_source = "applied_torque (implicit actuators: PD law estimate)"
                warnings.warn(f"actuator groups {implicit} are implicit (PhysX PD) and the PhysX articulation view is "
                              "not available: their joint torques are Isaac Lab's estimate of the PD law, off by ~5 % "
                              "in summed power on H1 (scripts/check_isaaclab_torques.py)", stacklevel=2)
        self.seg = [names.index(self.map.segments[k]) for k in ("pelvis", "thigh", "shank", "foot")] \
            if self.map.sagittal and self.map.segments else None
        self.mass_b = _np(self.robot.data.default_mass)[0]                  # [bodies]
        self.mass = float(self.mass_b.sum())
        self.dt = float(u.sim.get_physics_dt())
        self.fell_height = fell_height
        self.n = int(u.num_envs)
        self.seg_stride = max(1, round(1.0 / (50.0 * self.dt)))
        self.rows = [[] for _ in range(self.n)]
        self.limit_hits = [0] * self.n                                   # joint samples at a limit (PhysX torque)
        self.segrows = [[] for _ in range(self.n)]
        self.meta = [{} for _ in range(self.n)]
        from .storage import Storage
        self.storage = Storage(dtype, keep_transient, spill_dir)       # memory options: humanlike.rl.storage
        self.episodes: list[dict] = []
        orig = self.scene.update

        def update(*args, **kw):
            out = orig(*args, **kw)
            self._sample()
            return out
        self.scene.update = update

    def _sample(self):
        d = self.robot.data
        P = _np(d.body_pos_w)                                               # [N, B, 3]
        grf = self._grf()
        com = _np(getattr(d, "body_com_pos_w", d.body_pos_w))
        comv = _np(getattr(d, "body_com_lin_vel_w", d.body_lin_vel_w))
        w = self.mass_b / self.mass
        tau, qd, q = _np(d.applied_torque), _np(d.joint_vel), _np(d.joint_pos)
        at_limit = None
        if self.physx_torque:
            qdd = np.zeros_like(qd) if self.qd_prev is None else (qd - self.qd_prev) / self.dt
            self.qd_prev = qd
            drive = _np(self.view.get_dof_projected_joint_forces()) + self.armature * qdd
            at_limit = np.minimum(q - self.limits[..., 0], self.limits[..., 1] - q) < 0.01
            tau = np.where(at_limit, tau, drive)
        s = {"pelvis_pos": P[:, self.pelvis], "left_foot_pos": P[:, self.lfoot], "right_foot_pos": P[:, self.rfoot],
             "left_grf": grf["L"], "right_grf": grf["R"],
             "com_pos": np.einsum("nbi,b->ni", com, w), "com_vel": np.einsum("nbi,b->ni", comv, w),
             "joint_torque": tau, "joint_vel": qd}
        if self.map.sagittal:
            s.update(sagittal_angles=np.degrees(q[:, self.sag]) * self.sag_sign, sagittal_moments=tau[:, self.sag] * self.sag_sign,
                     sagittal_powers=tau[:, self.sag] * qd[:, self.sag])
        quat = _np(d.body_quat_w)[:, self.seg] if self.seg is not None else None     # [N, 4, (w, x, y, z)]
        for e in range(self.n):
            if quat is not None and len(self.rows[e]) % self.seg_stride == 0:
                self.segrows[e].append(quat[e])
            self.rows[e].append({k: v[e] for k, v in s.items()})
            if at_limit is not None:
                self.limit_hits[e] += int(at_limit[e].sum())

    def _scene_sensors(self, side, n):
        keys = [f"humanlike_{side}_foot{i}" for i in range(n)]
        try:
            return [self.scene[k] for k in keys]
        except KeyError:
            return []

    def _grf(self) -> dict:
        """Floor-on-foot force per foot [N, 3]."""
        if self.foot_sensors is None:
            F = _np(self.sensor.data.net_forces_w)                          # [N, S, 3]
            return {k: F[:, ids].sum(1) for k, ids in self.sfeet.items()}
        out = {}
        for side, sensors in self.foot_sensors.items():
            f = np.zeros((self.n, 3))
            for s in sensors:
                normal = np.nan_to_num(_np(s.data.force_matrix_w))           # [N, 1, M, 3] with the ground
                f += normal.sum(axis=(1, 2))
                f += self._friction(s)
            out[side] = f
        return out

    def _friction(self, s) -> np.ndarray:
        fr = getattr(s.data, "friction_forces_w", None)
        if fr is not None:                                                  # Isaac Lab with track_friction_forces
            return np.nan_to_num(_np(fr)).sum(axis=(1, 2))
        forces, _, count, start = s.contact_physx_view.get_friction_data(dt=self.dt)
        forces, count, start = _np(forces), _np(count).astype(int), _np(start).astype(int)   # count [N*B, M]
        c, st = count.reshape(-1), start.reshape(-1)          # contact points of each (env, body, filter)
        row = np.repeat(np.arange(len(c)), c)
        idx = st[row] + np.arange(len(row)) - np.repeat(np.cumsum(c) - c, c)
        out = np.zeros((len(c), 3))
        np.add.at(out, row, forces[idx])
        return out.reshape(self.n, -1, 3).sum(1)

    def check(self, episode: int = -1, strict: bool = False):
        """Plausibility checks of a recorded episode after its start-up transient (its skip_s; humanlike.rl.checks);
        strict raises on a failure."""
        from .checks import after_transient, check_episode
        if not self.episodes:
            raise RuntimeError("no finished episode to check")
        ep = self.episodes[episode]
        arrays, dg = after_transient(ep["arrays"], ep.get("diagnostics"), 1.0 / self.dt, float(ep["meta"].get("skip_s") or 0.0))
        if len(arrays["pelvis_pos"]) < 1.0 / self.dt:             # less than 1 s after the transient: the whole episode
            arrays, dg = ep["arrays"], ep.get("diagnostics")
        rep = check_episode(arrays, 1.0 / self.dt, self.mass, self.map.leg_length_m, dg, fell=bool(ep["meta"]["fell"]))
        if strict:
            rep.raise_if_failed()
        return rep

    def set_metadata(self, env_ids, **meta):
        """Metadata of the current episodes of these environments (group, commanded_speed, skip_s, id)."""
        for e in np.atleast_1d(env_ids):
            self.meta[int(e)].update(meta)

    def after_step(self, terminated, truncated):
        """End the episodes of the environments that terminated or were truncated in this env step."""
        term, trunc = _np(terminated).astype(bool).ravel(), _np(truncated).astype(bool).ravel()
        for e in np.flatnonzero(term | trunc):
            self.end_episode(int(e), fell=bool(term[e]))

    def end_episode(self, e: int, fell: bool = False):
        rows = self.rows[e]
        if rows:
            arrays = {k: np.stack([r[k] for r in rows]) for k in rows[0]}
            if self.fell_height is not None:
                fell = fell or bool(arrays["pelvis_pos"][:, 2].min() < self.fell_height)
            dg = {}
            if self.physx_torque:
                dg["joint_limit_share"] = self.limit_hits[e] / max(arrays["joint_vel"].size, 1)
            if self.segrows[e]:
                from scipy.spatial.transform import Rotation as Rot
                q = np.asarray(self.segrows[e])                                     # [n, 4, 4] wxyz
                R = Rot.from_quat(q[..., [1, 2, 3, 0]].reshape(-1, 4)).as_matrix().reshape(len(q), 4, 3, 3)
                dg = {"segment_rot": R, "segment_stride": self.seg_stride}
            arrays, meta, dg = self.storage.finish(arrays, {**self.meta[e], "fell": fell, "env": e}, dg, 1.0 / self.dt)
            self.episodes.append({"arrays": arrays, "meta": meta, "diagnostics": dg})
        self.rows[e] = []
        self.segrows[e] = []
        self.limit_hits[e] = 0

    def memory_bytes(self) -> int:
        """Bytes held in memory by the finished episodes' arrays (spilled ones count 0)."""
        from .storage import nbytes
        return nbytes(self.episodes)

    def close(self):
        for e in range(self.n):
            self.end_episode(e)

    def dataset(self, name: str, skip_s: float = 0.0, **meta):
        from ..adapters import from_arrays
        rollouts = []
        for i, ep in enumerate(self.episodes):
            em = ep["meta"]
            rollouts.append({"id": str(em.get("id", f"env{em['env']:03d}_ep{i:04d}")), "group": str(em.get("group", em["env"])),
                             "fs": 1.0 / self.dt, "skip_s": float(em.get("skip_s", skip_s)), "fell": bool(em["fell"]),
                             **({"commanded_speed": float(em["commanded_speed"])} if "commanded_speed" in em else {}),
                             **({"transient_dropped_s": float(em["transient_dropped_s"])} if "transient_dropped_s" in em else {}),
                             "arrays": ep["arrays"]})
        meta.setdefault("simulator", "Isaac Lab")
        ds = from_arrays(name, rollouts, mass_kg=self.mass, leg_length_m=self.map.leg_length_m,
                         sagittal_side=self.map.side if self.map.sagittal else None, up="z", **meta)
        ds.meta["dataset"]["joint_torque_source"] = self.torque_source
        ds.meta["dataset"]["grf_source"] = self.grf_source
        return ds
