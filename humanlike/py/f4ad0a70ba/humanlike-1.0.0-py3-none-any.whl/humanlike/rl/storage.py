"""How the recorders keep finished episodes: memory is the limit of a full protocol at the physics rate.

A rollout of locomotion-speed-v1 is 20 s; at 500 Hz with joint torques and velocities of a 23-joint
humanoid that is ~7 MB in float64, and the protocol's 400 rollouts ~3 GB. Three options of both recorders
(HumanlikeRecorder, IsaacLabRecorder) reduce it, applied when an episode ends:

    dtype="float32"         half the memory; the analyses need no more than float32's 7 digits
    keep_transient=False    drop the start-up transient (the episode's skip_s, e.g. the protocol's first
                            10 s) instead of keeping it to be skipped later: half again for the protocol
    spill_dir=PATH          write each episode's arrays to PATH/<n>/<name>.npy and keep memory-mapped views,
                            so the recorded data live on disk; the analyses read them as arrays

The plausibility check of an episode (check()) runs on what is kept.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np


class Storage:
    def __init__(self, dtype=None, keep_transient: bool = True, spill_dir=None):
        self.dtype = None if dtype is None else np.dtype(dtype)
        if self.dtype is not None and self.dtype.kind != "f":
            raise ValueError("dtype must be a floating type (float32 or float64)")
        self.keep_transient = keep_transient
        self.spill_dir = None if spill_dir is None else Path(spill_dir).expanduser()
        self.count = 0

    def finish(self, arrays: dict, meta: dict, diagnostics: dict, fs: float) -> tuple[dict, dict, dict]:
        """(arrays, meta, diagnostics) of a finished episode as they are kept."""
        meta, diagnostics = dict(meta), dict(diagnostics or {})
        skip = float(meta.get("skip_s") or 0.0)
        if not self.keep_transient and skip > 0:
            from .checks import after_transient
            n = len(arrays["pelvis_pos"])
            cut = min(int(round(skip * fs)), n)
            arrays, diagnostics = after_transient(arrays, diagnostics, fs, skip)
            meta["skip_s"], meta["transient_dropped_s"] = 0.0, cut / fs
        if self.dtype is not None:
            arrays = {k: (v.astype(self.dtype) if np.asarray(v).dtype.kind == "f" else v) for k, v in arrays.items()}
        if self.spill_dir is not None:
            d = self.spill_dir / f"{self.count:05d}"
            d.mkdir(parents=True, exist_ok=True)
            out = {}
            for k, v in arrays.items():
                np.save(d / f"{k}.npy", np.ascontiguousarray(v))
                out[k] = np.load(d / f"{k}.npy", mmap_mode="r")
            arrays = out
        self.count += 1
        return arrays, meta, diagnostics


def nbytes(episodes) -> int:
    """Bytes the episodes' arrays hold in memory (memory-mapped arrays count 0)."""
    return int(sum(0 if isinstance(v, np.memmap) else np.asarray(v).nbytes
                   for ep in episodes for v in ep["arrays"].values()))
