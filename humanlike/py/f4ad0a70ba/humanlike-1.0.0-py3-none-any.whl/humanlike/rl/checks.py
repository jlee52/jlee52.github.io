"""Plausibility checks of a recorded episode: catch a wrong body map, floor or capture before a whole
protocol is run on it (HumanlikeRecorder.check, IsaacLabRecorder.check).

    sample rate          >= 100 Hz (the strike detection and the stride phases need it)
    vertical GRF         the floor pushes the feet up: Fz >= -2 % of body weight
    impulse balance      mean Fz on the robot from the floor = m (g + (vz_end - vz_start) / T) within 10 %
                         (Newton's second law on the centre of mass; walking or standing); a shortfall
                         means floor contacts are missed (floor geoms, contact sensor)
    horizontal GRF       when the pelvis travels (>= 0.3 m/s): the largest horizontal floor force is >= 3 % of
                         body weight (braking and propulsion; human walking ~15-25 %), and the mean
                         horizontal force matches m dv/T within 2 % of body weight; normal forces only
                         (no friction) fail the first
    force vs COM accel.  at every sample the floor force equals m (a_COM + g) per axis (Newton's second law;
                         5-sample smoothing): slope 0.9-1.1 and r >= 0.8 for each axis that varies by
                         >= 2 % of body weight; a wrong force scale (e.g. impulses for forces) or missed
                         contacts fail. Isaac Lab H1: slope 0.98-1.00, r 0.93-0.99
    unlisted contacts    the feet touch nothing outside the robot that is not the floor
    non-foot contacts    bodies other than the feet carry < 5 % of the vertical floor force (a foot body
                         missing from the body map, or knees and hands on the floor); skipped after a fall
    joint limits         (Isaac Lab, PhysX drive torque) < 5 % of the joint samples at a limit, where the passive
                         limit force would enter the transmitted force and the PD estimate is used instead
    feet below pelvis    median pelvis height above the feet > 0.3 leg lengths (z up)
    level ground         the analyses assume level ground: over >= 1 m of travel, the pelvis height's linear
                         trend against the distance travelled is below 2 % (a slope of ~1 degree)
    joint axes           (MuJoCo) each sagittal joint turns about the mediolateral axis and its sign
                         agrees with the direction of the turn: hip flexion and ankle dorsiflexion turn
                         about -L, knee flexion about +L, L = z x forward (the leftward axis); |axis . L|
                         < 0.5 means the joint is not the sagittal one (abduction, rotation)
    segment rotation     the recorded angle follows the rotation of the distal segment relative to the
                         proximal one (pelvis-thigh, thigh-shank, shank-foot) about the same axes:
                         correlation r >= 0.5 and slope 0.3-3 (r <= -0.5: flipped sign; |r| < 0.5: not
                         the sagittal joint or not these segments; slope ~57 or ~0.017: radians vs
                         degrees). BFM-TS: r = 0.99, 0.98, 0.76, slope 0.8-0.9. Needs >= 5 deg of motion
    knee sign, hip sign  only without segment orientations: median knee angle >= -5 deg, median hip
                         angle >= -15 deg (gross errors only; the ankle cannot be checked this way)
Forward is the direction the feet point (MuJoCo: mean of both feet, from the ankle to the foot's centre
of mass, at the first sample), else the direction the pelvis travelled in the episode (>= 0.3 m).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

G = 9.81
JOINTS = ("hip", "knee", "ankle")
TURN = np.array([-1.0, 1.0, -1.0])           # flexion / dorsiflexion turns about TURN * L


@dataclass
class CheckReport:
    rows: list = field(default_factory=list)       # (name, status "ok" | "fail" | "skip", message)

    @property
    def ok(self) -> bool:
        return all(s != "fail" for _, s, _ in self.rows)

    def failures(self) -> list:
        return [r for r in self.rows if r[1] == "fail"]

    def __str__(self) -> str:
        w = max(len(n) for n, _, _ in self.rows)
        return "\n".join(f"{n:<{w}}  {s:<4}  {m}" for n, s, m in self.rows)

    def raise_if_failed(self):
        if not self.ok:
            raise RuntimeError("recording check failed:\n" + str(self) + "\n(see humanlike.rl.checks; "
                               "check=False skips the check)")


def check_episode(arrays: dict, fs: float, mass_kg: float, leg_length_m: float | None = None,
                  diagnostics: dict | None = None, fell: bool = False) -> CheckReport:
    r = CheckReport()
    add = lambda *row: r.rows.append(row)  # noqa: E731
    n = len(arrays["pelvis_pos"])
    T = n / fs
    add("sample rate", "ok" if fs >= 100 else "fail", f"{fs:.0f} Hz" + ("" if fs >= 100 else
        " (below 100 Hz: the physics steps were not captured; see the recorder's docs)"))
    W = mass_kg * G
    Fz = arrays["left_grf"][:, 2] + arrays["right_grf"][:, 2]
    lo = float(min(arrays["left_grf"][:, 2].min(), arrays["right_grf"][:, 2].min()))
    add("vertical GRF", "ok" if lo >= -0.02 * W else "fail", f"min {lo:.0f} N (body weight {W:.0f} N)" +
        ("" if lo >= -0.02 * W else ": negative, the force is the foot on the floor or z is not up"))
    dg = diagnostics or {}
    other = dg.get("non_foot_fz", 0.0) / max(n, 1)                 # mean non-foot Fz (MuJoCo only)
    if fell:
        add("impulse balance", "skip", "fall")
    elif T < 1.0 or "com_vel" not in arrays:
        add("impulse balance", "skip", "episode shorter than 1 s or no centre of mass")
    else:
        v = arrays["com_vel"][:, 2]
        want = mass_kg * (G + (v[-1] - v[0]) / T)
        got = float(Fz.mean()) + other
        good = abs(got - want) <= 0.1 * want
        add("impulse balance", "ok" if good else "fail", f"mean floor Fz {got:.0f} N, expected {want:.0f} N" +
            ("" if good else ": floor contacts are missing (floor geoms, foot bodies or contact sensor)"))
    speed = float(np.linalg.norm((arrays["pelvis_pos"][-1] - arrays["pelvis_pos"][0])[:2])) / T if T > 0 else 0.0
    if fell:
        add("horizontal GRF", "skip", "fall")
    elif speed < 0.3:
        add("horizontal GRF", "skip", f"the pelvis travels {speed:.2f} m/s")
    else:
        H = arrays["left_grf"][:, :2] + arrays["right_grf"][:, :2]
        peak = float(max(np.linalg.norm(arrays["left_grf"][:, :2], axis=1).max(),
                         np.linalg.norm(arrays["right_grf"][:, :2], axis=1).max()))
        msg = f"peak {100 * peak / W:.1f} % of body weight"
        good = peak >= 0.03 * W
        if not good:
            msg += ": no horizontal forces, friction is not recorded (Isaac Lab: add_foot_contact_sensors)"
        elif "com_vel" in arrays:
            dv = arrays["com_vel"][-1, :2] - arrays["com_vel"][0, :2]
            err = float(np.linalg.norm(H.mean(0) - mass_kg * dv / T))
            msg += f", mean force vs m dv/T {100 * err / W:.1f} % of body weight"
            if err > 0.02 * W:
                good = False
                msg += ": horizontal floor forces are missing"
        add("horizontal GRF", "ok" if good else "fail", msg)
    share = other / max(float(Fz.mean()) + other, 1e-9)
    if fell:
        add("force vs COM accel.", "skip", "fall")
    elif "com_vel" not in arrays or n < 20:
        add("force vs COM accel.", "skip", "no centre of mass velocity" if n >= 20 else "too short")
    elif share >= 0.05:
        add("force vs COM accel.", "skip", "other bodies carry part of the floor force")
    else:
        _newton(add, arrays, fs, mass_kg)
    if "unlisted_foot_contact" in dg:
        k = dg["unlisted_foot_contact"]
        names = ", ".join(sorted(dg.get("unlisted_geoms", ())))
        add("unlisted contacts", "ok" if k == 0 else "fail", "none" if k == 0 else
            f"the feet touch {names} in {k} samples (max {dg['unlisted_foot_force_max']:.0f} N); "
            "add them to the body map's floor, or floor=\"world\"")
    if "non_foot_fz" in dg:
        bodies = ", ".join(sorted(b for b in dg.get("non_foot_bodies", ()) if b))
        if fell:
            add("non-foot contacts", "skip", "fall")
        else:
            add("non-foot contacts", "ok" if share < 0.05 else "fail", f"{100 * share:.1f} % of the vertical floor force"
                + (f" ({bodies})" if bodies else "") + ("" if share < 0.05 else
                   ": add these bodies to the feet in the body map if they are foot segments"))
    if "joint_limit_share" in dg:                                  # Isaac Lab PhysX drive torque
        sh = dg["joint_limit_share"]
        add("joint limits", "ok" if sh < 0.05 else "fail", f"{100 * sh:.1f} % of joint samples at a limit" +
            ("" if sh < 0.05 else ": the drive torque there is the PD estimate (applied_torque); joint limits that the "
             "gait keeps hitting make the energetics approximate"))
    P = arrays["pelvis_pos"]
    dist = np.r_[0.0, np.cumsum(np.linalg.norm(np.diff(P[:, :2], axis=0), axis=1))]
    if fell or dist[-1] < 1.0:
        add("level ground", "skip", "fall" if fell else f"the pelvis travels {dist[-1]:.2f} m")
    else:
        grade = float(np.polyfit(dist, P[:, 2], 1)[0])
        add("level ground", "ok" if abs(grade) < 0.02 else "fail", f"pelvis height trend {100 * grade:+.1f} % of the distance"
            + ("" if abs(grade) < 0.02 else ": the ground slopes; the analyses (and the human references) assume level "
               "ground, so slopes, stairs and uneven terrain are outside the protocols"))
    h = float(np.median(arrays["pelvis_pos"][:, 2] - np.minimum(arrays["left_foot_pos"][:, 2], arrays["right_foot_pos"][:, 2])))
    need = 0.3 * (leg_length_m or 0.9)
    add("feet below pelvis", "ok" if h > need else "fail", f"median pelvis height above the feet {h:.2f} m" +
        ("" if h > need else ": wrong pelvis or foot bodies, or z is not up"))
    if "sagittal_angles" in arrays:
        L = _leftward(arrays, dg.get("forward_hint"))
        rot = dg.get("segment_rot")
        if dg.get("sagittal_axis_sum") is not None and dg.get("sagittal_signs") is not None and L is not None:
            _axes(add, dg["sagittal_axis_sum"], dg["sagittal_signs"], L)
        if rot is not None and len(rot) and L is not None:
            _segments(add, np.asarray(rot), arrays["sagittal_angles"][::dg.get("segment_stride", 1)][:len(rot)], L)
            return r
        if rot is not None and len(rot):
            add("segment rotation", "skip", "no forward direction (the pelvis did not travel and the feet give none)")
        hip, knee = np.median(arrays["sagittal_angles"][:, 0]), np.median(arrays["sagittal_angles"][:, 1])
        add("knee sign", "ok" if knee >= -5 else "fail", f"median knee angle {knee:.1f} deg" +
            ("" if knee >= -5 else ": flexion is negative, flip the knee sign in the body map"))
        add("hip sign", "ok" if hip >= -15 else "fail", f"median hip angle {hip:.1f} deg" +
            ("" if hip >= -15 else ": flexion is negative, flip the hip sign in the body map"))
    return r


def after_transient(arrays: dict, diagnostics: dict | None, fs: float, skip_s: float) -> tuple[dict, dict]:
    """The arrays and diagnostics of an episode without its first skip_s seconds (the start-up transient,
    in which a policy may stand, turn or fall into its gait): the samples, the segment orientations,
    joint axes and foot directions sampled every segment_stride samples, the joint-axis sum and the
    forward direction (where the feet point at the first kept sample), and the non-foot force (summed
    over samples; its mean is kept)."""
    dg = dict(diagnostics or {})
    n = len(arrays["pelvis_pos"])
    cut = min(int(round(max(skip_s, 0.0) * fs)), n)
    if cut == 0:
        return arrays, dg
    arrays = {k: v[cut:] for k, v in arrays.items()}
    k = -(-cut // max(int(dg.get("segment_stride", 1)), 1))
    for key in ("segment_rot", "sagittal_axes", "foot_dirs"):
        if key in dg and dg[key] is not None:
            dg[key] = dg[key][k:]
    if dg.get("sagittal_axes") is not None and len(dg["sagittal_axes"]):
        dg["sagittal_axis_sum"] = np.sum(dg["sagittal_axes"], axis=0)
    if dg.get("foot_dirs") is not None and len(dg["foot_dirs"]):
        dg["forward_hint"] = dg["foot_dirs"][0]
    if "non_foot_fz" in dg and n:
        dg["non_foot_fz"] = dg["non_foot_fz"] * (n - cut) / n
    return arrays, dg


def _leftward(arrays, hint):
    """L = z x forward: forward is where the feet point (MuJoCo), else where the pelvis travelled."""
    v = arrays["pelvis_pos"][-1] - arrays["pelvis_pos"][0]
    v = np.array([v[0], v[1], 0.0])
    if hint is not None:
        f = np.asarray(hint, float)
    elif np.linalg.norm(v) >= 0.3:
        f = v / np.linalg.norm(v)
    else:
        return None
    return np.cross([0.0, 0.0, 1.0], f)


def _axes(add, axis_sum, signs, L):
    a = axis_sum / np.linalg.norm(axis_sum, axis=1, keepdims=True)
    msgs, bad = [], False
    for i, k in enumerate(JOINTS):
        c = float(a[i] @ L)
        if abs(c) < 0.5:
            bad = True
            msgs.append(f"{k} axis . L {c:+.2f}: not the sagittal joint")
            continue
        want = int(np.sign(c * TURN[i]))
        if want != int(np.sign(signs[i])):
            bad = True
            msgs.append(f"{k}: sign {int(np.sign(signs[i])):+d} in the body map, {want:+d} by its axis")
        else:
            msgs.append(f"{k} {want:+d}")
    add("joint axes", "fail" if bad else "ok", "; ".join(msgs))


def _segments(add, R, ang, L):
    """R [n, 4, 3, 3]: pelvis, thigh, shank, foot orientations (world); ang [n, 3] recorded angles (deg)."""
    from scipy.spatial.transform import Rotation as Rot
    msgs, st = [], []
    for i, k in enumerate(JOINTS):
        rel = R[:, i + 1] @ np.transpose(R[:, i], (0, 2, 1))   # distal relative to proximal, world frame
        g = np.degrees(Rot.from_matrix(rel).as_rotvec() @ (TURN[i] * L))
        a = ang[:, i]
        if np.ptp(a) < 5 or np.ptp(g) < 5:
            msgs.append(f"{k}: too little motion")
            st.append("skip")
            continue
        rr = float(np.corrcoef(g, a)[0, 1])
        slope = float(np.polyfit(g, a, 1)[0])
        if rr <= -0.5:
            msgs.append(f"{k}: r {rr:+.2f}, the sign is flipped")
        elif rr < 0.5:
            msgs.append(f"{k}: r {rr:+.2f}, not the sagittal joint of these segments")
        elif not 0.3 <= slope <= 3:
            msgs.append(f"{k}: slope {slope:.3g} (radians vs degrees?)")
        else:
            msgs.append(f"{k} r {rr:+.2f}")
            st.append("ok")
            continue
        st.append("fail")
    add("segment rotation", "fail" if "fail" in st else "ok" if "ok" in st else "skip", "; ".join(msgs))


def _newton(add, arrays, fs, mass_kg):
    F = arrays["left_grf"] + arrays["right_grf"]
    need = mass_kg * (np.gradient(arrays["com_vel"], 1.0 / fs, axis=0) + [0.0, 0.0, G])
    k = np.ones(5) / 5
    W = mass_kg * G
    msgs, st = [], []
    for ax, name in enumerate("xyz"):
        f, q = np.convolve(F[:, ax], k, "valid"), np.convolve(need[:, ax], k, "valid")
        if q.std() < 0.02 * W:
            msgs.append(f"{name}: little variation")
            continue
        slope = float(np.polyfit(q, f, 1)[0])
        r = float(np.corrcoef(q, f)[0, 1]) if f.std() > 1e-9 else 0.0
        good = 0.9 <= slope <= 1.1 and r >= 0.8
        st.append(good)
        msgs.append(f"{name} slope {slope:.2f} r {r:.2f}")
    if not st:
        add("force vs COM accel.", "skip", "; ".join(msgs))
    else:
        add("force vs COM accel.", "ok" if all(st) else "fail", "; ".join(msgs) + ("" if all(st) else
            ": the floor forces do not account for the centre-of-mass acceleration (force scale, missed contacts)"))
