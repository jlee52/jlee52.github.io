"""Where the profile's signals live in a simulated body: the pelvis, the feet (bodies whose floor
contacts make up each foot's ground reaction force; the first one also gives the foot position), the
sagittal hip, knee and ankle joints of one leg with their signs (+ = flexion / dorsiflexion), and the
floor: a MuJoCo geom name, several names (terrain made of several geoms), or "world" (every geom that
is not part of the robot). `segments` names the pelvis, thigh, shank and foot bodies of the sagittal leg,
whose orientations cross-check the sagittal joints (humanlike.rl.checks); MuJoCo finds them from the
joints (the body of each joint, and the parent of the thigh), Isaac Lab needs them.

Presets for the models of the manuscript:
    humenv-smpl   SMPL humanoid of humenv (the behavior foundation models), left leg
    myoleg        MyoLeg of KINESIS (MuJoCo, muscle-actuated), right leg
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class BodyMap:
    pelvis: str
    left_foot: tuple                       # body names; the first gives the foot position
    right_foot: tuple
    sagittal: dict = field(default_factory=dict)   # {"hip" | "knee" | "ankle": (joint name, sign)}
    side: str = "left"                     # leg of the sagittal joints
    floor: str | tuple = "floor"           # MuJoCo floor geom(s), or "world"
    leg_length_m: float | None = None
    segments: dict = field(default_factory=dict)   # {"pelvis" | "thigh" | "shank" | "foot": body name}

    def __post_init__(self):
        if self.sagittal and set(self.sagittal) != {"hip", "knee", "ankle"}:
            raise ValueError("sagittal needs the hip, knee and ankle joints (or none)")
        if self.segments and set(self.segments) != {"pelvis", "thigh", "shank", "foot"}:
            raise ValueError("segments needs the pelvis, thigh, shank and foot bodies (or none)")
        if self.side not in ("left", "right"):
            raise ValueError("side must be 'left' or 'right'")


PRESETS = {
    # pipeline.yaml conventional.sagittal.joints.smpl; feet as the manuscript's GRF (scripts/reconstruct_bfm_grf.py)
    "humenv-smpl": BodyMap("Pelvis", ("L_Ankle", "L_Toe"), ("R_Ankle", "R_Toe"),
                           {"hip": ("L_Hip_x", -1), "knee": ("L_Knee_x", 1), "ankle": ("L_Ankle_x", -1)},
                           side="left", leg_length_m=0.854),
    # pipeline.yaml conventional.sagittal.joints.myoleg
    "myoleg": BodyMap("pelvis", ("calcn_l", "toes_l"), ("calcn_r", "toes_r"),
                      {"hip": ("hip_flexion_r", 1), "knee": ("knee_angle_r", 1), "ankle": ("ankle_angle_r", 1)},
                      side="right", leg_length_m=0.8763),
}


def bodymap(spec) -> BodyMap:
    """A BodyMap, a preset name, or a dict of BodyMap fields."""
    if isinstance(spec, BodyMap):
        return spec
    if isinstance(spec, str):
        if spec not in PRESETS:
            raise KeyError(f"unknown body map {spec!r}; presets: {', '.join(PRESETS)}")
        return PRESETS[spec]
    d = dict(spec)
    d["left_foot"], d["right_foot"] = tuple(d["left_foot"]), tuple(d["right_foot"])
    d["sagittal"] = {k: tuple(v) for k, v in d.get("sagittal", {}).items()}
    if isinstance(d.get("floor"), list):
        d["floor"] = tuple(d["floor"])
    return BodyMap(**d)
