"""Gymnasium wrapper that records the profile signals of every physics step of a MuJoCo environment.

    env = HumanlikeRecorder(make_env(), body_map="humenv-smpl")
    obs, info = env.reset(options={"humanlike": {"group": "speed_1.1", "commanded_speed": 1.1}})
    ...                                      # roll out; info["humanlike"] holds the step's samples, [k, ...]
    ds = env.dataset("MyPolicy")             # the finished episodes as a data set (humanlike.engine.evaluate)

With humanlike.adapters.minari_io.collector(env) the same infos are recorded as a Minari dataset;
finish(..., **env.profile_metadata()) adds the profile metadata.

Physics-rate capture: while the wrapped env steps, mujoco.mj_step is intercepted for this env's data and
run one physics step at a time, each followed by a sample (MujocoExtractor). This works for environments
that advance the simulation with mujoco.mj_step (Gymnasium's MujocoEnv, humenv, ...) and leaves the
trajectory unchanged. An environment that steps otherwise (mj_step imported by name, a compiled loop)
raises an error at the first step, since one sample per env step is too coarse for the ground reaction
forces and the strikes; allow_env_rate=True records at the env rate anyway. The number of
physics steps per env step (k) must be constant; it is taken from the environment's frame_skip (Gymnasium's
MujocoEnv) or `physics_steps`, else from the first env step (the reset entry of the first episode then has
one sample, which a Minari DataCollector rejects: pass physics_steps). Rollouts in which the pelvis drops below `fell_height`
(m), or that end by termination when `terminated_is_fall`, are marked as falls.

check() tests a recorded episode for a wrong body map, floor or capture (humanlike.rl.checks); run it
after the first episode, as evaluate_policy does.

Memory: dtype="float32", keep_transient=False and spill_dir= keep a full protocol small
(humanlike.rl.storage); memory_bytes() reports what the finished episodes hold.
"""
from __future__ import annotations

import numpy as np

try:
    import gymnasium as gym
    _Base = gym.Wrapper
except ImportError:                      # pragma: no cover
    gym, _Base = None, object

from .mujoco import MujocoExtractor
from .storage import Storage, nbytes


def _find(env, name):
    e = env
    while e is not None:
        if hasattr(e, name):
            return getattr(e, name)
        e = getattr(e, "env", None)
    return None


class HumanlikeRecorder(_Base):
    def __init__(self, env, body_map, model=None, data=None, info_key: str = "humanlike",
                 fell_height: float | None = 0.5, terminated_is_fall: bool = True, physics_steps: int | None = None,
                 allow_env_rate: bool = False, dtype=None, keep_transient: bool = True, spill_dir=None):
        super().__init__(env)
        u = env.unwrapped
        self.model = model if model is not None else _find(u, "model")
        self.data = data if data is not None else _find(u, "data")
        if self.model is None or self.data is None:
            raise ValueError("no MuJoCo model and data on the environment; pass model= and data=")
        self.x = MujocoExtractor(self.model, self.data, body_map)
        self.info_key, self.fell_height, self.terminated_is_fall = info_key, fell_height, terminated_is_fall
        self.allow_env_rate = allow_env_rate
        fs = physics_steps or _find(u, "frame_skip")
        self.physics_steps: int | None = int(fs) if fs else None
        self.k: int | None = self.physics_steps          # samples per env step
        self.sample_dt = self.x.dt                       # physics time step; env step at the env rate
        self.storage = Storage(dtype, keep_transient, spill_dir)
        self.episodes: list[dict] = []
        self._rows: list[dict] = []
        self._meta: dict = {}
        self._buf: list[dict] = []

    @staticmethod
    def _stack(samples):
        return {key: np.stack([s[key] for s in samples]) for key in samples[0]}

    def step(self, action):
        import mujoco
        orig, rec = mujoco.mj_step, self

        def mj_step(m, d, nstep=1):
            if d is not rec.data:
                return orig(m, d, nstep)
            for _ in range(int(nstep)):
                orig(m, d)
                rec._buf.append(rec.x.sample())

        self._buf = []
        mujoco.mj_step = mj_step
        try:
            obs, reward, terminated, truncated, info = self.env.step(action)
        finally:
            mujoco.mj_step = orig
        if not self._buf:                        # stepped without mujoco.mj_step: one sample per env step
            if not self.allow_env_rate:
                raise RuntimeError(
                    "the environment stepped without calling mujoco.mj_step, so the physics steps cannot be "
                    "recorded (it may import mj_step by name or step in compiled code). Make it call "
                    "mujoco.mj_step(model, data, nstep), or pass allow_env_rate=True to record one sample "
                    "per env step (too coarse for ground reaction forces and strikes below ~100 Hz)")
            if not self.physics_steps:
                raise RuntimeError("recording at the env rate needs physics_steps= (physics steps per env step)")
            if self.sample_dt == self.x.dt:
                self.k, self.sample_dt = None, self.x.dt * self.physics_steps
            self._buf.append(self.x.sample())
        if self.k is None:
            self.k = len(self._buf)
        elif len(self._buf) != self.k:
            raise RuntimeError(f"{len(self._buf)} physics steps in this env step and {self.k} expected; the number of "
                               "physics steps per env step must be constant (physics_steps= sets it)")
        chunk = self._stack(self._buf)
        self._rows.append(chunk)
        info = dict(info)
        info[self.info_key] = chunk
        if terminated or truncated:
            self.end_episode(fell=bool(terminated) and self.terminated_is_fall)
        return obs, reward, terminated, truncated, info

    def reset(self, *, seed=None, options=None):
        self.end_episode()
        options = dict(options or {})
        self._meta = dict(options.pop(self.info_key, None) or {})
        obs, info = self.env.reset(seed=seed, options=options or None)
        info = dict(info)
        info[self.info_key] = self._stack([self.x.sample()] * (self.k or 1))   # reset entry (not used by readers)
        self.x.reset_diagnostics()
        return obs, info

    def end_episode(self, fell: bool = False):
        """Store the steps since the last reset as an episode (also called by step at termination and
        truncation, and by reset); call it to end an episode at a fixed duration."""
        if not self._rows:
            return
        arrays = {key: np.concatenate([r[key] for r in self._rows]) for key in self._rows[0]}
        if self.fell_height is not None:
            fell = fell or bool(arrays["pelvis_pos"][:, 2].min() < self.fell_height)
        arrays, meta, dg = self.storage.finish(arrays, {**self._meta, "fell": fell}, self.x.diagnostics, self.fs)
        self.episodes.append({"arrays": arrays, "meta": meta, "diagnostics": dg})
        self._rows = []
        self.x.reset_diagnostics()

    @property
    def fs(self) -> float:
        return 1.0 / self.sample_dt

    def memory_bytes(self) -> int:
        """Bytes held in memory by the finished episodes' arrays (spilled ones count 0)."""
        return nbytes(self.episodes)

    def check(self, episode: int = -1, strict: bool = False):
        """Plausibility checks of a recorded episode after its start-up transient (its skip_s; humanlike.rl.checks);
        strict raises on a failure."""
        from .checks import after_transient, check_episode
        if not self.episodes:
            raise RuntimeError("no finished episode to check")
        ep = self.episodes[episode]
        arrays, dg = after_transient(ep["arrays"], ep.get("diagnostics"), self.fs, float(ep["meta"].get("skip_s") or 0.0))
        if len(arrays["pelvis_pos"]) < self.fs:             # less than 1 s after the transient: the whole episode
            arrays, dg = ep["arrays"], ep.get("diagnostics")
        rep = check_episode(arrays, self.fs, self.x.mass, self.x.map.leg_length_m, dg, fell=bool(ep["meta"].get("fell")))
        if strict:
            rep.raise_if_failed()
        return rep

    def profile_metadata(self) -> dict:
        """Keyword arguments of humanlike.adapters.minari_io.finish / annotate for the recorded data."""
        m = self.x.meta()
        return {"fs": self.fs, "samples_per_step": self.k or 1, "up": m["up"], "mass_kg": m["mass_kg"],
                "leg_length_m": m["leg_length_m"], "sagittal_side": m["sagittal_side"], "simulator": m["simulator"]}

    def episode_metadata(self) -> list[dict]:
        """Per-episode metadata for finish(..., episodes=...)."""
        return [{k: v for k, v in ep["meta"].items() if v is not None} for ep in self.episodes]

    def dataset(self, name: str, skip_s: float = 0.0, **meta):
        from ..adapters import from_arrays
        m = self.x.meta()
        rollouts = []
        for i, ep in enumerate(self.episodes):
            em = ep["meta"]
            rollouts.append({"id": str(em.get("id", f"ep{i:04d}")), "group": str(em.get("group", "0")), "fs": self.fs,
                             "skip_s": float(em.get("skip_s", skip_s)), "fell": bool(em["fell"]),
                             **({"commanded_speed": float(em["commanded_speed"])} if "commanded_speed" in em else {}),
                             **({"transient_dropped_s": float(em["transient_dropped_s"])} if "transient_dropped_s" in em else {}),
                             "arrays": ep["arrays"]})
        meta.setdefault("simulator", m["simulator"])
        return from_arrays(name, rollouts, mass_kg=m["mass_kg"], leg_length_m=m["leg_length_m"],
                           sagittal_side=m["sagittal_side"], up="z", **meta)
