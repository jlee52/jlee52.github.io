"""How much data each analysis needs (docs/oss/COVERAGE.md: subsampling of the manuscript's rollouts).

Two tiers per analysis:
    minimum      below it the value is biased or meaningless: the stage reports "not evaluable" with the
                 reason (evaluate(..., coverage="report") computes it anyway, flagged)
    recommended  below it the value is computed and flagged as low coverage: it moved by more than about
                 10 % (or one count) between subsamples of the manuscript's models

    analysis            minimum                              recommended                    why
    gait_scaling (JS)   3 speed levels in the reference range  6 levels                       the speed distribution enters the
                                                                                            joint (speed, stride) density
    feedback (FPGD,     median 100 strides per group           250 strides per group          FPGD grows with fewer strides
      peak dR^2)                                                                            (AMP: +28 % at ~50, +16 % at ~125)
    energetics (COT)    speeds from <= 1.0 to >= 3.0 m/s,      12 levels, 10 rollouts per     too few speeds give false PASS
                        8 levels                               level                          verdicts (AMP: 68 % with 4 speeds)
    sagittal            none (compared at matched speed)      4 levels and 20 rollouts       counts at |median z| = 2 flip
    kinetic_principles  none (the direction and shape          6 levels, 5 rollouts per level fewer predictions evaluated;
                        predictions need a 0.6 m/s span:                                      counts near the thresholds flip
                        n/a below it)
Speed-matched analyses (sagittal, principles, gait phases) are valid at a single speed and are only flagged;
the analyses of speed relations (JS, COT) and the fitted feedback signature are not evaluable below their
minimum.

A speed level is a commanded speed when every rollout has one (a protocol), else the measured speed to the
nearest 0.2 m/s. The commanded speeds decide the COT's range when given, so a model commanded to run that
cannot is evaluated (and fails) rather than excused.
"""
from __future__ import annotations

import numpy as np

REQUIREMENTS = {
    "gait_scaling": {"minimum": {"levels": 3}, "recommended": {"levels": 6}},
    "feedback": {"minimum": {"strides_per_group": 100}, "recommended": {"strides_per_group": 250}},
    "energetics": {"minimum": {"levels": 8, "span": (1.0, 3.0)},
                   "recommended": {"levels": 12, "rollouts_per_level": 10, "span": (1.0, 3.0)}},
    "sagittal": {"minimum": {}, "recommended": {"levels": 4, "rollouts": 20}},
    "kinetic_principles": {"minimum": {}, "recommended": {"levels": 6, "rollouts_per_level": 5}},
}
WHAT = {"levels": "speed levels", "rollouts": "rollouts", "rollouts_per_level": "rollouts per speed level (median)",
        "strides_per_group": "strides per group (median)", "span": "speeds"}


def speed_levels(rows) -> np.ndarray:
    """Level of each rollout: rows are dicts with "speed" (measured) and optionally "commanded_speed"."""
    cmd = [x.get("commanded_speed") for x in rows]
    if rows and all(c is not None for c in cmd):
        return np.round(np.asarray(cmd, float), 2)
    return np.round(np.asarray([x["speed"] for x in rows], float) / 0.2) * 0.2


def measure(rows=None, strides_per_group=None) -> dict:
    """What a data set provides: levels, rollouts, rollouts per level, the speed span (commanded if given)."""
    out = {}
    if rows is not None:
        lv = speed_levels(rows)
        u, n = np.unique(lv, return_counts=True)
        out.update(levels=len(u), rollouts=len(rows), rollouts_per_level=float(np.median(n)) if len(n) else 0.0)
        if len(rows):
            cmd = [x.get("commanded_speed") for x in rows]
            s = np.asarray(cmd if all(c is not None for c in cmd) else [x["speed"] for x in rows], float)
            out["span"] = (round(float(s.min()), 3), round(float(s.max()), 3))
    if strides_per_group is not None:
        out["strides_per_group"] = float(np.median(strides_per_group)) if len(strides_per_group) else 0.0
    return out


def _short(req: dict, have: dict) -> list[str]:
    miss = []
    for k, v in req.items():
        h = have.get(k)
        if k == "span":
            if h is None or h[0] > v[0] or h[1] < v[1]:
                got = "none" if h is None else f"{h[0]:.2f}-{h[1]:.2f} m/s"
                miss.append(f"speeds from <= {v[0]:g} to >= {v[1]:g} m/s needed, {got}")
        elif h is None or h < v:
            miss.append(f"{v:g} {WHAT[k]} needed, {0 if h is None else h:g}")
    return miss


def assess(analysis: str, have: dict) -> dict:
    """{"status": "ok" | "low" | "insufficient", "have", "missing"} against REQUIREMENTS[analysis]."""
    req = REQUIREMENTS[analysis]
    have = {k: v for k, v in have.items() if k in WHAT}
    lo, rec = _short(req["minimum"], have), _short(req["recommended"], have)
    status = "insufficient" if lo else "low" if rec else "ok"
    return {"status": status, "have": have, "missing": lo or rec}


def gate(analysis: str, have: dict, mode: str | None) -> tuple[dict, dict | None]:
    """(coverage entry, skip result or None): skip below the minimum unless mode == "report"."""
    c = assess(analysis, have)
    if c["status"] == "insufficient" and (mode or "enforce") != "report":
        return c, {"skipped": "not evaluable with these data: " + "; ".join(c["missing"]) +
                              " (docs/oss/COVERAGE.md; coverage='report' computes it anyway)", "coverage": c}
    return c, None
