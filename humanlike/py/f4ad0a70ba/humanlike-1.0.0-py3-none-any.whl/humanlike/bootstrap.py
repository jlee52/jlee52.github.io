"""Bootstrap confidence intervals of the summary values, by resampling the units the value is built from
(rollouts, or groups for the feedback signature) with replacement. evaluate(..., bootstrap=N) sets the
number of resamples (default 200; 0 leaves the intervals out); the seed is fixed, so results repeat.

The interval says how much the value would move with another draw of the same number of rollouts from
the same controller; it does not cover a biased design (too few speeds or strides: humanlike.coverage).
"""
from __future__ import annotations

import numpy as np

DEFAULT = 200
LEVEL = 95


def resamples(ctx) -> int:
    n = ctx.options.get("bootstrap")
    return DEFAULT if n is None else int(n)


def ci(stat, n_units: int, B: int, seed: int = 0, groups=None) -> list | None:
    """[lo, hi] (95 %) of stat(idx) over B resamples of unit indices 0..n_units-1; with groups (an array of
    one label per unit), units are resampled within each group so that every group keeps its size (the
    design's speeds stay fixed). None if B == 0 or there are fewer than 2 units."""
    if not B or n_units < 2:
        return None
    rng = np.random.default_rng(seed)
    if groups is None:
        draws = (rng.integers(0, n_units, n_units) for _ in range(B))
    else:
        g = np.asarray(groups)
        members = [np.flatnonzero(g == u) for u in np.unique(g)]
        draws = (np.concatenate([m[rng.integers(0, len(m), len(m))] for m in members]) for _ in range(B))
    vals = []
    for idx in draws:
        try:
            v = stat(idx)
        except (ValueError, RuntimeError, np.linalg.LinAlgError):
            v = np.nan
        vals.append(np.nan if v is None else v)
    vals = np.asarray(vals, float)
    if not np.isfinite(vals).sum():
        return None
    lo, hi = np.nanpercentile(vals, [(100 - LEVEL) / 2, 100 - (100 - LEVEL) / 2])
    return [float(lo), float(hi)]


def agreement(stat, value, n_units: int, B: int, seed: int = 0, groups=None) -> float | None:
    """Share of resamples whose (categorical) stat equals value, e.g. the COT verdict."""
    if not B or n_units < 2:
        return None
    rng = np.random.default_rng(seed)
    g = None if groups is None else np.asarray(groups)
    members = None if g is None else [np.flatnonzero(g == u) for u in np.unique(g)]
    same = 0
    for _ in range(B):
        idx = (rng.integers(0, n_units, n_units) if members is None
               else np.concatenate([m[rng.integers(0, len(m), len(m))] for m in members]))
        try:
            same += stat(idx) == value
        except (ValueError, RuntimeError, np.linalg.LinAlgError):
            pass
    return same / B
