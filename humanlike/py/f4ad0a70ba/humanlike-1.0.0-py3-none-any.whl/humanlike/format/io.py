"""Reading and writing HLB containers (zip of hlb.json + .npy arrays). Only numpy and the standard
library are used, so the same code runs in the browser (Pyodide)."""
from __future__ import annotations

import io
import json
import zipfile
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from .spec import FORMAT, VERSION


@dataclass
class Rollout:
    meta: dict
    arrays: dict = field(default_factory=dict)

    @property
    def id(self) -> str:
        return str(self.meta["id"])

    @property
    def fs(self) -> float:
        return float(self.meta["fs"])


@dataclass
class Dataset:
    meta: dict                        # dataset, subject, frame
    rollouts: list = field(default_factory=list)

    @property
    def name(self) -> str:
        return str(self.meta.get("dataset", {}).get("name", "unnamed"))

    @property
    def mass(self) -> float | None:
        m = self.meta.get("subject", {}).get("mass_kg")
        return None if m is None else float(m)

    @property
    def side(self) -> str:
        """Leg of the sagittal arrays and reference foot of the sagittal and kinetic analyses."""
        return str(self.meta.get("dataset", {}).get("sagittal_side", "left"))

    @property
    def leg_length(self) -> float | None:
        v = self.meta.get("subject", {}).get("leg_length_m")
        return None if v is None else float(v)

    @property
    def up(self) -> int:
        return "xyz".index(self.meta.get("frame", {}).get("up", "z"))


def write(path, ds: Dataset) -> Path:
    path = Path(path)
    meta = {"format": FORMAT, "version": VERSION, **ds.meta,
            "rollouts": [{**r.meta, "arrays": sorted(r.arrays)} for r in ds.rollouts]}
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("hlb.json", json.dumps(meta, indent=1, default=_json_default))
        for r in ds.rollouts:
            for name, arr in r.arrays.items():
                buf = io.BytesIO()
                np.save(buf, np.asarray(arr), allow_pickle=False)
                z.writestr(f"rollouts/{r.id}/{name}.npy", buf.getvalue())
    return path


def read(path_or_bytes) -> Dataset:
    src = io.BytesIO(path_or_bytes) if isinstance(path_or_bytes, (bytes, bytearray)) else path_or_bytes
    with zipfile.ZipFile(src) as z:
        meta = json.loads(z.read("hlb.json"))
        if meta.get("format") != FORMAT:
            raise ValueError(f"not an HLB file (format={meta.get('format')!r})")
        if str(meta.get("version", "")).split(".")[0] != VERSION.split(".")[0]:
            raise ValueError(f"HLB version {meta.get('version')} is not supported (reader {VERSION})")
        rollouts = []
        for rm in meta.pop("rollouts"):
            names = rm.pop("arrays", [])
            arrays = {n: np.load(io.BytesIO(z.read(f"rollouts/{rm['id']}/{n}.npy")), allow_pickle=False) for n in names}
            rollouts.append(Rollout(rm, arrays))
    meta.pop("format"), meta.pop("version")
    return Dataset(meta, rollouts)


def _json_default(x):
    if isinstance(x, np.generic):
        return x.item()
    raise TypeError(f"not JSON serialisable: {type(x)}")


def load(source) -> Dataset:
    """A data set from a Minari dataset with the humanlike profile (directory or registered id), or from
    the package's own container file (written by humanlike.format.write)."""
    p = Path(str(source))
    if p.is_file() and p.suffix != ".hlb" and not zipfile.is_zipfile(p):
        raise ValueError(f"{p}: not an HLB file or Minari dataset")
    if p.is_file():
        return read(p)
    from ..adapters.minari_io import read as read_minari
    return read_minari(source)

