"""Gait events: foot strikes from the ground reaction force when it is recorded, else from body positions.

Contact (strike_source "grf"): where a foot's vertical GRF is recorded over the whole rollout, its
strikes are the onsets of contact (humanlike.kinetics.foot_strikes: vertical GRF rising through 5 % of
body weight), the definition of initial contact (Perry & Burnfield 2010) and of the human reference's
gait cycles (Camargo et al. 2021 force plates). Body weight is m g, or, without the mass, the mean total
vertical GRF of the rollout (equal to m g over steady gait). The GRF is used when it gives at least
half as many strikes as the kinematic criterion (a force plate under a few steps of an overground trial
does not cover the rollout).

Kinematic foot strike (strike_source "kinematic"): a local maximum of the anteroposterior distance of the foot ahead of the pelvis
(the kinematic heel-strike criterion of Zeni et al., 2008, Gait & Posture 27:710-714), after a
4th-order zero-phase low-pass filter at 6 Hz. Peaks must exceed the mean and have a prominence of
at least 40 % of the largest peak after the first, as in the manuscript's analysis
(scripts/curate_mimickit_rollouts.py detect_hs). The walking direction is the first principal
component of the horizontal pelvis path.
"""
from __future__ import annotations

import numpy as np
from scipy.signal import butter, find_peaks, sosfiltfilt

CUTOFF_HZ = 6.0


def horizontal_axes(up: int) -> list[int]:
    return [i for i in range(3) if i != up]


def heading(pelvis: np.ndarray, up: int = 2) -> np.ndarray:
    """Unit vector (3D, horizontal) of the first principal component of the pelvis path, oriented
    in the direction of travel."""
    h = horizontal_axes(up)
    xy = np.asarray(pelvis, float)[:, h]
    xy = xy[np.isfinite(xy).all(1)]
    c = xy - xy.mean(0)
    _, _, vt = np.linalg.svd(c, full_matrices=False)
    d = vt[0]
    if np.dot(xy[-1] - xy[0], d) < 0:
        d = -d
    out = np.zeros(3)
    out[h] = d
    return out


def lowpass(x: np.ndarray, fs: float, cutoff: float = CUTOFF_HZ, order: int = 4) -> np.ndarray:
    if cutoff >= 0.5 * fs:
        return np.asarray(x, float)
    sos = butter(order, cutoff / (0.5 * fs), output="sos")
    return sosfiltfilt(sos, np.asarray(x, float), axis=0)


def foot_strikes(pelvis: np.ndarray, foot: np.ndarray, fs: float, up: int = 2, direction=None) -> np.ndarray:
    """Sample indices of the foot strikes of `foot` ([T, 3] positions; pelvis likewise)."""
    d = heading(pelvis, up) if direction is None else np.asarray(direction, float)
    src = lowpass(np.asarray(pelvis, float) @ d, fs)
    tgt = lowpass(np.asarray(foot, float) @ d, fs)
    diff = tgt - src
    diff = diff - diff.mean()
    pks, _ = find_peaks(diff, height=0, prominence=0.02)
    ref = (diff[pks[0] + 1:].max() if pks.size and pks[0] + 1 < len(diff) else diff.max())
    peaks, _ = find_peaks(diff, height=0, prominence=ref * 0.4)
    return np.sort(peaks)


def contact_strikes(grf, fs, up: int = 2, mass_kg=None) -> np.ndarray:
    """Foot strikes (sample indices) from a foot's GRF [T, 3] (N): onsets of contact."""
    from .kinetics import foot_strikes as grf_strikes, lowpass
    fz = np.asarray(grf, float)[:, up]
    return grf_strikes(lowpass(fz / _body_weight(fz, mass_kg), fs), fs)


def _body_weight(fz, mass_kg):
    return mass_kg * 9.81 if mass_kg else max(float(np.mean(fz)) * 2, 1e-9)   # one foot: half the weight on average


def strikes(arrays: dict, side: str, fs: float, up: int = 2, mass_kg=None, direction=None, source: str = "auto"):
    """Foot strikes of one foot and their source: "grf" (contact; preferred), "provided" (the data set's
    <side>_heel_strikes) or "kinematic" (Zeni et al. 2008). source forces one of them ("auto": the first
    available in that order; the GRF only if it covers the rollout)."""
    key = f"{side}_heel_strikes"
    kin = None
    if source in ("auto", "grf") and f"{side}_grf" in arrays:
        hs = contact_strikes(arrays[f"{side}_grf"], fs, up, mass_kg)
        if source == "grf":
            return hs, "grf"
        kin = foot_strikes(arrays["pelvis_pos"], arrays[f"{side}_foot_pos"], fs, up, direction)
        if len(hs) >= 2 and len(hs) >= 0.5 * len(kin):
            return hs, "grf"
    if source in ("auto", "provided") and key in arrays:
        return np.asarray(arrays[key], int), "provided"
    if kin is None:
        kin = foot_strikes(arrays["pelvis_pos"], arrays[f"{side}_foot_pos"], fs, up, direction)
    return kin, "kinematic"
