"""Manuscript figures for the human-likeness signatures.

Each function takes the result dict of run_pipeline.compute() plus the pipeline config and
returns a matplotlib Figure (or {suffix: Figure}). Statistics (significance brackets) come from the
same Games-Howell results that feed the tables.

Figures are drawn at their printed size: TEXT_WIDTH is the manuscript text width (arxiv.sty,
6.5 in), and the manuscript includes them at width=\textwidth, so the font sizes below (7-9 pt)
are the sizes on the page. Points take the color of their box or line.
"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.patheffects as pe  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import statsmodels.api as sm  # noqa: E402
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec  # noqa: E402
from scipy.stats import gaussian_kde  # noqa: E402

from .energetics import PARAMS, two_gaussian, zscore  # noqa: E402

TAB = plt.cm.tab10.colors
MODEL_COLORS = {"BFM-TA": TAB[0], "BFM-TS": TAB[1], "AMP": TAB[2], "SMP": TAB[3], "KINESIS": TAB[4]}
REF_LABELS = {"AMASS": "BFM-EXPERT", "AMP-EXPERT": "AMP/SMP-EXPERT", "KIT": "KINESIS-EXPERT",
              "OOD-HUMAN": "OOD Human"}

TEXT_WIDTH = 6.5   # in
HUMAN_COLOR = "0.35"
plt.rcParams.update({
    "pdf.fonttype": 42, "ps.fonttype": 42, "svg.hashsalt": "humanlike",
    "font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 9, "axes.labelsize": 8,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7, "figure.titlesize": 9,
    "axes.linewidth": .6, "xtick.major.width": .6, "ytick.major.width": .6,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5, "lines.linewidth": 1.2,
    "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
    "savefig.dpi": 600,   # rasterized point clouds inside the vector PDFs
})


def _stars(p):
    return "***" if p < 1e-3 else "**" if p < 1e-2 else "*" if p < .05 else ""


def _families(cfg):
    fam = {}
    for m in cfg["models"]:
        fam.setdefault(cfg["gait"][m]["reference"], []).append(m)
    return fam


def _sig_pairs(posthoc, labels, alpha=0.05):
    idx = {g: i for i, g in enumerate(labels)}
    pairs = [(min(idx[a], idx[b]), max(idx[a], idx[b]), p)
             for a, b, p in zip(posthoc.A, posthoc.B, posthoc.pval) if p < alpha]
    return sorted(pairs, key=lambda t: (t[1] - t[0], t[0]))


def _span(*groupsets):
    """(min, max) over all finite values of several {label: values} dicts."""
    v = np.concatenate([np.asarray(x, float) for g in groupsets for x in g.values()])
    v = v[np.isfinite(v)]
    return float(v.min()), float(v.max())


def _levels(pairs):
    """Bracket level of each significant pair: shortest spans lowest; pairs whose spans do not
    overlap (and do not share an endpoint) share a level."""
    used, out = [], []
    for i, j, _ in pairs:
        k = 0
        while k < len(used) and any(not (j < a or b < i) for a, b in used[k]):
            k += 1
        if k == len(used):
            used.append([])
        used[k].append((i, j))
        out.append(k)
    return out


def _n_pairs(posthoc, labels):
    """Number of bracket levels a panel needs."""
    lv = _levels(_sig_pairs(posthoc, labels))
    return max(lv) + 1 if lv else 0


def _boxplot(ax, groups: dict, colors, posthoc, ylabel, span=None, n_pairs=None):
    """Box + jittered points + Games-Howell brackets.

    Panels that show the same quantity pass the same `span` (data min, max over all of them) and
    `n_pairs` (largest number of bracket levels among them), so they get identical y-limits: the
    data occupy the same range and the bracket zone above it has the same height whatever the
    number of significant pairs in each panel. Levels are spaced by a fixed fraction of the axis
    height so the stars never overlap."""
    labels = list(groups)
    data = [np.asarray(groups[k])[np.isfinite(groups[k])] for k in labels]
    thin = {"linewidth": .7, "color": "0.2"}
    box = ax.boxplot(data, showfliers=False, patch_artist=True, widths=.55,
                     medianprops={"color": "k", "linewidth": 1.2}, whiskerprops=thin, capprops=thin,
                     boxprops={"linewidth": .7})
    ax.set_xticks(range(1, len(labels) + 1), labels)
    for patch, c in zip(box["boxes"], colors):
        patch.set_facecolor((*matplotlib.colors.to_rgb(c), .3))
        patch.set_edgecolor(c)
    rng = np.random.default_rng(0)
    for i, (y, c) in enumerate(zip(data, colors), start=1):
        ax.scatter(i + rng.uniform(-.14, .14, y.size), y, s=5, alpha=.55, color=c, linewidths=0,
                   zorder=3, rasterized=True)

    pairs = _sig_pairs(posthoc, labels)
    levels = _levels(pairs)
    lo, hi = span if span is not None else _span(groups)
    n = max(max(levels) + 1 if levels else 0, n_pairs or 0)
    yr = max(hi - lo, 1e-6)
    bottom, data_top = lo - .05 * yr, hi + .05 * yr
    frac = .07                                         # axis-height fraction per bracket level
    total = (data_top - bottom) / (1 - n * frac - (.02 if n else 0))
    step, h = frac * total, .015 * total
    for (i, j, p), k in zip(pairs, levels):
        y = data_top + k * step
        ax.plot([i + 1, i + 1, j + 1, j + 1], [y, y + h, y + h, y], color="k", lw=.7)
        ax.text((i + j) / 2 + 1, y + .2 * h, _stars(p), ha="center", va="bottom", fontsize=7)
    ax.set_ylim(bottom, bottom + total)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=30)
    for t in ax.get_xticklabels():
        t.set_ha("right")
        t.set_rotation_mode("anchor")


# --------------------------------------------------------------------------- #
# Feedforward: speed-dependent stride length / frequency
# --------------------------------------------------------------------------- #
def _quantile_band(x, y, degree=2):
    m = np.isfinite(x) & np.isfinite(y)
    x, y = x[m], y[m]
    order = np.argsort(x)
    x, y = x[order], y[order]
    X = np.vander(x, degree + 1)
    return x, {q: sm.QuantReg(y, X).fit(q=q, max_iter=2000).predict(X) for q in (.25, .5, .75)}


def feedforward(res, cfg):
    """2 x n_family grid: stride length (top) / frequency (bottom) vs speed, quartile bands
    from quadratic quantile regression, marginal KDEs."""
    fam = _families(cfg)
    raw = res["raw"]
    feats = [("stride_lengths", "Stride Length (m)"), ("stride_frequencies", r"Frequency (strides s$^{-1}$)")]
    fig = plt.figure(figsize=(TEXT_WIDTH, 4.6))
    outer = GridSpec(2, len(fam), figure=fig, hspace=.12, wspace=.12, left=.08, right=.99, top=.99, bottom=.09)

    for row, (key, ylabel) in enumerate(feats):
        for col, (ref_key, models) in enumerate(fam.items()):
            gs = GridSpecFromSubplotSpec(5, 5, outer[row, col], hspace=.1, wspace=.1)
            ax = fig.add_subplot(gs[1:5, 0:4])
            ax_x = fig.add_subplot(gs[0, 0:4], sharex=ax)
            ax_y = fig.add_subplot(gs[1:5, 4], sharey=ax)
            series = [(REF_LABELS[ref_key], raw["gait_refs"][ref_key], HUMAN_COLOR)]
            series += [(m, raw["gait"][m], MODEL_COLORS[m]) for m in models]
            for name, d, c in series:
                x, y = d["speeds"], d[key]
                ok = np.isfinite(x) & np.isfinite(y)
                x, y = x[ok], y[ok]
                xs, q = _quantile_band(x, y)
                ax.scatter(x, y, color=c, alpha=.06, s=1, linewidths=0, rasterized=True)
                ax.fill_between(xs, q[.25], q[.75], color=c, alpha=.15, lw=0)
                ax.plot(xs, q[.5], color=c, lw=1.5, label=name)
                xe, ye = np.linspace(.3, 4.3, 200), np.linspace(.2, 3.0, 200)
                kx, ky = gaussian_kde(x)(xe), gaussian_kde(y)(ye)
                ax_x.plot(xe, kx, color=c, lw=1)
                ax_x.fill_between(xe, kx, color=c, alpha=.1, lw=0)
                ax_y.plot(ky, ye, color=c, lw=1)
                ax_y.fill_betweenx(ye, 0, ky, color=c, alpha=.1, lw=0)
            ax.set_xlim(.3, 4.3)
            ax.set_ylim(.2, 3.0)
            if row == 0:                   # same series in both rows: one legend per column
                ax.legend(loc="upper left", handlelength=1.5)
            ax.tick_params(labelleft=col == 0, labelbottom=row == 1)
            if col == 0:
                ax.set_ylabel(ylabel)
            if row == 1:
                ax.set_xlabel("Speed (m/s)")
            ax_x.axis("off")
            ax_y.axis("off")
    return fig


# --------------------------------------------------------------------------- #
# Feedback: FPGD
# --------------------------------------------------------------------------- #
def fpgd(res, cfg):
    traj = res["fpgd_traj"]
    models = cfg["models"]
    fig, axes = plt.subplots(1, 2, figsize=(TEXT_WIDTH, 2.6), layout="constrained")
    ctxs = {ctx: {m: traj.query("context == @ctx and model == @m").fpgd.to_numpy() for m in models}
            for ctx in ("ID", "OOD")}
    span = _span(*ctxs.values())
    n = max(_n_pairs(res["fpgd_stats"][c]["posthoc"], models) for c in ctxs)
    for ax, ctx, title in zip(axes, ("ID", "OOD"), ("in-distribution", "out-of-distribution")):
        _boxplot(ax, ctxs[ctx], [MODEL_COLORS[m] for m in models], res["fpgd_stats"][ctx]["posthoc"], "FPGD",
                 span=span, n_pairs=n)
        ax.set_title(f"vs. {title} human data")
    return fig


# --------------------------------------------------------------------------- #
# Feedback: relative predictive power dR^2
# --------------------------------------------------------------------------- #
def feedback_dr2(res, cfg, context="OOD"):
    """One row per model family: dR^2 curves (mean +/- SD, x = peak of mean), peak magnitude
    and peak timing boxplots vs the OOD human data or the family's ID training data."""
    fam = _families(cfg)
    raw, pk = res["raw"], res["peak"]
    fig, axes = plt.subplots(len(fam), 3, figsize=(TEXT_WIDTH, 2.25 * len(fam)), squeeze=False, layout="constrained")
    for row, (id_ref, models) in enumerate(fam.items()):
        ref = "OOD-HUMAN" if context == "OOD" else id_ref
        ref_label = "OOD Human" if context == "OOD" else "ID Human"
        names = [ref, *models]
        labels = [ref_label, *models]
        colors = [HUMAN_COLOR, *(MODEL_COLORS[m] for m in models)]

        ax = axes[row, 0]
        for name, label, c in zip(names, labels, colors):
            src = raw["feedback_refs"] if name == ref else raw["feedback"]
            Y = src[name]["ctl_mag"]
            Y = Y[~np.all(np.isnan(Y), axis=1)]
            x, mu, sd = np.arange(Y.shape[1]), np.nanmean(Y, 0), np.nanstd(Y, 0)
            ax.plot(x, mu, color=c, lw=1.3, label=label)
            ax.fill_between(x, mu - sd, mu + sd, color=c, alpha=.18, lw=0)
            i = np.nanargmax(mu)
            ax.scatter(x[i], mu[i], color=c, s=28, marker="X", zorder=5, linewidths=0)
        ax.set(xlim=(0, 100), ylim=(0, 1))
        ax.set_xlabel("Gait cycle (%)")
        ax.set_ylabel(r"$\Delta R^2$")
        ax.legend(loc="upper left", handlelength=1.5)

        for col, (metric, ylabel) in enumerate(
                (("peak_dr2", r"Peak $\Delta R^2$"), ("peak_timing", "Peak timing (% gait cycle)")), start=1):
            groups = {lab: pk.loc[pk.group == n, metric].to_numpy() for n, lab in zip(names, labels)}
            ph = res["peak_stats"][(id_ref, context, metric)]["posthoc"]
            # same y-limits in every row of both figures (OOD and ID): all groups, most brackets
            span = _span({"all": pk[metric].to_numpy()})
            n = max(_n_pairs(st["posthoc"], list(st["descriptives"].group))
                    for (_, _, mt), st in res["peak_stats"].items() if mt == metric)
            _boxplot(axes[row, col], groups, colors, ph, ylabel, span=span, n_pairs=n)
    return fig


# --------------------------------------------------------------------------- #
# Energetics: COT two-Gaussian fits
# --------------------------------------------------------------------------- #
def cot(res, cfg):
    """Speed-COT profiles with the two-Gaussian fit (valleys marked with their optimal speeds) and the
    fit residuals; under each model name the classification, with the criterion that decided it in
    colour and the other fit statistics in grey."""
    models = cfg["models"]
    fits = res["cot"].set_index("model")
    crit = {"autocorrelation": "DW", "non-random": "runs", "R2": "R²", "RMSE": "RMSE"}
    fig, axes = plt.subplots(2, len(models), figsize=(TEXT_WIDTH, 3.5), sharex=True, layout="constrained",
                             gridspec_kw={"height_ratios": [1.5, 1]})
    for col, m in enumerate(models):
        ax, ax_r = axes[0, col], axes[1, col]
        d, c = res["raw"]["gait"][m], MODEL_COLORS[m]
        x, y = d["speeds"], zscore(d["cot"])
        ok = np.isfinite(x) & np.isfinite(y)
        x, y = x[ok], y[ok]
        ax.scatter(x, y, s=2.5, alpha=.3, color=c, linewidths=0, zorder=1, rasterized=True)
        f = fits.loc[m]
        stats = {}
        if np.isfinite(f.get("r2", np.nan)):
            p = [f[k] for k in PARAMS]
            xf = np.linspace(x.min(), x.max(), 400)
            ax.plot(xf, two_gaussian(xf, *p), color=c, lw=1.6, zorder=5,
                    path_effects=[pe.Stroke(linewidth=2.8, foreground="white"), pe.Normal()])
            comps = sorted([(f["a1"], f["mu1"]), (f["a2"], f["mu2"])], key=lambda t: t[1])
            for k, (amp, mu) in enumerate(comps):          # valleys (negative amplitude) inside the data
                if amp < 0 and x.min() - .05 <= mu <= x.max() + .05:
                    yv = two_gaussian(mu, *p)
                    ax.plot([mu], [yv], marker="v", ms=4, color="k", zorder=6)
                    ax.annotate(f"µ{'₁₂'[k]} {mu:.2f}", (mu, yv), xytext=(0, -9), textcoords="offset points",
                                ha="center", va="top", fontsize=5.5)
            r = y - two_gaussian(x, *p)
            ax_r.scatter(x, r, s=2.5, alpha=.3, color=c, linewidths=0, rasterized=True)
            lw = sm.nonparametric.lowess(r, x, frac=.25)
            ax_r.plot(lw[:, 0], lw[:, 1], color="k", lw=1.1, zorder=5)
            stats = {"R²": f"{f.r2:.2f}", "DW": f"{f.dw:.2f}",
                     "runs": "p<.001" if f.runs_p < 1e-3 else f"p={f.runs_p:.3f}"}
        for a in (ax, ax_r):
            a.axhline(0, color="0.6", lw=.6, zorder=0)
        fail = next((v for k, v in crit.items() if k in f.reason), None) if f.label == "FAIL" else None
        reason = (f.reason.split(" (")[0] if fail not in stats else f"{fail} {stats[fail]}")
        head = f.label if f.label == "PASS" else f"FAIL: {reason}"
        rest = " · ".join(f"{k} {v}" for k, v in stats.items() if k != fail)
        ax.set_title(m, pad=17)
        for yy, txt, kw in ((1.075, head, dict(fontsize=6, fontweight="bold", color="green" if f.label == "PASS" else "C3")),
                            (1.01, rest, dict(fontsize=5.5, color="0.4"))):
            t = ax.text(.5, yy, txt, transform=ax.transAxes, ha="center", va="bottom", **kw)
            t.set_in_layout(False)
        ax.set(xlim=(.3, 4.4), ylim=(-3, 3.2), yticks=[-2, 0, 2])
        ax_r.set(ylim=(-2, 2), yticks=[-1, 0, 1], xticks=[1, 2, 3, 4])
        ax_r.set_xlabel("Speed (m/s)")
        if col == 0:
            ax.set_ylabel("COT (z-score)")
            ax_r.set_ylabel("Residual")
        else:
            ax.tick_params(labelleft=False)
            ax_r.tick_params(labelleft=False)
    return fig


def conventional(res, cfg):
    """2 x 2 boxplots of Local-MPJPE / MPJAE (whole and lower body) with Games-Howell brackets."""
    panels = [("local_mpjpe_full", "Local-MPJPE (full body)", "Local-MPJPE (m)"),
              ("local_mpjpe_lower", "Local-MPJPE (lower body)", "Local-MPJPE (m)"),
              ("mpjae_full", "MPJAE (full body)", "MPJAE (deg)"), ("mpjae_lower", "MPJAE (lower body)", "MPJAE (deg)")]
    fig, axes = plt.subplots(2, 2, figsize=(TEXT_WIDTH, 5.0), layout="constrained")
    conv, st = res["raw"]["conventional"], res["conventional"]
    for ax, (key, title, ylabel) in zip(axes.flat, panels):
        vals = conv[key]
        models = [m for m in cfg["models"] if m in vals]
        pair = [k for k in conv if k.rsplit("_", 1)[0] == key.rsplit("_", 1)[0]]   # whole + lower body
        span = _span(*(conv[k] for k in pair))
        n = max(_n_pairs(st[k]["posthoc"], list(conv[k])) for k in pair)
        _boxplot(ax, {m: vals[m] for m in models}, [MODEL_COLORS[m] for m in models],
                 st[key]["posthoc"], ylabel, span=span, n_pairs=n)
        ax.set_title(title)
    return fig




def sagittal(res, cfg, normalized=True):
    """Sagittal hip/knee/ankle angles over the gait cycle in three speed bins (one figure per bin,
    conventional.sagittal.bins): model mean +- SD over the rollouts in the bin against independent human
    data (Camargo et al. 2021: each subject's mean over its strides at every treadmill speed of the bin,
    mean +- SD across subjects). Human strides lie within 0.025 m/s of a treadmill speed, so the rollouts
    are taken from the bin's first speed - 0.025 to its last speed + 0.025 m/s. normalized: each curve
    (subject mean or rollout) scaled to its own range of motion, 0 = minimum, 1 = maximum."""
    from .conventional import sagittal_angle
    from .sagittal import human_bin, rom_normalize

    cc = cfg["conventional"]
    sg, mp = cc["sagittal"], cc["mpjae"]
    angles, human = res["raw"].get("sagittal_angles", res["raw"]["joint_angles"]), res["raw"]["sagittal_human"]
    joints = [str(j) for j in human["joint"]]
    t = np.linspace(0, 100, human["angles"].shape[2])

    def curves(first, last):
        """Human subject means [subjects, T, joints] and {model: [rollouts, T, joints]} in the bin."""
        H, n_hum = human_bin(human, first, last)
        out = {}
        for m in cfg["models"]:
            spec = mp["models"][m]
            sim = angles[spec["sim"]]
            jmap = sg["joints"][mp["references"][spec["reference"]]["skeleton"]]
            sel = (sim["speed"] >= first - .025 - 1e-9) & (sim["speed"] < last + .025 - 1e-9)
            out[m] = np.stack([sagittal_angle(sim, *jmap[j])[sel] for j in joints], axis=-1)
        if normalized:
            H, out = rom_normalize(H), {m: rom_normalize(x) for m, x in out.items()}
        return H, out, n_hum

    # one y-range per joint, shared by all models and speeds: mean +- SD bands of every curve
    data = {tuple(b): curves(*b) for b in sg["bins"]}
    lo, hi = np.full(len(joints), np.inf), np.full(len(joints), -np.inf)
    for H, sims, _ in data.values():
        for X in [H, *(x for x in sims.values() if len(x))]:
            mu, sd = X.mean(0), X.std(0)
            lo, hi = np.minimum(lo, (mu - sd).min(0)), np.maximum(hi, (mu + sd).max(0))
    pad = 0.05 * (hi - lo)
    ylim = [(a - p, b + p) for a, b, p in zip(lo, hi, pad)]
    figs = {}
    for (first, last), (H, sims, n_hum) in data.items():
        fig, axes = plt.subplots(len(cfg["models"]), len(joints), figsize=(TEXT_WIDTH, 1.45 * len(cfg["models"]) + .6),
                                 sharex=True, squeeze=False, layout="constrained")
        for row, m in enumerate(cfg["models"]):
            S = sims[m]
            for col, j in enumerate(joints):
                ax = axes[row, col]
                ax.fill_between(t, H[..., col].mean(0) - H[..., col].std(0), H[..., col].mean(0) + H[..., col].std(0),
                                color="0.85", lw=0)
                ax.plot(t, H[..., col].mean(0), color="0.4", lw=1.2)
                if len(S):
                    X = S[..., col]
                    c = MODEL_COLORS[m]
                    ax.fill_between(t, X.mean(0) - X.std(0), X.mean(0) + X.std(0), color=c, alpha=.25, lw=0)
                    ax.plot(t, X.mean(0), color=c, lw=1.5)
                else:
                    ax.text(.5, .5, "no rollouts in this speed bin", transform=ax.transAxes, ha="center",
                            va="center", fontsize=7, color="0.4")
                ax.set_ylim(*ylim[col])
                if row == 0:
                    ax.set_title(f"{j} ({'dorsiflexion' if j == 'Ankle' else 'flexion'} +)")
                if col == 0:
                    ax.set_ylabel(f"{m} (n={len(S)})\n" + ("angle (0-1 of ROM)" if normalized else "angle (deg)"))
                if row == len(cfg["models"]) - 1:
                    ax.set_xlabel("Gait cycle (%)")
        handles = [plt.Rectangle((0, 0), 1, 1, color="0.85",
                                 label=f"Human (Camargo et al.), {len(H)} subjects, {n_hum} strides"),
                   *(plt.Line2D([], [], color=MODEL_COLORS[m], lw=1.5, label=m) for m in cfg["models"])]
        fig.legend(handles=handles, loc="outside upper center", ncol=6, handlelength=1.4, columnspacing=1.0,
                   title=f"Sagittal joint angles{', normalized to range of motion,' if normalized else ''} at {first:.2f}–{last:.2f} m/s (mean ± SD)", title_fontsize=9)
        figs[f"_{int(round(first * 100)):03d}_{int(round(last * 100)):03d}"] = fig
    return figs


def sagittal_shape(res, cfg):
    """Shape distance of the ROM-normalized hip, knee and ankle curves from the mean human shape
    (% of the range of motion) against speed: human leave-one-out distances (median and IQR, gray) and
    each model's rollouts (points) with their quantile-regression median (line)."""
    if "sagittal_shape" not in res:
        return {}
    from .principles import SpeedModel
    from .sagittal import JOINTS
    sh = res["sagittal_shape"]
    T = sh["tests"]
    g = np.linspace(sh["speeds"].min(), sh["speeds"].max(), 60)
    fig, axes = plt.subplots(1, 3, figsize=(TEXT_WIDTH, 2.4), layout="constrained", sharey=True)
    for ax, j in zip(axes, JOINTS):
        ref = sh["reference"][j]
        ax.fill_between(g, ref.q(g, .25), ref.q(g, .75), color="0.85", lw=0, zorder=1)
        ax.plot(g, ref.q(g, .5), color=HUMAN_COLOR, lw=1.4, ls="--", zorder=4)
        for m in cfg["models"]:
            df = sh["models"][m]
            ax.scatter(df.speed, df[j], s=2, color=MODEL_COLORS[m], alpha=.35, lw=0, rasterized=True, zorder=2)
            if len(df) >= 5 and np.ptp(df.speed) >= .3:
                mm = SpeedModel(df.speed.to_numpy(), df[j].to_numpy())
                gg = np.linspace(df.speed.min(), df.speed.max(), 40)
                ax.plot(gg, mm.q(gg, .5), color=MODEL_COLORS[m], lw=1.2, zorder=3)
        ok = [m for m in cfg["models"] if T[(T.model == m) & (T.joint == j)].consistent.iloc[0]]
        ax.set_title(f"{j}\n", fontsize=8, pad=2)
        ax.text(.5, 1.02, "consistent: " + (", ".join(ok) if ok else "none"), transform=ax.transAxes, ha="center",
                va="bottom", fontsize=5.5, color="0.3")
        ax.set_xlabel("Speed (m/s)")
        ax.tick_params(labelsize=6.5)
    axes[0].set_ylabel("Shape distance (% of ROM)", fontsize=7)
    handles = [plt.Rectangle((0, 0), 1, 1, color="0.85", label="Human (leave-one-out), median and IQR"),
               *(plt.Line2D([], [], color=MODEL_COLORS[m], lw=1.2, marker="o", ms=2, label=m) for m in cfg["models"])]
    fig.legend(handles=handles, loc="outside lower center", ncol=6, fontsize=6.5, handlelength=1.4)
    return fig


def sagittal_continuous(res, cfg, key="sagittal"):
    """Sagittal joint-angle features against speed: human median and 25-75 % range (quadratic quantile
    regression of subject x treadmill-speed means, grey), each model's rollouts (points) and their
    quadratic quantile-regression median (line); panel titles give the models consistent with the human
    reference (|median robust z| <= 2)."""
    if key not in res:
        return {}
    from .principles import SpeedModel
    from .sagittal import FEATURES
    sg = res[key]
    lo, hi = sg["human_range"]
    T = sg["tests"]
    g = np.linspace(lo, hi, 60)
    fig, axes = plt.subplots(2, 4, figsize=(TEXT_WIDTH, 4.3), layout="constrained")
    for ax, (k, (label, unit)) in zip(axes.ravel(), FEATURES.items()):
        ref = sg["reference"][k]
        ax.fill_between(g, ref.q(g, .25), ref.q(g, .75), color="0.85", lw=0, zorder=1)
        ax.plot(g, ref.q(g, .5), color=HUMAN_COLOR, lw=1.4, ls="--", zorder=4)
        for m in cfg["models"]:
            df = sg["models"][m]
            c = MODEL_COLORS[m]
            ax.scatter(df.speed, df[k], s=2, color=c, alpha=.35, lw=0, rasterized=True, zorder=2)
            ok = np.isfinite(df[k].to_numpy())
            if ok.sum() >= 5 and np.ptp(df.speed[ok]) >= .3:
                mm = SpeedModel(df.speed.to_numpy()[ok], df[k].to_numpy()[ok])
                gg = np.linspace(df.speed[ok].min(), df.speed[ok].max(), 40)
                ax.plot(gg, mm.q(gg, .5), color=c, lw=1.2, zorder=3)
        ok = [m for m in cfg["models"] if T[(T.model == m) & (T.feature == k)].consistent.iloc[0]]
        ax.set_title(f"{label[0].upper()}{label[1:]}\n", fontsize=7.5, pad=2)
        ax.text(.5, 1.02, "consistent: " + (", ".join(ok) if ok else "none"), transform=ax.transAxes,
                ha="center", va="bottom", fontsize=5.5, color="0.3")
        ax.set_ylabel("% of gait cycle" if unit == "%" else "deg", fontsize=7)
        ax.tick_params(labelsize=6.5)
    for ax in axes[-1]:
        ax.set_xlabel("Speed (m/s)")
    handles = [plt.Rectangle((0, 0), 1, 1, color="0.85",
                             label=f"Human (Camargo et al.), median and IQR, {sg['human'].unit.nunique()} subjects"),
               *(plt.Line2D([], [], color=MODEL_COLORS[m], lw=1.2, marker="o", ms=2, label=m) for m in cfg["models"])]
    fig.legend(handles=handles, loc="outside lower center", ncol=6, fontsize=6.5, handlelength=1.4)
    return fig


PRINCIPLE_PANELS = [("double_support", "P1 double support (fraction)"), ("pushoff_work", "P1 push-off work (J/kg)"),
                    ("collision_work", "P1 collision work (J/kg)"), ("ankle_share", "P2 ankle share of positive work"),
                    ("knee_net_work", "P3 knee net work (J/kg)"), ("net_ap_impulse", "P4 net / propulsive AP impulse"),
                    ("fz_peak1", "P5 first vertical peak (BW)"), ("stance_frac", "P5 stance fraction"),
                    ("recovery", "P6 energy recovery (%)")]


def principles(res, cfg, key="principles"):
    """Key metric of each biomechanical principle against speed: human median and 25-75 % range
    (quadratic quantile regression of subject x speed means, grey; the means as grey points), each
    model's rollout means (points) and their quadratic quantile-regression median (lines) within the
    human speed range. The y-range covers the human data and the 1st-99th percentile of the model points (AP
    impulse ratio: -1 to 0.4, below which KINESIS falls at its slowest speeds)."""
    if key not in res:
        return {}
    from .principles import SpeedModel
    pr = res[key]
    norm = bool(pr.get("legs"))
    lo, hi = pr["human_range"]
    H = pr["groups"]["Human"]
    fig, axes = plt.subplots(3, 3, figsize=(TEXT_WIDTH, 5.6), layout="constrained")
    g = np.linspace(lo, hi, 60)
    for ax, (metric, title) in zip(axes.ravel(), PRINCIPLE_PANELS):
        hm = SpeedModel(H.speed.to_numpy(), H[metric].to_numpy())
        ax.fill_between(g, hm.q(g, .25), hm.q(g, .75), color="0.85", lw=0, zorder=1)
        ax.plot(g, hm.q(g, .5), color="0.35", lw=1.4, ls="--", zorder=4)
        ax.scatter(H.speed, H[metric], s=2, color="0.45", alpha=.5, lw=0, rasterized=True, zorder=2)
        hv = np.r_[H[metric].to_numpy(), hm.q(g, .25), hm.q(g, .75)]
        vals = []
        for m in cfg["models"]:
            df = pr["groups"][m]
            ok = np.isfinite(df[metric].to_numpy())
            ax.scatter(df.speed[ok], df[metric][ok], s=2, color=MODEL_COLORS[m], alpha=.35, lw=0, rasterized=True, zorder=2)
            vals.append(df[metric].to_numpy()[ok])
            if ok.sum() < 5 or np.ptp(df.speed[ok]) < .3:
                continue
            mm = SpeedModel(df.speed.to_numpy()[ok], df[metric].to_numpy()[ok])
            gg = np.linspace(df.speed[ok].min(), df.speed[ok].max(), 40)
            ax.plot(gg, mm.q(gg, .5), color=MODEL_COLORS[m], lw=1.3, zorder=3)
        v = np.concatenate(vals); v = v[np.isfinite(v)]
        hv = hv[np.isfinite(hv)]
        a, b = min(hv.min(), np.percentile(v, 1)), max(hv.max(), np.percentile(v, 99)); pad = .05 * (b - a)
        ax.set_ylim(*((-1.0, 0.4) if metric == "net_ap_impulse" else (a - pad, b + pad)))   # KINESIS falls to -5 at its slowest speeds
        ax.set_title(title.replace("(J/kg)", "($/\\,mgL$)") if norm else title, fontsize=7.5)
        ax.tick_params(labelsize=6.5)
    for ax in axes[-1]:
        ax.set_xlabel("Speed (m/s)")
    handles = [plt.Rectangle((0, 0), 1, 1, color="0.85", label="Human (Camargo et al.), median and IQR"),
               *(plt.Line2D([], [], color=MODEL_COLORS[m], lw=1.3, marker="o", ms=2, label=m) for m in cfg["models"])]
    fig.legend(handles=handles, loc="outside lower center", ncol=6, fontsize=6.5, handlelength=1.4)
    return fig


G = 9.80665
NORM_POWER = "$/\\,mg^{1.5}L^{0.5}$"


def _model_cycles(d, cfg):
    """Mean speed of each stored model cycle (rollout x 0.2 m/s bin of extract_model_kinetics.py): the mean
    speed of that rollout's strides in that bin."""
    from .conventional import speed_bin
    centers = np.linspace(*cfg["conventional"]["speed_bins"])
    v, r = d["features"][:, 0].astype(float), d["stride_rollout"]
    b = speed_bin(v, centers)
    return np.array([v[(r == cr) & np.isclose(b, round(cb, 1))].mean() for cr, cb in zip(d["cycle_rollout"], d["cycle_bin_speed"])])


def _bin_curves(key, j, first, last, hum, d, cfg, cyc_speed):
    """Human subject means (stride-weighted over the treadmill speeds first..last) and model rollout means
    (cycle-weighted over the cycles whose speed lies within first - 0.025 .. last + 0.025 m/s)."""
    sel = (hum["tm_speed"] >= first - 1e-9) & (hum["tm_speed"] <= last + 1e-9)
    A = hum[f"tm_{key}"][:, sel].astype(float)
    A = A if j is None else A[..., j]
    n = np.where(np.isfinite(A).all(-1), hum["tm_n_strides"][:, sel], 0).astype(float)
    with np.errstate(invalid="ignore"):
        H = (np.nan_to_num(A) * n[..., None]).sum(1) / n.sum(1)[:, None]
    H = H[n.sum(1) > 0]
    X = d[key] if j is None else d[key][..., j]
    keep = (cyc_speed >= first - .025 - 1e-9) & (cyc_speed < last + .025 - 1e-9) & np.isfinite(X).all(1)
    R = d["cycle_rollout"][keep]
    M = np.array([np.average(X[keep][R == r], axis=0, weights=d["cycle_n"][keep][R == r]) for r in np.unique(R)])
    return H, M.reshape(-1, X.shape[-1])


def kinetic_waveforms(res, cfg, key="principles"):
    """GRF and sagittal joint power over the stride in the three speed bins of the sagittal figures
    (conventional.sagittal.bins), one figure per bin: one row per model (mean +- SD over rollouts, each
    the mean of its cycles in the bin) against the human mean +- SD over subjects (each the mean of its
    strides at the bin's treadmill speeds; Camargo et al. 2021). For the normalized results, power is
    divided by g^1.5 L^0.5 (Hof 1996; L, leg length)."""
    if key not in res:
        return {}
    hum, mods = res["principles"]["data"]["human"], res["principles"]["data"]["models"]
    if "tm_speed" not in hum:
        return {}
    legs = res[key].get("legs")
    pu = NORM_POWER if legs else "(W/kg)"
    cols = [("fz", None, "Vertical GRF (BW)"), ("fap", None, "AP GRF (BW)"), ("power", 0, f"Hip power {pu}"),
            ("power", 1, f"Knee power {pu}"), ("power", 2, f"Ankle power {pu}")]
    models = cfg["models"]
    t = np.linspace(0, 100, 101)
    Lh = np.array([legs["human"][str(s)] for s in hum["subject"]]) if legs else None
    cyc_speed = {m: _model_cycles(mods[m], cfg) for m in models}
    bins = [tuple(b) for b in cfg["conventional"]["sagittal"]["bins"]]
    data = {}
    for b in bins:
        for c, (q, j, _) in enumerate(cols):
            if q == "power" and legs:
                hum_s = dict(hum); hum_s["tm_power"] = hum["tm_power"] / (G ** 1.5 * np.sqrt(Lh))[:, None, None, None]
            else:
                hum_s = hum
            for m in models:
                d = mods[m]
                if q == "power" and legs:
                    d = dict(d); d["power"] = d["power"] / (G ** 1.5 * np.sqrt(legs["models"][m]))
                data[b, c, m] = _bin_curves(q, j, *b, hum_s, d, cfg, cyc_speed[m])
    ylim = {}
    for c in range(len(cols)):                     # one y-range per column, shared by all bins and models
        curves = [x for (b, cc, m), (H, M) in data.items() if cc == c for x in (H, M) if len(x)]
        lo = min(np.nanmin(x.mean(0) - x.std(0)) for x in curves); hi = max(np.nanmax(x.mean(0) + x.std(0)) for x in curves)
        pad = .05 * (hi - lo); ylim[c] = (lo - pad, hi + pad)
    figs = {}
    for b in bins:
        fig, ax = plt.subplots(len(models), len(cols), figsize=(TEXT_WIDTH, 1.25 * len(models) + .7), sharex=True,
                               squeeze=False, layout="constrained")
        for c, (q, j, lab) in enumerate(cols):
            for r, m in enumerate(models):
                H, X = data[b, c, m]
                hm, hs = np.nanmean(H, 0), np.nanstd(H, 0)
                a = ax[r, c]
                a.fill_between(t, hm - hs, hm + hs, color="0.85", lw=0)
                a.plot(t, hm, color="0.4", lw=1.1)
                if len(X):
                    a.fill_between(t, X.mean(0) - X.std(0), X.mean(0) + X.std(0), color=MODEL_COLORS[m], alpha=.25, lw=0)
                    a.plot(t, X.mean(0), color=MODEL_COLORS[m], lw=1.4)
                else:
                    a.text(.5, .5, "no rollouts in this speed bin", transform=a.transAxes, ha="center", va="center",
                           fontsize=6, color="0.4")
                a.axhline(0, color="0.7", lw=.5, zorder=0)
                a.set_ylim(*ylim[c])
                a.tick_params(labelsize=6)
                if r == 0:
                    a.set_title(lab, fontsize=7.5)
                if c == 0:
                    a.set_ylabel(f"{m}\n(n={len(X)})", fontsize=7.5)
                if r == len(models) - 1:
                    a.set_xlabel("Stride (%)", fontsize=7)
        H0 = data[b, 0, models[0]][0]
        sel = (hum["tm_speed"] >= b[0] - 1e-9) & (hum["tm_speed"] <= b[1] + 1e-9)
        fig.legend(handles=[plt.Rectangle((0, 0), 1, 1, color="0.85",
                                          label=f"Human mean ± SD ({len(H0)} subjects, {int(hum['tm_n_strides'][:, sel].sum())} strides)"),
                            *(plt.Line2D([], [], color=MODEL_COLORS[m], lw=1.4, label=m) for m in models)],
                   loc="outside upper center", ncol=6, fontsize=6.5,
                   title=f"GRF and joint power at {b[0]:.2f}–{b[1]:.2f} m/s (mean ± SD)", title_fontsize=8.5)
        figs[f"_{int(round(b[0] * 100)):03d}_{int(round(b[1] * 100)):03d}"] = fig
    return figs


KINETIC_JOINTS = {"hip": "#8da0cb", "knee": "#a6d854", "ankle": "#fc8d62"}


def kinetic_work(res, cfg, key="principles"):
    """Positive hip, knee and ankle work per stride in the three speed bins of the sagittal figures: mean
    over human subjects (strides at the bin's treadmill speeds +- 0.025 m/s) and over each model's
    rollouts (strides in the same range), stacked, with the ankle share. For the normalized results,
    work is divided by g L (Hof 1996)."""
    if key not in res:
        return {}
    from .kinetics import FEATURES
    legs = res[key].get("legs")
    hum, mods = res["principles"]["data"]["human"], res["principles"]["data"]["models"]
    ix = [FEATURES.index(f"{j}_pos_work") for j in KINETIC_JOINTS]
    bins = [tuple(b) for b in cfg["conventional"]["sagittal"]["bins"]]

    def units(F, ids, L, first, last):
        m = (F[:, 0] >= first - .025 - 1e-9) & (F[:, 0] < last + .025 - 1e-9)
        W = F[:, ix] / (G * np.asarray(L, float)[..., None] if legs else 1.0)
        return np.array([np.nanmean(W[m & (ids == u)], 0) for u in np.unique(ids[m]) if (m & (ids == u)).sum() >= 2]).reshape(-1, 3)
    Lh = np.array([legs["human"][str(s)] for s in hum["subject"]])[hum["stride_subject"]] if legs else 1.0
    fig, axes = plt.subplots(1, len(bins), figsize=(TEXT_WIDTH, 2.7), layout="constrained", sharey=True)
    top = 0
    for ax, (first, last) in zip(axes, bins):
        W = {"Human": units(hum["features"].astype(float), hum["stride_subject"], Lh, first, last),
             **{m: units(mods[m]["features"].astype(float), mods[m]["stride_rollout"], legs["models"][m] if legs else 1.0,
                         first, last) for m in cfg["models"]}}
        for i, (g, X) in enumerate(W.items()):
            if not len(X):
                continue
            mu, b = np.nanmean(X, 0), 0.0
            for k, (j, c) in enumerate(KINETIC_JOINTS.items()):
                ax.bar(i, mu[k], bottom=b, color=c, width=.7, edgecolor="white", lw=.6,
                       label=j.capitalize() if i == 0 and ax is axes[0] else None)
                b += mu[k]
            top = max(top, b)
            ax.text(i, b, f"{100 * mu[2] / mu.sum():.0f}%", ha="center", va="bottom", fontsize=5.5)
        ax.set_xticks(range(len(W)))
        ax.set_xticklabels([f"{g}\n({len(X)})" for g, X in W.items()], fontsize=5.5, rotation=0)
        ax.set_title(f"{first:.2f}–{last:.2f} m/s", fontsize=8)
    axes[0].set_ylabel("Positive joint work per stride " + ("($/\\,mgL$)" if legs else "(J/kg)"), fontsize=7)
    axes[0].set_ylim(0, top * 1.12)
    fig.legend(*axes[0].get_legend_handles_labels(), loc="outside upper center", ncol=3, fontsize=7,
               title="Number above each bar: ankle share of positive work; (n) subjects or rollouts", title_fontsize=6.5)
    return fig


def principles_scorecard(res, cfg, key="principles"):
    """Each prediction of the biomechanical principles for each model: consistent (green) or not
    (red), with its value (z, share, slope or vertex speed), and the count per model."""
    if key not in res:
        return {}
    from .principles import PREDICTIONS
    T = res[key]["tests"]
    models = cfg["models"]
    fig, ax = plt.subplots(figsize=(TEXT_WIDTH * .85, 4.9), layout="constrained")
    for i, p in enumerate(PREDICTIONS):
        for k, m in enumerate(models):
            r = T[(T.group == m) & (T.key == p.key)].iloc[0]
            na = r.consistent is None or (isinstance(r.consistent, float) and np.isnan(r.consistent))
            ax.add_patch(plt.Rectangle((k, i), .96, .92, color="#d9d9d9" if na else ("#7fc97f" if r.consistent else "#f4a6a6"), lw=0))
            txt = ("n/a" if na else f"{r.value:+.1f}" if p.kind == "magnitude" else f"{100 * r.value:.0f}%" if p.kind == "sign"
                   else f"{r.value:+.2g}" if p.kind == "direction" else f"{r.value:.2f}")
            ax.text(k + .48, i + .46, txt, ha="center", va="center", fontsize=6)
    ax.set_xlim(0, len(models)); ax.set_ylim(len(PREDICTIONS), 0)
    ax.set_xticks(np.arange(len(models)) + .48); ax.set_xticklabels(models, fontsize=7.5); ax.xaxis.tick_top()
    ax.set_yticks(np.arange(len(PREDICTIONS)) + .46)
    ax.set_yticklabels([f"{p.principle} {p.text}" for p in PREDICTIONS], fontsize=6.5)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.tick_params(length=0)
    for k, m in enumerate(models):
        sub = T[T.group == m].consistent.dropna()
        ax.text(k + .48, len(PREDICTIONS) + .55, f"{int(sub.sum())}/{len(sub)}", ha="center", va="center", fontsize=7.5,
                fontweight="bold", clip_on=False)
    return fig


def matched_stride(res, cfg):
    """Stride length and frequency at matched speed against the Camargo treadmill data: median robust z
    of each model's trajectories per 0.2 m/s speed bin (line) with quartiles (band); grey, the human range
    |z| <= 2. Symmetric-log axis: linear within +-2."""
    if "matched" not in res:
        return {}
    fig, axes = plt.subplots(1, 2, figsize=(TEXT_WIDTH, 2.4), layout="constrained", sharex=True)
    titles = {"stride_length": "Stride length", "stride_frequency": "Stride frequency"}
    for ax, feat in zip(axes, cfg["feedforward_features"]):
        ax.axhspan(-2, 2, color="0.9", lw=0, zorder=0)
        ax.axhline(0, color=HUMAN_COLOR, lw=.6, zorder=1)
        for m in cfg["models"]:
            P = res["matched"]["models"][m][feat]["profile"]
            P = [q for q in P if q["n"] >= 3]
            v = [q["speed"] for q in P]
            ax.fill_between(v, [q["q25"] for q in P], [q["q75"] for q in P], color=MODEL_COLORS[m], alpha=.18, lw=0)
            ax.plot(v, [q["median_z"] for q in P], color=MODEL_COLORS[m], marker="o", ms=2.5, label=m)
        ax.set_yscale("symlog", linthresh=2, linscale=1.2)
        ticks = [-20, -10, -5, -2, 0, 2, 5, 10, 20, 40]
        lo, hi = ax.get_ylim()
        ax.set_yticks([t for t in ticks if lo <= t <= hi], [f"{t:g}".replace("-", "−") for t in ticks if lo <= t <= hi])
        ax.yaxis.set_minor_locator(matplotlib.ticker.NullLocator())
        ax.set_title(titles.get(feat, feat))
        ax.set_xlabel("Speed (m/s)")
    axes[0].set_ylabel("$z$ at matched speed")
    fig.legend(*axes[0].get_legend_handles_labels(), loc="outside upper center", ncol=5)
    return fig


FIGURES = {
    "fig_conventional": conventional,
    "fig_feedforward": feedforward,
    "fig_fpgd": fpgd,
    "fig_feedback_ood": lambda r, c: feedback_dr2(r, c, "OOD"),
    "fig_feedback_id": lambda r, c: feedback_dr2(r, c, "ID"),
    "fig_cot": cot,
    "fig_sagittal": sagittal,
    "fig_sagittal_continuous": sagittal_continuous,
    "fig_sagittal_shape": sagittal_shape,
    "fig_principles": principles,
    "fig_principles_scorecard": principles_scorecard,
    "fig_kinetic_waveforms": kinetic_waveforms,
    "fig_kinetic_work": kinetic_work,
    "fig_matched_stride": matched_stride,
}
