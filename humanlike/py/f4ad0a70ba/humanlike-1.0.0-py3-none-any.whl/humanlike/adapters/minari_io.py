"""Minari mapping of the humanlike locomotion profile (docs/oss/PROFILE.md).

A Minari dataset (Farama Foundation; HDF5 or Arrow) carries the profile as follows:
    dataset          one model (or one group of human subjects)
    metadata.json    "humanlike_profile": {"profile", "version", "samples_per_step", "fs", "up", "mass_kg",
                     "leg_length_m", "sagittal_side", "name", "kind", "simulator", "skeleton", "joint_torque_source",
                     "grf_source"}
    episode          one rollout; episode metadata (optional): "group", "commanded_speed", "fell", "skip_s",
                     "transient_dropped_s"
    step infos       infos["humanlike"][<signal>]: the samples of the profile signal recorded since the
                     previous step, shape [samples_per_step, ...] (e.g. pelvis_pos [k, 3], left_grf [k, 3]);
                     foot strikes as boolean signals left_heel_strike / right_heel_strike [k]
The entry Minari stores at reset (index 0) is not used: an episode of n steps gives n x k samples, the
samples of step i covering the interval of action i. Signal names, shapes, units and sign conventions
are those of humanlike.format.spec.FIELDS; fs is the rate of the profile signals (k / control period).

    read(path_or_id) -> Dataset            a Minari dataset (directory or registered id) as a data set;
                                           needs only h5py (HDF5) or pyarrow (Arrow), not minari
    annotate(path_or_id, fs=..., ...)      add the profile metadata (no minari needed)
    write(ds, dataset_id, ...)             a data set as a Minari dataset: HDF5 written with h5py, compressed
                                           (no minari needed; evaluation only: placeholder observations/actions)
    collector(env), finish(c, id, ...)     record with minari.DataCollector (infos kept), then add the profile
                                           metadata and check the dataset
"""
from __future__ import annotations

from pathlib import Path

import numpy as np

from ..format import Dataset, Rollout
from ..format.spec import FIELD

PROFILE = "humanlike-locomotion"
VERSION = "1.0"
KEY = "humanlike"
META = "humanlike_profile"
STRIKES = {"left_heel_strike": "left_heel_strikes", "right_heel_strike": "right_heel_strikes"}


def is_minari(path) -> bool:
    p = Path(str(path))
    return p.is_dir() and ((p / "data" / "metadata.json").exists() or (p / "metadata.json").exists())


def data_dir(path_or_id) -> Path:
    """The directory holding metadata.json: a dataset directory, its data/ folder, or a registered id
    under $MINARI_DATASETS_PATH (default ~/.minari/datasets)."""
    import os
    p = Path(str(path_or_id))
    if not p.exists():
        root = Path(os.environ.get("MINARI_DATASETS_PATH") or Path.home() / ".minari" / "datasets")
        p = root / str(path_or_id)
    if (p / "data" / "metadata.json").exists():
        return p / "data"
    if (p / "metadata.json").exists():
        return p
    raise FileNotFoundError(f"{path_or_id}: not a Minari dataset (no metadata.json)")


def _episodes(d: Path, fmt: str):
    """(episode metadata, {signal: [steps + 1, ...]}) per episode, read with h5py or pyarrow only, so
    that reading needs neither the minari package nor its dependencies (and runs in Pyodide)."""
    if fmt == "hdf5":
        import h5py
        with h5py.File(d / "main_data.hdf5", "r") as f:
            names = sorted((k for k in f if k.startswith("episode_")), key=lambda k: int(k.split("_")[1]))
            for n in names:
                g = f[n]
                em = {k: (v.decode() if isinstance(v, bytes) else v.item() if hasattr(v, "item") else v)
                      for k, v in g.attrs.items()}
                info = g.get("infos", {}).get(KEY) if "infos" in g else None
                yield em, None if info is None else {s: info[s][()] for s in info}
    else:
        import json
        import pyarrow as pa
        eps = sorted((x for x in d.iterdir() if x.is_dir() and x.name.isdigit()), key=lambda x: int(x.name))
        for e in eps:
            em = json.loads((e / "metadata.json").read_text()) if (e / "metadata.json").exists() else {"id": int(e.name)}
            tables = []
            for part in sorted(e.glob("*.arrow")):
                with pa.memory_map(str(part)) as src:
                    tables.append(pa.ipc.open_file(src).read_all())
            t = pa.concat_tables(tables)
            if "infos" not in t.column_names:
                yield em, None
                continue
            infos = t.column("infos").combine_chunks()
            if KEY not in [f.name for f in infos.type]:
                yield em, None
                continue
            h = infos.field(KEY)
            out = {}
            for i, fld in enumerate(h.type):
                col = h.field(i)
                shape = tuple(int(x) for x in (fld.metadata or {}).get(b"shape", b"").decode().split(",") if x)
                vals = np.asarray(col.flatten() if pa.types.is_fixed_size_list(col.type) else col.to_numpy(zero_copy_only=False))
                out[fld.name] = vals.reshape(len(col), *shape) if shape else vals.reshape(len(col), -1).squeeze(-1) \
                    if vals.size == len(col) else vals.reshape(len(col), -1)
            yield em, out


def read(path_or_id, name: str | None = None) -> Dataset:
    """A data set from a Minari dataset (directory, its data/ folder, or a registered id) that carries the
    humanlike profile metadata: the profile signals of every episode at their sampling rate, the episode
    metadata (group, commanded_speed, fell, skip_s, transient_dropped_s) and the dataset metadata. name
    overrides the dataset's name."""
    import json
    d = data_dir(path_or_id)
    meta = json.loads((d / "metadata.json").read_text())
    prof = meta.get(META)
    if not prof:
        raise ValueError(f"{path_or_id}: no '{META}' metadata. Add it with humanlike.adapters.minari_io.annotate("
                         f"path, fs=<Hz of the profile signals>, samples_per_step=<samples per env step>, mass_kg=...)")
    k, fs = int(prof.get("samples_per_step", 1)), float(prof["fs"])
    rollouts = []
    for em, info in _episodes(d, meta.get("data_format", "hdf5")):
        eid = em.get("id")
        if info is None:
            raise ValueError(_missing_infos(eid))
        arrays = {}
        for sig, val in info.items():
            a = np.asarray(val)[1:]                               # drop the reset entry
            sample_ndim = 0 if sig in STRIKES else 1 if sig in FIELD else a.ndim - 2
            if a.ndim == sample_ndim + 2:                         # [steps, k, ...] -> [steps * k, ...]
                a = a.reshape(a.shape[0] * a.shape[1], *a.shape[2:])
            elif not (a.ndim == sample_ndim + 1 and k == 1):
                raise ValueError(f"episode {eid}: infos['{KEY}']['{sig}'] has shape {np.shape(val)}; "
                                 f"expected [steps + 1, {k}, ...]")
            if sig in STRIKES:
                arrays[STRIKES[sig]] = np.flatnonzero(a.astype(bool).ravel())
            elif sig in FIELD:
                arrays[sig] = a.astype(float)
        rm = {"id": str(em.get("rollout_id", eid)), "group": str(em.get("group", "0")), "fs": fs}
        for key in ("commanded_speed", "fell", "skip_s", "transient_dropped_s"):
            if key in em:
                v = em[key]
                rm[key] = bool(v) if key == "fell" else float(v)
        rollouts.append(Rollout(rm, arrays))
    ds_meta = {"dataset": {k2: prof[k2] for k2 in ("kind", "simulator", "skeleton", "sagittal_side", "joint_torque_source", "grf_source",
                                                   "provenance") if prof.get(k2) is not None},
               "subject": {k2: float(prof[k2]) for k2 in ("mass_kg", "leg_length_m") if prof.get(k2) is not None},
               "frame": {"up": prof.get("up", "z"), "units": "m"}}
    ds_meta["dataset"]["name"] = name or prof.get("name") or meta.get("dataset_id", "minari")
    ds_meta["dataset"]["source"] = f"minari:{meta.get('dataset_id')}"
    return Dataset(ds_meta, rollouts)


def _missing_infos(eid) -> str:
    return (f"episode {eid}: no infos['{KEY}']. Record the profile signals in the step infos and keep them: "
            "minari.DataCollector(env, record_infos=True), or humanlike.adapters.minari_io.collector(env); "
            "see docs/oss/PROFILE.md")


def annotate(path_or_id, *, fs: float, samples_per_step: int = 1, up: str = "z", mass_kg=None, leg_length_m=None,
             sagittal_side=None, name=None, kind="simulation", simulator=None, skeleton=None, episodes=None,
             evaluation_only: bool | None = None, joint_torque_source=None,
             grf_source=None, provenance: dict | None = None) -> Path:
    """Add the profile metadata to a Minari dataset (HDF5 or Arrow; the minari package is not needed);
    episodes: optional list of per-episode dicts (group, commanded_speed, fell, skip_s), in episode order.
    Returns the dataset's data directory."""
    import json
    d = data_dir(path_or_id)
    meta = json.loads((d / "metadata.json").read_text())
    prof = {"profile": PROFILE, "version": VERSION, "samples_per_step": int(samples_per_step), "fs": float(fs), "up": up,
            "mass_kg": mass_kg, "leg_length_m": leg_length_m, "sagittal_side": sagittal_side, "name": name, "kind": kind,
            "simulator": simulator, "skeleton": skeleton, "evaluation_only": evaluation_only,
            "joint_torque_source": joint_torque_source, "grf_source": grf_source, "provenance": provenance}
    meta[META] = {k: (float(v) if isinstance(v, np.floating) else v) for k, v in prof.items() if v is not None}
    (d / "metadata.json").write_text(json.dumps(meta))
    if episodes is not None:
        if meta.get("data_format", "hdf5") == "hdf5":
            import h5py
            with h5py.File(d / "main_data.hdf5", "a") as f:
                for i, em in enumerate(episodes):
                    for k, v in em.items():
                        f[f"episode_{i}"].attrs[k] = v
        else:
            for i, em in enumerate(episodes):
                f = d / str(i) / "metadata.json"
                old = json.loads(f.read_text()) if f.exists() else {"id": i}
                f.write_text(json.dumps({**old, **em}))
    return d


# --- writing ---------------------------------------------------------------------------------------
LAYOUT = "0.5.0"      # the Minari dataset layout written (metadata.json + main_data.hdf5), read by Minari >= 0.5.0
_OBS = {"type": "Box", "dtype": "float64", "shape": [9], "low": [-np.inf] * 9, "high": [np.inf] * 9}
_ACT = {"type": "Box", "dtype": "float32", "shape": [1], "low": [-1.0], "high": [1.0]}


def _episode_arrays(r, k: int):
    """(observations [n+1, 9], {signal: [n+1, k, ...]}, n) of one rollout; the reset entry repeats step 0."""
    T = len(r.arrays["pelvis_pos"]) // k * k
    n = T // k
    info = {}
    for sig, a in r.arrays.items():
        f = FIELD.get(sig)
        if f is None:
            continue
        if f.shape == "n":
            flag = np.zeros(T, bool)
            hs = np.asarray(a, int)
            flag[hs[hs < T]] = True
            sig, a = {v: k2 for k2, v in STRIKES.items()}[sig], flag
        a = np.asarray(a)[:T].reshape(n, k, *np.shape(a)[1:])
        info[sig] = np.concatenate([a[:1], a], 0)
    core = np.concatenate([np.asarray(r.arrays[s], float)[:T][k - 1::k] for s in ("pelvis_pos", "left_foot_pos", "right_foot_pos")], 1)
    return np.concatenate([core[:1], core], 0), info, n


def _episode_meta(r) -> dict:
    return {"rollout_id": r.id, "group": str(r.meta["group"]),
            **{key: r.meta[key] for key in ("commanded_speed", "fell", "skip_s", "transient_dropped_s")
               if r.meta.get(key) is not None}}


def _profile_kwargs(ds: Dataset, k: int) -> dict:
    fs = {r.fs for r in ds.rollouts}
    if len(fs) != 1:
        raise ValueError("a Minari dataset needs one sampling rate for all rollouts")
    d, s = ds.meta.get("dataset", {}), ds.meta.get("subject", {})
    return dict(fs=fs.pop(), samples_per_step=k, up=ds.meta.get("frame", {}).get("up", "z"), mass_kg=s.get("mass_kg"),
                leg_length_m=s.get("leg_length_m"), sagittal_side=d.get("sagittal_side"), name=ds.name,
                kind=d.get("kind", "simulation"), simulator=d.get("simulator"), skeleton=d.get("skeleton"),
                joint_torque_source=d.get("joint_torque_source"), grf_source=d.get("grf_source"),
                provenance=d.get("provenance"))


def write(ds: Dataset, dataset_id: str, *, samples_per_step: int = 1, data_format: str = "hdf5", root=None,
          compress: bool = True, author=None, algorithm_name=None, description=None, code_permalink=None) -> Path:
    """Write a data set as a Minari dataset with the profile, at <root>/<dataset_id>/data (root:
    $MINARI_DATASETS_PATH or ~/.minari/datasets, as Minari). Returns the data directory.

    HDF5 is written directly with h5py (the Minari layout, compressed with gzip and shuffle when
    `compress`), so neither minari nor its dependencies are needed, also in the browser; Arrow is
    written with the minari package. Observations are the core positions (pelvis, left foot, right foot)
    at the last sample of each step and actions a zero placeholder: such a dataset is for evaluation
    (marked evaluation_only), the profile signals are in the step infos."""
    import json
    import os
    import re
    if not re.fullmatch(r"([\w.-]+/)?[\w.-]+-v\d+", dataset_id):
        raise ValueError(f"{dataset_id!r}: Minari dataset ids are [namespace/]name-v<version>, e.g. mylab/policy-v0")
    k = int(samples_per_step)
    root = Path(root or os.environ.get("MINARI_DATASETS_PATH") or Path.home() / ".minari" / "datasets").resolve()
    description = description or f"{ds.name}: humanlike locomotion profile {VERSION} (signals in infos['{KEY}'])"
    if data_format == "arrow":
        return _write_with_minari(ds, dataset_id, k, root, author=author, algorithm_name=algorithm_name,
                                  description=description, code_permalink=code_permalink)
    if data_format != "hdf5":
        raise ValueError("data_format must be 'hdf5' or 'arrow'")
    import h5py
    d = root / dataset_id / "data"
    d.mkdir(parents=True, exist_ok=True)
    opts = {"compression": "gzip", "compression_opts": 4, "shuffle": True} if compress else {}
    total = 0
    with h5py.File(d / "main_data.hdf5", "w") as f:
        for i, r in enumerate(ds.rollouts):
            obs, info, n = _episode_arrays(r, k)
            g = f.create_group(f"episode_{i}")
            g.attrs["id"] = np.int64(i)
            g.attrs["total_steps"] = np.int64(n)
            for key, v in _episode_meta(r).items():
                g.attrs[key] = v
            g.create_dataset("observations", data=obs.astype(np.float64), **opts)
            g.create_dataset("actions", data=np.zeros((n, 1), np.float32), **opts)
            g.create_dataset("rewards", data=np.zeros(n), **opts)
            g.create_dataset("terminations", data=np.zeros(n, bool), **opts)
            trunc = np.zeros(n, bool)
            trunc[-1] = True
            g.create_dataset("truncations", data=trunc, **opts)
            h = g.create_group("infos").create_group(KEY)
            for sig, a in info.items():
                h.create_dataset(sig, data=a, **opts)
            total += n
    meta = {"total_episodes": len(ds.rollouts), "total_steps": int(total), "data_format": "hdf5", "jpeg_encoding": False,
            "observation_space": json.dumps(_OBS), "action_space": json.dumps(_ACT), "dataset_id": dataset_id,
            "minari_version": LAYOUT, "description": description,
            "dataset_size": round((d / "main_data.hdf5").stat().st_size / 1e6, 1)}
    if author:
        meta["author"] = [author] if isinstance(author, str) else list(author)
    if algorithm_name:
        meta["algorithm_name"] = algorithm_name
    if code_permalink:
        meta["code_permalink"] = code_permalink
    (d / "metadata.json").write_text(json.dumps(meta))
    annotate(d, **_profile_kwargs(ds, k), evaluation_only=True)
    return d


def _write_with_minari(ds, dataset_id, k, root, **kw) -> Path:
    import os
    import gymnasium as gym
    import minari
    from minari.data_collector import EpisodeBuffer
    os.environ["MINARI_DATASETS_PATH"] = str(root)
    eps = []
    for i, r in enumerate(ds.rollouts):
        obs, info, n = _episode_arrays(r, k)
        eps.append(EpisodeBuffer(id=i, observations=obs, actions=np.zeros((n, 1), np.float32), rewards=list(np.zeros(n)),
                                 terminations=[False] * n, truncations=[False] * (n - 1) + [True], infos={KEY: info}))
    md = minari.create_dataset_from_buffers(dataset_id, eps, observation_space=gym.spaces.Box(-np.inf, np.inf, (9,), np.float64),
                                            action_space=gym.spaces.Box(-1.0, 1.0, (1,), np.float32), data_format="arrow",
                                            **{key: v for key, v in kw.items() if v is not None})
    return annotate(md.storage.data_path, **_profile_kwargs(ds, k), episodes=[_episode_meta(r) for r in ds.rollouts],
                    evaluation_only=True)


# --- recording with minari.DataCollector -----------------------------------------------------------
def collector(env, **kw):
    """minari.DataCollector for an environment whose step infos carry infos['humanlike'] (the infos are
    kept: record_infos=True)."""
    import minari
    kw["record_infos"] = True
    return minari.DataCollector(env, **kw)


def finish(collector_env, dataset_id: str, *, fs: float, samples_per_step: int = 1, episodes=None, check: bool = True,
           mass_kg=None, leg_length_m=None, sagittal_side=None, up: str = "z", name=None, kind: str = "simulation",
           simulator=None, skeleton=None, joint_torque_source=None, grf_source=None, provenance=None,
           **minari_kw) -> Path:
    """Create the dataset from a DataCollector, add the profile metadata and (check) read it back, so that a
    missing signal is reported now rather than at evaluation. Returns the data directory."""
    md = collector_env.create_dataset(dataset_id, **minari_kw)
    d = annotate(md.storage.data_path, fs=fs, samples_per_step=samples_per_step, episodes=episodes, mass_kg=mass_kg,
                 leg_length_m=leg_length_m, sagittal_side=sagittal_side, up=up, name=name, kind=kind,
                 simulator=simulator, skeleton=skeleton, joint_torque_source=joint_torque_source,
                 grf_source=grf_source, provenance=provenance)
    if check:
        from ..format import validate
        rep = validate(read(d))
        if not rep.ok:
            raise ValueError(f"{dataset_id}: " + "; ".join(rep.errors))
    return d
