"""Kinetic gait features from ground reaction forces (GRF) and joint torques, shared by the human
reference (Camargo et al. 2021 force plates and inverse dynamics) and the simulated rollouts.

Conventions
  * forces in body weights (BW), joint moments in N m / kg, powers in W / kg, work in J / kg
  * GRF low-pass filtered (4th-order zero-phase Butterworth, FILTER_HZ) before events and features,
    as force-plate data; signals sampled too slowly for the filter are used as recorded
  * contact = vertical GRF above CONTACT_BW; a stride runs from one foot strike (contact) to the
    next of the same foot. Within a stride a foot's swing is its longest interval without contact;
    briefer unloadings between two contacts (shorter than BRIDGE x the swing) belong to stance
    (`stance_mask`), so stance runs from the strike to the start of the swing (toe-off)
  * anteroposterior (AP) force along the walking direction: negative = braking, positive = propulsion
  * joint angles, moments and powers are sagittal, + = flexion / dorsiflexion moment

Per stride: speed, stance fraction, vertical first peak, mid-stance valley and second peak, braking
and propulsive impulse, peak braking and propulsive force, and the positive and negative work of
the hip, knee and ankle over the stride. The `tot_*` impulses use the total AP force of both feet over
the whole stride.

Centre-of-mass (COM) features (COM_FEATURES, `com_features`), from both feet's GRF and the COM velocity
and height:
  * phases of the stride, measured from both feet's stance (`stance_mask`): double support (both feet),
    single support (one foot) and flight (neither), fractions of the stride
  * step-to-step transition (individual-limbs method, Donelan, Kram & Kuo 2002): during the double
    support that starts at the stride's foot strike, the negative work of the leading (reference) leg
    on the COM (collision) and the positive work of the trailing leg (push-off), J/kg, with leg power
    F_leg . v_COM; and the time of the trailing leg's peak power relative to the foot strike (% stride)
  * pendular energy recovery (Cavagna, Thys & Zamboni 1976): R = (W_f + W_v - W_ext) / (W_f + W_v),
    with W the summed positive increments over the stride of the horizontal kinetic energy (W_f), of
    the potential plus vertical kinetic energy (W_v) and of their sum (W_ext), %
For force-plate data the COM velocity and height come from integrating the total GRF over the stride
(`com_from_grf`); for the simulations they are the simulated COM.
"""
from __future__ import annotations

import numpy as np
from scipy.interpolate import interp1d
from scipy.signal import butter, sosfiltfilt

FILTER_HZ = 20.0
CONTACT_BW = 0.05
MIN_STANCE_S = 0.10
BRIDGE = 0.3          # unloadings within stance shorter than BRIDGE x the stride's swing count as contact
JOINTS = ("Hip", "Knee", "Ankle")
FEATURES = ("speed", "stride_time", "stance_frac", "fz_peak1", "fz_valley", "fz_peak2", "brake_impulse",
            "propel_impulse", "brake_peak", "propel_peak", "tot_brake_impulse", "tot_propel_impulse",
            *[f"{j.lower()}_{s}_work" for j in JOINTS for s in ("pos", "neg")],
            "double_support", "collision_work", "pushoff_work", "pushoff_peak_time", "recovery",
            "single_support", "flight")
COM_FEATURES = ("double_support", "collision_work", "pushoff_work", "pushoff_peak_time", "recovery",
                "single_support", "flight")
G = 9.81


def lowpass(x, fs, hz=FILTER_HZ, axis=0):
    """Zero-phase 4th-order Butterworth low-pass; returned unchanged if fs <= 2.5 * hz."""
    x = np.asarray(x, dtype=float)
    if fs <= 2.5 * hz or x.shape[axis] < 30:
        return x
    return sosfiltfilt(butter(4, hz / (0.5 * fs), output="sos"), x, axis=axis)


def foot_strikes(fz_bw, fs, min_stance_s: float | None = None):
    """Indices where the vertical GRF (BW) rises through CONTACT_BW, starting a contact of at least
    MIN_STANCE_S, at least 2 x MIN_STANCE_S after the previous strike (rejects flicker at contact), and
    after an unloading that is a swing: a reloading less than BRIDGE x the median swing (the longest
    unloading of each stride) after the end of the previous contact of at least MIN_STANCE_S continues
    that stance and is not a strike (brief touches in between, shorter than MIN_STANCE_S, are ignored); and a
    strike within half the median stride of the previous one also continues its stance (the first contact
    is the strike, as initial contact; this assumes that most strides are not split).

    Very fast gaits: when no stride is found (fewer than 3 strikes) because every contact is shorter than
    MIN_STANCE_S, as in robots that step at 4-5 Hz (Isaac Lab H1: 0.09 s contacts, 0.22 s strides), the
    minimum stance is scaled to the gait: 0.2 x the stride period (the median interval between the onsets
    of contacts that load the foot with >= 0.5 BW), at most MIN_STANCE_S. Stance takes more than 20 % of
    the stride even in human sprinting, so a contact that short is a step, not a touch. Gaits whose strikes
    are found with MIN_STANCE_S are unchanged."""
    if min_stance_s is None:
        out = foot_strikes(fz_bw, fs, MIN_STANCE_S)
        if len(out) < 3:
            T = _stride_period(fz_bw, fs)
            if T is not None and 0.2 * T < MIN_STANCE_S:
                alt = foot_strikes(fz_bw, fs, max(0.2 * T, 2.0 / fs))
                if len(alt) > len(out):
                    return alt
        return out
    on = np.asarray(fz_bw) > CONTACT_BW
    up = np.flatnonzero(~on[:-1] & on[1:]) + 1
    down = np.flatnonzero(on[:-1] & ~on[1:]) + 1
    n = max(int(min_stance_s * fs), 1)

    def select(cands):
        keep = []
        for u in cands:
            nxt = down[down > u]
            if nxt.size and nxt[0] - u >= n and (not keep or u - keep[-1] >= 2 * n):
                keep.append(u)
        return np.array(keep, dtype=int)

    keep = select(up)
    if len(keep) < 3:
        return keep
    swings = []
    for a, b in zip(keep[:-1], keep[1:]):                          # longest unloading of each stride
        off = (~on[a:b]).astype(int)
        if off.any():
            i = np.flatnonzero(np.diff(np.r_[0, off, 0]))
            swings.append(int(np.max(i[1::2] - i[::2])))
    if not swings:
        return keep
    swing = float(np.median(swings))
    starts = np.r_[0, up] if on[0] else up                          # a contact under way at the first sample
    ends = [d for u, d in zip(starts, [down[down > u][0] if (down > u).any() else len(on) for u in starts]) if d - u >= n]
    ends = np.array(ends, int)                                       # ends of the contacts of >= MIN_STANCE_S
    prev_off = np.array([u - (ends[ends < u][-1] if (ends < u).any() else -10 ** 9) for u in up])
    keep = select(up[prev_off >= BRIDGE * swing])
    if len(keep) < 3:
        return keep
    half = 0.5 * float(np.median(np.diff(keep)))                    # a reloading within half a stride of the
    out = [keep[0]]                                                 # previous strike continues its stance
    for u in keep[1:]:
        if u - out[-1] >= half:
            out.append(u)
    return np.array(out, dtype=int)


def _stride_period(fz_bw, fs) -> float | None:
    """Median interval (s) between the onsets of contacts whose force reaches 0.5 BW (one foot), or None."""
    f = np.asarray(fz_bw, float)
    on = f > CONTACT_BW
    up = np.flatnonzero(~on[:-1] & on[1:]) + 1
    down = np.flatnonzero(on[:-1] & ~on[1:]) + 1
    loaded = [u for u in up if (down > u).any() and f[u:down[down > u][0]].max() >= 0.5]
    return float(np.median(np.diff(loaded))) / fs if len(loaded) >= 4 else None


def contact_durations(fz_bw, fs) -> np.ndarray:
    """Durations (s) of the intervals in which the vertical GRF (BW) exceeds CONTACT_BW."""
    on = np.asarray(fz_bw) > CONTACT_BW
    up = np.flatnonzero(~on[:-1] & on[1:]) + 1
    down = np.flatnonzero(on[:-1] & ~on[1:]) + 1
    down = down[down > up[0]] if up.size else down
    k = min(len(up), len(down))
    return (down[:k] - up[:k]) / fs


def stance_mask(fz_bw) -> np.ndarray:
    """A foot's stance over one stride window: contact (vertical GRF > CONTACT_BW) with the brief
    unloadings between two contacts that are shorter than BRIDGE x the longest unloading (the swing)
    counted as contact. Unloadings at the window's edges are kept (the foot is off the ground there)."""
    on = np.asarray(fz_bw, float) > CONTACT_BW
    edges = np.flatnonzero(np.diff(on.astype(int)))
    runs = [(a + 1, b + 1) for a, b in zip(edges[:-1], edges[1:]) if on[a] and not on[a + 1]]   # interior
    off = (~on).astype(int)
    longest = 0
    if off.any():
        idx = np.flatnonzero(np.diff(np.r_[0, off, 0]))
        longest = int(np.max(idx[1::2] - idx[::2]))
    mask = on.copy()
    for a, b in runs:
        if b - a < BRIDGE * longest:
            mask[a:b] = True
    return mask


def resample(x, n=101):
    x = np.asarray(x, dtype=float)
    return interp1d(np.linspace(0, 100, len(x)), x, axis=0)(np.linspace(0, 100, n))


def stride_features(fz, fap, mom, power, fs, speed, power_fs=None, fap_total=None):
    """Features of one stride. Arrays run from a foot strike to the next strike of the same foot, both
    included (humanlike.gait): the features use the samples of the stride (all but the last), the
    101-sample cycles all of them (0 % and 100 % at the strikes).

    fz, fap: vertical and AP GRF (BW) at fs; mom, power: [n, 3] hip/knee/ankle (N m/kg, W/kg) at
    power_fs (defaults to fs); fap_total: AP force of both feet (BW) at fs.
    Returns (feature dict, cycles dict of 101-sample curves)."""
    cz, cap = np.asarray(fz, float), np.asarray(fap, float)
    cmom, cp = np.asarray(mom, float), np.asarray(power, float)
    cft = np.full(len(cz), np.nan) if fap_total is None else np.asarray(fap_total, float)
    fz, fap, mom, power = cz[:-1], cap[:-1], cmom[:-1], cp[:-1]
    fap_total = None if fap_total is None else cft[:-1]
    pfs = power_fs or fs
    off = np.flatnonzero(~stance_mask(fz))
    st_end = int(off[0]) if off.size else len(fz)                    # first sample of swing (toe-off)
    stance = slice(0, st_end)
    sz, sa = fz[stance], fap[stance]
    half = max(1, st_end // 2)
    i1 = int(np.argmax(sz[:half])); i2 = half + int(np.argmax(sz[half:])) if st_end > half else i1
    valley = float(sz[i1:i2 + 1].min()) if i2 > i1 else np.nan
    dt = 1.0 / fs
    f = dict(speed=float(speed), stride_time=len(fz) / fs, stance_frac=st_end / len(fz),
             fz_peak1=float(sz[i1]), fz_valley=valley, fz_peak2=float(sz[i2]) if st_end > half else np.nan,
             brake_impulse=float(np.clip(sa, None, 0).sum() * dt), propel_impulse=float(np.clip(sa, 0, None).sum() * dt),
             brake_peak=float(sa.min()), propel_peak=float(sa.max()))
    ft = np.full(len(fz), np.nan) if fap_total is None else np.asarray(fap_total, float)
    f["tot_brake_impulse"] = float(np.clip(ft, None, 0).sum() * dt)
    f["tot_propel_impulse"] = float(np.clip(ft, 0, None).sum() * dt)
    p = np.asarray(power, float)
    for k, j in enumerate(JOINTS):
        f[f"{j.lower()}_pos_work"] = float(np.clip(p[:, k], 0, None).sum() / pfs)
        f[f"{j.lower()}_neg_work"] = float(np.clip(p[:, k], None, 0).sum() / pfs)
    f.update(dict.fromkeys(COM_FEATURES, np.nan))                     # filled by the caller (com_features)
    cyc = dict(fz=resample(cz), fap=resample(cap), fap_total=resample(cft), moment=resample(cmom), power=resample(cp))
    return f, cyc


def com_from_grf(f_total, fs, speed):
    """COM velocity [n, 3] (AP, ML, vertical; m/s) and height [n] (m) over one steady stride from the
    total GRF of both feet [n, 3] (BW, same axes): the integral of the acceleration g (F - e_z), with
    the drift removed so that the stride is periodic, mean AP velocity = speed (treadmill belt speed,
    i.e. the overground frame), mean ML and vertical velocity = 0, and mean height 0."""
    a = G * (np.asarray(f_total, float) - np.array([0.0, 0.0, 1.0]))
    v = np.cumsum(a, axis=0) / fs
    n = len(v)
    v -= np.outer(np.arange(n) / max(n - 1, 1), v[-1] - v[0])          # periodic
    v -= v.mean(0)
    v[:, 0] += speed
    z = np.cumsum(v[:, 2]) / fs
    z -= np.linspace(0, 1, n) * (z[-1] - z[0])
    return v, z - z.mean()


def com_features(f_ref, f_con, v, z, fs, i0, i1, pre=None):
    """Step-to-step transition and pendular-recovery features of the stride [i0, i1).

    f_ref, f_con: GRF of the reference (stride) foot and of the other foot [n, 3] (BW; AP, ML,
    vertical); v [n, 3] COM velocity (m/s; AP absolute, ML, vertical); z [n] COM height (m); all on
    one time base at fs, covering at least [i0 - pre, i1) where pre (samples, default a quarter
    stride) is the window searched for the trailing leg's power peak before the foot strike."""
    f_ref, f_con, v, z = (np.asarray(x, float) for x in (f_ref, f_con, v, z))
    n = i1 - i0
    pre = n // 4 if pre is None else pre
    out = dict.fromkeys(COM_FEATURES, np.nan)
    m_ref, m_con = stance_mask(f_ref[i0:i1, 2]), stance_mask(f_con[i0:i1, 2])
    out["double_support"] = float((m_ref & m_con).mean())                # fractions of the stride
    out["single_support"] = float((m_ref ^ m_con).mean())
    out["flight"] = float((~m_ref & ~m_con).mean())
    p_ref = G * np.sum(f_ref * v, axis=1)                                # W/kg
    p_con = G * np.sum(f_con * v, axis=1)
    # double support from the foot strike to the other foot's toe-off
    if m_con[0]:
        off = np.flatnonzero(~m_con)
        if off.size:
            j = i0 + int(off[0])
            out["collision_work"] = float(np.clip(p_ref[i0:j], None, 0).sum() / fs)
            out["pushoff_work"] = float(np.clip(p_con[i0:j], 0, None).sum() / fs)
            k0 = max(0, i0 - pre)
            out["pushoff_peak_time"] = float((k0 + np.argmax(p_con[k0:j]) - i0) / n * 100)
    ep = G * z[i0:i1] + 0.5 * v[i0:i1, 2] ** 2                           # potential + vertical kinetic, J/kg
    ek = 0.5 * (v[i0:i1, 0] ** 2 + v[i0:i1, 1] ** 2)                       # horizontal kinetic
    pos = lambda e: float(np.clip(np.diff(e), 0, None).sum())            # noqa: E731
    wf, wv, wext = pos(ek), pos(ep), pos(ek + ep)
    if wf + wv > 0:
        out["recovery"] = 100 * (wf + wv - wext) / (wf + wv)
    return out


def rollout_strides(fz, fap_xy, comv, mom, pw, fs, pfs, start, ok=None, fxy_total=None, feet=None, comz=None, pelvis=None):
    """Feature rows and cycles of the strides of one rollout. fz [n] (BW); fap_xy [n, 2] horizontal GRF
    of the foot (BW); comv [n, 3]; mom, pw [m, 3] at pfs; ok(a, b) -> bool filters strides by
    physics-row range; fxy_total [n, 2]: horizontal force of both feet (BW); feet [n, 2, 3]: GRF of the
    stride foot and of the other foot (BW, world axes) and comz [n] COM height (m) for the COM features;
    pelvis [n, 3] (m): the stride speed (humanlike.gait.stride_speed). Cycles include both strikes.
    comv None: no centre-of-mass data; the walking direction is the pelvis's and the COM velocity and
    height of each stride come from integrating the total GRF of the feet (com_from_grf), as for the
    force-plate data of the human reference."""
    fzf = lowpass(fz, fs); fxy = lowpass(fap_xy, fs)
    fxt = lowpass(fxy_total, fs) if fxy_total is not None else None
    from .gait import stride_speed
    pv = np.gradient(np.asarray(pelvis, float)[:, :2], 1 / fs, axis=0)
    grf_com = comv is None
    if grf_com:
        comv = np.c_[pv, np.zeros(len(pv))]
    hs = foot_strikes(fzf, fs)
    hs = hs[hs >= start]
    rows, cycs = [], []
    for a, b in zip(hs[:-1], hs[1:]):
        if ok is not None and not ok(a, b):
            continue
        vxy = comv[a:b, :2].mean(0)                            # walking direction of the stride
        if np.linalg.norm(vxy) < 1e-3:
            continue
        u2 = vxy / np.linalg.norm(vxy)
        sp = stride_speed(None, a, b, fs, vel=pv)
        fap = fxy[a:b + 1] @ u2
        pa, pb = int(round(a * pfs / fs)), int(round(b * pfs / fs))
        if pb - pa < 4:
            continue
        f, c = stride_features(fzf[a:b + 1], fap, mom[pa:pb + 1], pw[pa:pb + 1], fs, sp, power_fs=pfs,
                               fap_total=None if fxt is None else fxt[a:b + 1] @ u2)
        pre = (b - a) // 4
        if feet is not None and a >= pre:                      # COM features in walking-direction axes
            u = np.r_[u2, 0.0]; w = np.array([-u[1], u[0], 0.0]); e = np.array([0.0, 0.0, 1.0])
            axes = np.stack([u, w, e], 1)
            fr, fc = (lowpass(feet[a - pre:b, i], fs) @ axes for i in (0, 1))
            if grf_com:                                        # periodic stride, preceded by its own end
                vc, zc = com_from_grf(fr[pre:] + fc[pre:], fs, sp)
                f.update(com_features(fr, fc, np.r_[vc[-pre:], vc], np.r_[zc[-pre:], zc], fs, pre, pre + b - a, pre))
            else:
                f.update(com_features(fr, fc, comv[a - pre:b] @ axes, comz[a - pre:b], fs, pre, pre + b - a, pre))
        rows.append([f[k] for k in FEATURES]); cycs.append(c)
    return rows, cycs
