"""Analysis engine: runs the registered stages on an HLB data set in dependency order.

A stage declares the capabilities it needs (humanlike.format.spec.CAPABILITIES), the stages it
depends on, and the reference kinds and options it reads. A stage whose data are missing, or whose
dependency did not run, is skipped with the reason, so every data set gets every analysis its data
support. With a cache (humanlike.cache), a stage whose inputs are unchanged is not run again.
"""
from __future__ import annotations

import time
import traceback
from dataclasses import dataclass, field
from typing import Callable

import numpy as np

from .format import Dataset, validate
from .references import DEFAULTS, Bundle


@dataclass
class Stage:
    name: str
    title: str
    needs: tuple = ()            # capabilities
    after: tuple = ()            # stages
    run: Callable = None         # (ctx) -> dict
    refs: tuple = ()             # reference kinds read (ctx.references[kind])
    options: tuple = ()          # evaluate() options read (ctx.options)


STAGES: dict[str, Stage] = {}


def stage(name, title, needs=(), after=(), refs=(), options=()):
    def deco(fn):
        STAGES[name] = Stage(name, title, tuple(needs), tuple(after), fn, tuple(refs), tuple(options))
        return fn
    return deco


def _key(st: Stage, ctx, keys: dict, data_fp: str) -> str:
    from .cache import code_fingerprint, stage_key
    refs = {}
    for kind in st.refs:
        names = ctx.references.get(kind, [])
        man = ctx.bundle.manifest["references"] if ctx.bundle is not None else {}
        refs[kind] = [[n, man.get(n, {}).get("sha256")] for n in names]
    return stage_key(stage=st.name, code=code_fingerprint(), data=data_fp, after=[keys.get(a) for a in st.after],
                     refs=refs, options={o: ctx.options.get(o) for o in st.options}, bundle=bool(ctx.bundle))


@dataclass
class Context:
    ds: Dataset
    bundle: Bundle | None
    references: dict
    options: dict
    results: dict = field(default_factory=dict)
    cache: dict = field(default_factory=dict)       # intermediate arrays shared between stages


def evaluate(ds: Dataset, references: dict | None = None, bundle: Bundle | None = None, only=None,
             progress: Callable | None = None, cache=None, **options) -> dict:
    """Run every applicable stage. Returns {"validation", "stages": {name: {status, title, reason,
    seconds, result, cached}}}; status is "ok", "skipped" or "error". cache: a humanlike.cache cache
    (MemoryCache, DirCache) or None."""
    from . import stages  # noqa: F401  (registers the stages)
    rep = validate(ds)
    out = {"dataset": ds.meta.get("dataset", {}), "n_rollouts": len(ds.rollouts), "validation": rep.to_dict(), "stages": {}}
    if not rep.ok:
        return out
    if bundle is None:
        try:
            bundle = Bundle()
        except FileNotFoundError:
            bundle = None
    ctx = Context(ds, bundle, {**DEFAULTS, **(references or {})}, options)
    done, keys = set(), {}
    order = _order(only)
    data_fp = None
    if cache is not None:
        from .cache import data_fingerprint
        data_fp = data_fingerprint(ds)
    for i, name in enumerate(order):
        st = STAGES[name]
        entry = {"title": st.title}
        missing = [c for c in st.needs if not rep.capabilities.get(c, (False, ""))[0]]
        blocked = [a for a in st.after if a not in done]
        if missing:
            entry.update(status="skipped", reason="; ".join(f"{c}: {rep.capabilities[c][1]}" for c in missing))
        elif blocked:
            entry.update(status="skipped", reason=f"needs stage {', '.join(blocked)}")
        else:
            t0 = time.time()
            key = _key(st, ctx, keys, data_fp) if cache is not None else None
            hit = cache.get(key) if key else None
            if hit is not None:
                ctx.cache.update(hit["cache"])
                ctx.results[name] = hit["result"]
                keys[name] = key
                done.add(name)
                entry.update(status="ok", result=hit["result"], cached=True, seconds=round(time.time() - t0, 3))
                out["stages"][name] = entry
                if progress:
                    progress(i + 1, len(order), name, "ok (cached)")
                continue
            try:
                before = set(ctx.cache)
                res = st.run(ctx)
                if isinstance(res, dict) and res.get("skipped"):
                    entry.update(status="skipped", reason=res["skipped"])
                    if "coverage" in res:                       # humanlike.coverage: what was missing
                        entry["coverage"] = res["coverage"]
                else:
                    ctx.results[name] = res
                    entry.update(status="ok", result=res)
                    done.add(name)
                    if key:
                        keys[name] = key
                        cache.put(key, {"result": res, "cache": {k: ctx.cache[k] for k in set(ctx.cache) - before}})
            except Exception as e:     # one failing analysis must not stop the others
                entry.update(status="error", reason=f"{type(e).__name__}: {e}", trace=traceback.format_exc(limit=3))
            entry["seconds"] = round(time.time() - t0, 3)
        out["stages"][name] = entry
        if progress:
            progress(i + 1, len(order), name, entry["status"])
    return to_jsonable(out)


def _order(only=None) -> list[str]:
    from . import stages  # noqa: F401
    want = set(STAGES if only is None else only)
    for n in list(want):                              # pull in dependencies
        stack = [n]
        while stack:
            for d in STAGES[stack.pop()].after:
                if d not in want:
                    want.add(d); stack.append(d)
    order, seen = [], set()

    def visit(n):
        if n in seen:
            return
        seen.add(n)
        for d in STAGES[n].after:
            visit(d)
        order.append(n)
    for n in STAGES:
        if n in want:
            visit(n)
    return order


def to_jsonable(x):
    if isinstance(x, dict):
        return {str(k): to_jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [to_jsonable(v) for v in x]
    if isinstance(x, np.ndarray):
        return to_jsonable(x.tolist())
    if isinstance(x, (np.floating, float)):
        return None if not np.isfinite(x) else float(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, np.bool_):
        return bool(x)
    if hasattr(x, "to_dict") and hasattr(x, "columns"):          # pandas DataFrame
        return to_jsonable(x.to_dict(orient="records"))
    return x
