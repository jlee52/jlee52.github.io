"""One leaderboard row from the results of humanlike.engine.evaluate: the headline number of each analysis
against the public human reference (Camargo et al. 2021 treadmill walking), side by side and never combined
into one score (the analyses measure different things, and a data set without a signal has no value for
the analyses that need it).

    humanlike summarize results/results.json [-o row.json]

    falls                 fraction of the rollouts that fell (left out of every analysis)
    js_stride_length      Jensen-Shannon divergence from the human speed-stride length relation (lower is closer)
    js_stride_frequency   ... speed-stride frequency relation
    z_stride_length       at matched speed: median robust z of the rollouts' stride length against the human
                          median and spread at their speed (|z| <= 2: within the human range); unlike JS, it
                          does not depend on which speeds the data cover
    z_stride_frequency    ... stride frequency
    fpgd                  foot-placement gain distance from the human feedback signature, mean over groups
    peak_dr2, peak_dr2_human   foot-placement control: mean peak explained variance, model and human
    peak_dr2_p            Welch test of the difference
    cot                   PASS / FAIL: cost of transport with a minimum at a walking speed (energetics)
    sagittal_consistent   sagittal joint-angle features within the human range (of 8)
    shape_hip/knee/ankle  median distance of the joint-angle cycle from the human mean (deg)
    principles            kinetic principles consistent with the human data, "k/n"
    double_support        median fraction of the stride with both feet on the ground   } rollouts at walking speeds
    flight                fraction of the rollouts with flight in > 1 % of the stride  } (mean speed 0.9-1.5 m/s,
                                                                                         as manuscript Table gait
                                                                                         phases; humans: 0)
    signals               the profile capabilities the data provide (core, energetics, sagittal, kinetics,
                          joint_kinetics)
    <column>_ci           95 % bootstrap interval (humanlike.bootstrap; rollouts or groups resampled)
    cot_stability         share of bootstrap resamples with the same COT verdict
    coverage              {analysis: "ok" | "low" | "insufficient"} (humanlike.coverage): "low" values moved by
                          more than ~10 % between subsamples of the manuscript's data; "insufficient" ones are
                          not given
"""
from __future__ import annotations

import numpy as np

GAIT, FEEDBACK = "camargo-treadmill/gait", "camargo-treadmill/feedback"
WALKING = (0.9, 1.5)
COLUMNS = ["falls", "js_stride_length", "js_stride_frequency", "z_stride_length", "z_stride_frequency", "fpgd", "peak_dr2", "peak_dr2_human", "peak_dr2_p",
           "cot", "sagittal_consistent", "shape_hip", "shape_knee", "shape_ankle", "principles", "double_support",
           "flight"]


def _ok(res, stage):
    st = res["stages"].get(stage, {})
    return st.get("result") if st.get("status") == "ok" else None


def row(res: dict) -> dict:
    """{column: value or None} plus "name", "signals" and "rollouts"."""
    out = dict.fromkeys(COLUMNS)
    ev = _ok(res, "events") or {}
    if ev.get("rollouts"):
        n = ev["rollouts"] + ev.get("excluded_fell", 0)
        out["falls"] = ev.get("excluded_fell", 0) / n
    g = (_ok(res, "gait_scaling") or {}).get(GAIT)
    if g and "skipped" not in g:
        for f in ("stride_length", "stride_frequency"):
            out[f"js_{f}"], out[f"js_{f}_ci"] = g[f"js_{f}"], g.get(f"js_{f}_ci")
            m = g.get(f"matched_{f}") or {}
            out[f"z_{f}"], out[f"z_{f}_ci"] = m.get("median_z"), m.get("median_z_ci")
    f = _ok(res, "feedback")
    if f and FEEDBACK in f.get("references", {}):
        r = f["references"][FEEDBACK]
        c = r.get("comparison", {}).get("peak_dr2", {})
        out.update(fpgd=r.get("fpgd_mean"), fpgd_ci=r.get("fpgd_mean_ci"), peak_dr2=c.get("model_mean"),
                   peak_dr2_ci=c.get("model_mean_ci"), peak_dr2_human=c.get("reference_mean"), peak_dr2_p=c.get("p"))
    e = _ok(res, "energetics")
    if e:
        out["cot"], out["cot_stability"] = e.get("label"), e.get("label_stability")
    s = _ok(res, "sagittal")
    if s:
        out["sagittal_consistent"], out["sagittal_consistent_ci"] = s.get("consistent_features"), s.get("consistent_features_ci")
        for j in ("Hip", "Knee", "Ankle"):
            out[f"shape_{j.lower()}"] = s.get("shape_distance", {}).get(j, {}).get("median")
    k = _ok(res, "kinetic_principles")
    if k:
        out["principles"] = f"{k['consistent']}/{k['evaluated']}"
    p, gs = _ok(res, "gait_phases"), _ok(res, "gait_summary")
    if p and gs:
        speed = {x["rollout"]: x["speed"] for x in gs["rollouts"]}
        walk = [x for x in p["rollouts"] if WALKING[0] <= speed.get(x["rollout"], np.nan) <= WALKING[1]]
        if walk:
            from .bootstrap import DEFAULT, ci
            d_, f_ = np.array([x["double_support"] for x in walk]), np.array([x["flight"] for x in walk])
            out["double_support"], out["double_support_ci"] = float(np.median(d_)), ci(lambda i: np.median(d_[i]), len(walk), DEFAULT)
            out["flight"], out["flight_ci"] = float(np.mean(f_ > 0.01)), ci(lambda i: np.mean(f_[i] > 0.01), len(walk), DEFAULT)
    cov = {}
    for stage, st in res["stages"].items():
        c = (st.get("result") or {}).get("coverage") or st.get("coverage")
        if stage == "gait_scaling" and st.get("status") == "ok":
            c = (st["result"].get(GAIT) or {}).get("coverage")
        if c:
            cov[stage] = c["status"]
    caps = res.get("validation", {}).get("capabilities", {})
    d = res.get("dataset") or {}
    return {"name": d.get("name"), "simulator": d.get("simulator"), "skeleton": d.get("skeleton"),
            "rollouts": res.get("n_rollouts"), "signals": [c for c, v in caps.items() if v.get("available")],
            "coverage": cov, **out}


def main(argv=None):
    import argparse
    import json
    from pathlib import Path
    ap = argparse.ArgumentParser(prog="humanlike summarize", description=__doc__.split("\n")[0])
    ap.add_argument("results"); ap.add_argument("-o", "--output")
    a = ap.parse_args(argv)
    r = row(json.loads(Path(a.results).read_text()))
    text = json.dumps(r, indent=1)
    if a.output:
        Path(a.output).write_text(text)
    print(text)
    return 0
